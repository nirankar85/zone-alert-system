package com.trendanalyzer.one.secure

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.trendanalyzer.one.log.Logx
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-GCM with a key that never leaves the keystore. The preferences file holds only the
 * initialisation vector and the ciphertext, and a decrypt failure deletes the entry instead of
 * handing back something wrong.
 */
class KeystoreSecretStore(context: Context) : SecretStore {

    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    override fun put(key: String, value: String) {
        runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey())

            val ciphertext = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            val stored = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) +
                SEPARATOR + Base64.encodeToString(ciphertext, Base64.NO_WRAP)

            preferences.edit().putString(key, stored).commit()
        }.onFailure { Logx.e(TAG, "secret write failed", it) }
    }

    override fun get(key: String): String? {
        val stored = preferences.getString(key, null) ?: return null
        val separator = stored.indexOf(SEPARATOR)
        if (separator <= 0) {
            remove(key)
            return null
        }

        return runCatching {
            val iv = Base64.decode(stored.substring(0, separator), Base64.NO_WRAP)
            val ciphertext = Base64.decode(stored.substring(separator + 1), Base64.NO_WRAP)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(TAG_BITS, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        }.getOrElse {
            remove(key)
            null
        }
    }

    override fun remove(key: String) {
        runCatching { preferences.edit().remove(key).commit() }
    }

    override fun has(key: String): Boolean = get(key) != null

    private fun secretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )

        return generator.generateKey()
    }

    private companion object {
        const val TAG = "KeystoreSecretStore"
        const val PREFERENCES_NAME = "trend_analyzer_secure"
        const val KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "trend_analyzer_secret_key"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val TAG_BITS = 128
        const val SEPARATOR = ':'
    }
}
