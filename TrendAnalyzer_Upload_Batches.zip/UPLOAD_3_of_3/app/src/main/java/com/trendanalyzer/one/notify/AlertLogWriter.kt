package com.trendanalyzer.one.notify

interface AlertLogWriter {
    suspend fun write(record: AlertLogRecord): Long
}
