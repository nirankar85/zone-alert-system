package com.trendanalyzer.one.config

/**
 * The chart speeds a client may choose. This is not the list of zone rhythms: it is a small,
 * fixed set chosen so a client can read the chart without learning how the zones are watched.
 */
object ChartTimeframes {

    val visibleToClients: List<String> = listOf("1m", "5m", "6h", "1w")

    fun isVisible(timeframe: String): Boolean = timeframe in visibleToClients
}
