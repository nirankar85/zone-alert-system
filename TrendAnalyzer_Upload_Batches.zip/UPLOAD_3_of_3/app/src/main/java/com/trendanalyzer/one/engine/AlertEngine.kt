package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.EngineSettings
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.time.SystemAppClock
import kotlin.math.abs

/**
 * Decides whether a line is close enough to speak about. A rhythm says one thing per approach:
 * after speaking it stays quiet until price has walked away by the rearm distance or the cooldown
 * has passed and it approaches again.
 */
class AlertEngine(private val clock: AppClock = SystemAppClock) {

    fun decide(
        reading: ZoneReading,
        price: Double,
        settings: EngineSettings,
        state: ZoneRuntimeState
    ): AlertDecision {
        val now = clock.nowMillis()

        if (!reading.isValid() || !price.isFinite() || price <= 0.0) {
            return AlertDecision(state, null)
        }

        val distance = abs(price - reading.line)
        val sideChanged = reading.side != state.side

        var updated = state.copy(
            side = reading.side,
            lineValue = reading.line,
            lastPrice = price
        )

        if (sideChanged) {
            updated = updated.copy(phase = AlertPhase.ARMED, phaseSinceMillis = now)
        }

        val cooldownMillis = settings.cooldownSeconds.toLong() * 1_000L
        val cooldownElapsed = now - updated.lastAlertAtMillis >= cooldownMillis

        if (updated.phase == AlertPhase.COOLDOWN &&
            (distance > settings.rearmDistancePoints || cooldownElapsed)
        ) {
            updated = updated.copy(phase = AlertPhase.ARMED, phaseSinceMillis = now)
        }

        val gradeVisible = reading.grade >= settings.minGrade
        val near = distance <= settings.alertDistancePoints

        if (updated.phase == AlertPhase.ARMED && gradeVisible && near) {
            val event = AlertEvent(
                zoneId = reading.zoneId,
                grade = reading.grade,
                side = reading.side,
                lineValue = reading.line,
                price = price,
                atMillis = now,
                distance = distance
            )

            updated = updated.copy(
                phase = AlertPhase.COOLDOWN,
                phaseSinceMillis = now,
                lastAlertAtMillis = now,
                lastAlertLineValue = reading.line
            )

            return AlertDecision(updated, event)
        }

        return AlertDecision(updated, null)
    }
}
