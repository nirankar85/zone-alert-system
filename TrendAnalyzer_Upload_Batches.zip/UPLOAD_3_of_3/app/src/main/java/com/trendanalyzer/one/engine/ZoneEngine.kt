package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.config.internal.ZoneSpec
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.market.Candle
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.time.SystemAppClock

/** Turns candles into the newest line for one watched rhythm. */
class ZoneEngine(private val clock: AppClock = SystemAppClock) {

    fun evaluate(
        spec: ZoneSpec,
        candles: List<Candle>,
        smoothing: AtrSmoothing
    ): ZoneReading? {
        if (candles.size < spec.atrPeriod + 1) return null

        val points = LineEngine.compute(candles, spec.atrPeriod, spec.multiplier, smoothing)
        val last = points.lastOrNull() ?: return null

        val atr = Atr.latest(candles, spec.atrPeriod, smoothing)
        if (atr <= 0.0 || last.line <= 0.0) return null

        val reading = ZoneReading(
            zoneId = spec.id,
            grade = spec.grade,
            side = last.side,
            line = last.line,
            close = candles.last().close,
            atr = atr,
            atMillis = clock.nowMillis()
        )

        if (!reading.isValid()) {
            Logx.w(TAG, "zone ${spec.id} produced an unusable line")
            return null
        }

        return reading
    }

    fun lineHistory(
        spec: ZoneSpec,
        candles: List<Candle>,
        smoothing: AtrSmoothing
    ): List<LinePoint> = LineEngine.compute(candles, spec.atrPeriod, spec.multiplier, smoothing)

    private companion object {
        const val TAG = "ZoneEngine"
    }
}
