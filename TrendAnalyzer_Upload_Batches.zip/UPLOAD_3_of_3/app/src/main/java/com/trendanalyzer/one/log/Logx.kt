package com.trendanalyzer.one.log

import android.util.Log

/** Every log line passes through the redactor before it leaves the process. */
object Logx {

    fun d(tag: String, message: String) {
        Log.d(tag, LogRedactor.redact(message))
    }

    fun w(tag: String, message: String) {
        Log.w(tag, LogRedactor.redact(message))
    }

    fun e(tag: String, message: String, error: Throwable? = null) {
        Log.e(tag, LogRedactor.redact(message), error)
    }
}
