package com.trendanalyzer.one.log

/**
 * Removes what must never reach logcat: keys, bearer tokens, long opaque runs, and the local
 * part of an email address.
 */
object LogRedactor {

    const val MASK: String = "***"

    private const val MIN_OPAQUE_RUN = 24

    private val bearerPattern = Regex("(?i)bearer\\s+[A-Za-z0-9._~+/=\\-]+")

    private val keyValuePattern = Regex(
        "(?i)\\b(token|secret|password|passwd|apikey|api_key|authorization|auth)\\b" +
            "(\"?\\s*[=:]\\s*)" +
            "(\"[^\"]*\"|'[^']*'|[^\\s,;&}]+)"
    )

    private val emailPattern = Regex(
        "([A-Za-z0-9._%+\\-])[A-Za-z0-9._%+\\-]*(@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,})"
    )

    private val opaqueRunPattern = Regex("[A-Za-z0-9_\\-]{$MIN_OPAQUE_RUN,}")

    fun redact(text: String): String {
        var output = text

        output = bearerPattern.replace(output) { "Bearer $MASK" }

        output = keyValuePattern.replace(output) { match ->
            val key = match.groupValues[1]
            val separator = match.groupValues[2]
            "$key$separator$MASK"
        }

        output = emailPattern.replace(output) { match ->
            match.groupValues[1] + MASK + match.groupValues[2]
        }

        output = opaqueRunPattern.replace(output) { MASK }

        return output
    }

    fun redactUrl(url: String): String {
        val separator = url.indexOf('?')
        val base = if (separator >= 0) url.substring(0, separator) else url
        return redact(base)
    }
}
