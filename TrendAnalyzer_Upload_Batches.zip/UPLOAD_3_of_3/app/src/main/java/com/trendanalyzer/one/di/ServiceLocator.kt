package com.trendanalyzer.one.di

import android.content.Context
import com.trendanalyzer.one.account.AccountRepository
import com.trendanalyzer.one.account.ClientCacheStore
import com.trendanalyzer.one.account.FirebaseAuthGateway
import com.trendanalyzer.one.account.FirestoreAccountDataSource
import com.trendanalyzer.one.account.SessionStore
import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.data.AlertLogRoomWriter
import com.trendanalyzer.one.data.db.AppDatabase
import com.trendanalyzer.one.engine.AlertDispatcher
import com.trendanalyzer.one.engine.AlertEngine
import com.trendanalyzer.one.engine.AlertGrouper
import com.trendanalyzer.one.engine.AlertStateStore
import com.trendanalyzer.one.engine.EnginePipeline
import com.trendanalyzer.one.engine.RoomAlertStateStore
import com.trendanalyzer.one.engine.ZoneEngine
import com.trendanalyzer.one.market.CandleRepository
import com.trendanalyzer.one.market.DeltaRestClient
import com.trendanalyzer.one.market.DeltaWebSocketClient
import com.trendanalyzer.one.market.MarketFeed
import com.trendanalyzer.one.market.RateLimitGate
import com.trendanalyzer.one.notify.AlertHistoryRecorder
import com.trendanalyzer.one.notify.AlertNotifier
import com.trendanalyzer.one.notify.ChannelRegistrar
import com.trendanalyzer.one.notify.NotificationPermission
import com.trendanalyzer.one.notify.OngoingNotifier
import com.trendanalyzer.one.secure.KeystoreSecretStore
import com.trendanalyzer.one.secure.VoiceMonkeyCredentialRepository
import com.trendanalyzer.one.service.WatchController
import com.trendanalyzer.one.service.WatchRestorePolicy
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.time.SystemAppClock
import com.trendanalyzer.one.util.AppDispatchers
import com.trendanalyzer.one.util.DispatchersProvider
import com.trendanalyzer.one.voice.AlexaAnnouncer
import com.trendanalyzer.one.voice.AlexaCounter
import com.trendanalyzer.one.voice.PhoneVoice
import com.trendanalyzer.one.voice.VoiceGateway
import com.trendanalyzer.one.voice.VoiceHealth
import com.trendanalyzer.one.voice.VoiceMonkeyClient
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The one wiring point. Everything is created here and nowhere else, so a screen can never build
 * a second engine or a second speaker.
 */
object ServiceLocator {

    val clock: AppClock = SystemAppClock
    val dispatchers: DispatchersProvider = AppDispatchers

    private lateinit var appContext: Context
    private var initialized = false

    lateinit var database: AppDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var marketFeed: MarketFeed
        private set

    lateinit var pipeline: EnginePipeline
        private set

    lateinit var phoneVoice: PhoneVoice
        private set

    lateinit var voiceHealth: VoiceHealth
        private set

    lateinit var voiceGateway: VoiceGateway
        private set

    lateinit var alexaCounter: AlexaCounter
        private set

    lateinit var voiceMonkeyCredentials: VoiceMonkeyCredentialRepository
        private set

    lateinit var notificationPermission: NotificationPermission
        private set

    lateinit var alertNotifier: AlertNotifier
        private set

    lateinit var ongoingNotifier: OngoingNotifier
        private set

    lateinit var notificationChannels: ChannelRegistrar
        private set

    lateinit var watchController: WatchController
        private set

    lateinit var watchRestorePolicy: WatchRestorePolicy
        private set

    val accountRepository: AccountRepository by lazy {
        AccountRepository(
            auth = FirebaseAuthGateway(appContext),
            firestore = FirestoreAccountDataSource(),
            cache = ClientCacheStore(database.clientCacheDao(), clock),
            session = SessionStore(appContext),
            clock = clock
        )
    }

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        appContext = context.applicationContext

        database = AppDatabase.get(appContext)
        settingsRepository = SettingsRepository(database.settingsDao(), clock)

        CoroutineScope(SupervisorJob() + dispatchers.io).launch {
            runCatching { settingsRepository.load() }
        }

        val rest = DeltaRestClient(
            gate = RateLimitGate(clock),
            clock = clock
        )

        val candles = CandleRepository(rest, database.candleDao(), clock)

        marketFeed = MarketFeed(
            rest = rest,
            repository = candles,
            settings = settingsRepository,
            clock = clock,
            socket = DeltaWebSocketClient( clock = clock),
            dispatchers = dispatchers
        )

        notificationPermission = NotificationPermission(appContext)
        alertNotifier = AlertNotifier(appContext, notificationPermission)
        ongoingNotifier = OngoingNotifier(appContext, notificationPermission)
        notificationChannels = ChannelRegistrar(appContext)

        phoneVoice = PhoneVoice(appContext).also { it.initialize() }
        voiceHealth = VoiceHealth(clock)

        voiceMonkeyCredentials = VoiceMonkeyCredentialRepository(KeystoreSecretStore(appContext))
        alexaCounter = AlexaCounter(database.alexaCounterDao(), clock)

        val alexa = AlexaAnnouncer(
            credentials = voiceMonkeyCredentials,
            client = VoiceMonkeyClient(),
            counter = alexaCounter,
            settings = settingsRepository
        )

        voiceGateway = VoiceGateway(phoneVoice, alexa, settingsRepository, clock)

        val pipelineRef = AtomicReference<EnginePipeline?>(null)
        val history = AlertHistoryRecorder(AlertLogRoomWriter(database.alertLogDao()), clock)

        val dispatcher = AlertDispatcher(
            grouper = AlertGrouper(),
            voice = voiceGateway,
            notifier = alertNotifier,
            permission = notificationPermission,
            history = history,
            settings = settingsRepository,
            clock = clock,
            dispatchers = dispatchers,
            voiceHealth = voiceHealth,
            latestReading = { zoneId -> pipelineRef.get()?.reading(zoneId) },
            latestPrice = { pipelineRef.get()?.price() }
        )

        val stateStore: AlertStateStore = RoomAlertStateStore(database.zoneStateDao(), clock)

        val engine = EnginePipeline(
            feed = marketFeed,
            settings = settingsRepository,
            zoneEngine = ZoneEngine(clock),
            alertEngine = AlertEngine(clock),
            stateStore = stateStore,
            dispatcher = dispatcher,
            clock = clock,
            dispatchers = dispatchers,
            allowedGrades = { accountRepository.visibleGradesForAlerts(clock.nowMillis()) }
        )

        pipelineRef.set(engine)
        pipeline = engine

        watchController = WatchController(appContext)
        watchRestorePolicy = WatchRestorePolicy(appContext)
    }

    fun supportWhatsAppUrl(): String =
        "https://wa.me/" + AppConfig.SUPPORT_WHATSAPP_E164.removePrefix("+")
}
