package com.trendanalyzer.one.notify

/**
 * A full-screen alert is only for a phone that may show one and is not inside quiet hours.
 * Everything else gets a heads-up notification, which is enough.
 */
object FullScreenIntentPolicy {

    fun allows(canUseFullScreen: Boolean, quiet: Boolean): Boolean = canUseFullScreen && !quiet
}
