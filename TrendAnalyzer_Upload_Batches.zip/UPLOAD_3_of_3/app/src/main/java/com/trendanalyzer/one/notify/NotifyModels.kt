package com.trendanalyzer.one.notify

object NotifyActions {
    const val ACTION_STOP_WATCH = "com.trendanalyzer.one.action.STOP_WATCH"
    const val ACTION_START_WATCH = "com.trendanalyzer.one.action.START_WATCH"
}

/** One line in the alert history table. Text only: no prices from the venue are ever stored twice. */
data class AlertLogRecord(
    val createdAtMillis: Long,
    val speech: String,
    val title: String,
    val body: String,
    val zoneIds: List<String>,
    val zoneGrades: Map<String, Double>,
    val notified: Boolean,
    val spoken: Boolean,
    val alexaStatus: String
)
