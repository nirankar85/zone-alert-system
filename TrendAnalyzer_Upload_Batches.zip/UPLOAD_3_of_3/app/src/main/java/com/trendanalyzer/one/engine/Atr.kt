package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.market.Candle
import kotlin.math.abs
import kotlin.math.max

/**
 * Average true range. The default is a simple average of the last period, which is honest and
 * stable; the RMA option matches the smoothing used by the charting site. Leading entries stay
 * at zero because there is not enough history yet, and callers must skip them.
 */
object Atr {

    fun trueRanges(candles: List<Candle>): DoubleArray {
        val ranges = DoubleArray(candles.size)

        for (index in candles.indices) {
            val candle = candles[index]
            ranges[index] = if (index == 0) {
                (candle.high - candle.low).coerceAtLeast(0.0)
            } else {
                val previousClose = candles[index - 1].close
                max(
                    candle.high - candle.low,
                    max(abs(candle.high - previousClose), abs(candle.low - previousClose))
                )
            }
        }

        return ranges
    }

    fun series(
        candles: List<Candle>,
        period: Int = 10,
        smoothing: AtrSmoothing = AtrSmoothing.SMA
    ): DoubleArray {
        val safePeriod = period.coerceAtLeast(1)
        val output = DoubleArray(candles.size)
        if (candles.size < safePeriod) return output

        val ranges = trueRanges(candles)

        when (smoothing) {
            AtrSmoothing.SMA -> {
                var windowSum = 0.0
                for (index in candles.indices) {
                    windowSum += ranges[index]
                    if (index >= safePeriod) windowSum -= ranges[index - safePeriod]
                    if (index >= safePeriod - 1) output[index] = windowSum / safePeriod
                }
            }

            AtrSmoothing.RMA -> {
                var seed = 0.0
                for (index in 0 until safePeriod) seed += ranges[index]
                seed /= safePeriod
                output[safePeriod - 1] = seed

                for (index in safePeriod until candles.size) {
                    seed = (seed * (safePeriod - 1) + ranges[index]) / safePeriod
                    output[index] = seed
                }
            }
        }

        return output
    }

    fun latest(candles: List<Candle>, period: Int = 10, smoothing: AtrSmoothing = AtrSmoothing.SMA): Double =
        series(candles, period, smoothing).lastOrNull() ?: 0.0
}
