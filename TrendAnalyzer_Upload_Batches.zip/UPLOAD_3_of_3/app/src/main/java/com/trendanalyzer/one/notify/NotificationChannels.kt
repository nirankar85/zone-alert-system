package com.trendanalyzer.one.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import com.trendanalyzer.one.R
import com.trendanalyzer.one.config.AppConfig

object NotificationChannels {

    fun ensure(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val alerts = NotificationChannel(
            AppConfig.ALERT_CHANNEL_ID,
            context.getString(R.string.channel_alerts_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.channel_alerts_description)
            enableVibration(true)
            vibrationPattern = longArrayOf(0L, 350L, 200L, 350L)
            enableLights(true)
            setShowBadge(true)
        }

        val watch = NotificationChannel(
            AppConfig.WATCH_CHANNEL_ID,
            context.getString(R.string.channel_service_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.channel_service_description)
            setShowBadge(false)
        }

        manager.createNotificationChannels(listOf(alerts, watch))
    }
}
