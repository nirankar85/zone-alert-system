package com.trendanalyzer.one.voice

import com.trendanalyzer.one.log.Logx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class VoiceMonkeyClient(
    private val http: OkHttpClient = defaultClient(),
    private val endpoint: String = ENDPOINT
) {

    data class Response(val success: Boolean, val statusCode: Int)

    suspend fun announce(token: String, device: String, speech: String): Response =
        withContext(Dispatchers.IO) {
            if (token.isBlank() || device.isBlank() || speech.isBlank()) {
                return@withContext Response(false, 0)
            }

            val payload = """{"token":"${escape(token)}","device":"${escape(device)}","speech":"${escape(speech)}"}"""
            val request = Request.Builder()
                .url(endpoint)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(JSON_MEDIA_TYPE))
                .build()

            runCatching {
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Logx.w(TAG, "announce refused with status ${response.code}")
                    }
                    Response(response.isSuccessful, response.code)
                }
            }.getOrElse { error ->
                Logx.w(TAG, "announce failed: ${error::class.java.simpleName}")
                Response(false, 0)
            }
        }

    private fun escape(value: String): String = buildString(value.length + 8) {
        value.forEach { character ->
            when (character) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (character.code < 0x20) append(' ') else append(character)
            }
        }
    }

    companion object {
        private const val TAG = "VoiceMonkeyClient"
        private const val ENDPOINT = "https://api-v3.voicemonkey.io/announce"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }
}
