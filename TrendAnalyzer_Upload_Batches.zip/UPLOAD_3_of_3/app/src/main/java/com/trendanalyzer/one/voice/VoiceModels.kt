package com.trendanalyzer.one.voice

enum class AlertKind { FIRST, FOLLOW_UP_FIRST, FOLLOW_UP_SECOND }

data class AnnouncementOutcome(
    val phoneSpoken: Boolean,
    val alexaStatus: String,
    val quiet: Boolean
)
