package com.trendanalyzer.one.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import com.trendanalyzer.one.log.Logx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID

/**
 * The phone speaking. Initialisation is asynchronous and the first alert can arrive before the
 * engine is ready, so a not-ready engine answers false rather than pretending it spoke.
 */
class PhoneVoice(context: Context) {

    private val appContext = context.applicationContext

    @Volatile
    private var engine: TextToSpeech? = null

    @Volatile
    private var ready: Boolean = false

    private val lock = Any()

    fun initialize() {
        synchronized(lock) {
            if (engine != null) return

            engine = TextToSpeech(appContext) { status ->
                if (status != TextToSpeech.SUCCESS) {
                    Logx.w(TAG, "speech engine refused to start")
                    ready = false
                    return@TextToSpeech
                }

                val textToSpeech = engine ?: return@TextToSpeech
                textToSpeech.language = Locale.US
                textToSpeech.setSpeechRate(1.0f)
                ready = true
            }
        }
    }

    suspend fun speak(text: String): Boolean = withContext(Dispatchers.Main) {
        val textToSpeech = engine

        if (text.isBlank() || textToSpeech == null || !ready) {
            return@withContext false
        }

        val result = textToSpeech.speak(
            text,
            TextToSpeech.QUEUE_ADD,
            null,
            "alert-" + UUID.randomUUID().toString()
        )

        result == TextToSpeech.SUCCESS
    }

    fun stop() {
        runCatching { engine?.stop() }
    }

    fun release() {
        runCatching { engine?.stop() }
        runCatching { engine?.shutdown() }
        engine = null
        ready = false
    }

    fun isReady(): Boolean = ready

    private companion object {
        const val TAG = "PhoneVoice"
    }
}
