package com.trendanalyzer.one.voice

import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.secure.VoiceMonkeyCredentialRepository

/**
 * Speaks through the owner's speaker when — and only when — it is switched on, configured, and
 * the month still has room.
 */
class AlexaAnnouncer(
    private val credentials: VoiceMonkeyCredentialRepository,
    private val client: VoiceMonkeyClient,
    private val counter: AlexaCounter,
    private val settings: SettingsRepository
) {

    enum class Result { SENT, SKIPPED_DISABLED, SKIPPED_NO_CREDENTIALS, SKIPPED_QUOTA, FAILED }

    suspend fun announce(speech: String): Result {
        if (speech.isBlank()) return Result.FAILED
        if (!settings.current().alexaEnabled) return Result.SKIPPED_DISABLED

        val stored = credentials.load() ?: return Result.SKIPPED_NO_CREDENTIALS

        if (!counter.tryConsume()) return Result.SKIPPED_QUOTA

        val response = client.announce(stored.token, stored.device, speech)
        return if (response.success) Result.SENT else Result.FAILED
    }
}
