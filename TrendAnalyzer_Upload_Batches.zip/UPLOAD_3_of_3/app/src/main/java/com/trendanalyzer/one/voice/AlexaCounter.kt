package com.trendanalyzer.one.voice

import com.trendanalyzer.one.data.db.dao.AlexaCounterDao
import com.trendanalyzer.one.data.db.entity.AlexaCounterEntity
import com.trendanalyzer.one.time.AppClock
import java.time.Instant
import java.time.ZoneOffset

/**
 * The free announcing plan allows a fixed number of announcements each month. The counter lives
 * in the database so it survives a restart, and it refuses before the limit rather than after.
 */
class AlexaCounter(
    private val dao: AlexaCounterDao,
    private val clock: AppClock,
    private val monthlyLimit: Int = DEFAULT_MONTHLY_LIMIT
) {

    data class Status(
        val monthKey: String,
        val announcements: Int,
        val limit: Int
    ) {
        fun remaining(): Int = (limit - announcements).coerceAtLeast(0)
        fun exhausted(): Boolean = remaining() <= 0
    }

    suspend fun status(): Status {
        val monthKey = currentMonthKey()
        val row = runCatching { dao.get(monthKey) }.getOrNull()

        return Status(
            monthKey = monthKey,
            announcements = row?.announcements ?: 0,
            limit = row?.monthlyLimit ?: monthlyLimit
        )
    }

    /** Reserves one announcement. False means the month is used up; nothing was sent. */
    suspend fun tryConsume(): Boolean {
        val monthKey = currentMonthKey()
        val now = clock.nowMillis()
        val row = runCatching { dao.get(monthKey) }.getOrNull()

        val used = row?.announcements ?: 0
        val limit = row?.monthlyLimit ?: monthlyLimit
        if (used >= limit) return false

        runCatching {
            dao.upsert(
                AlexaCounterEntity(
                    monthKey = monthKey,
                    announcements = used + 1,
                    monthlyLimit = limit,
                    lastAnnouncementAtMillis = now,
                    updatedAtMillis = now
                )
            )
        }.onFailure { return false }

        return true
    }

    fun currentMonthKey(): String {
        val instant = Instant.ofEpochMilli(clock.nowMillis())
        return instant.atZone(ZoneOffset.UTC).toLocalDate().let { date ->
            "${date.year}-${date.monthValue.toString().padStart(2, '0')}"
        }
    }

    companion object {
        const val DEFAULT_MONTHLY_LIMIT = 200
    }
}
