package com.trendanalyzer.one.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.di.ServiceLocator
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.notify.NotifyActions
import com.trendanalyzer.one.util.AppDispatchers
import com.trendanalyzer.one.time.SystemAppClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps the watch alive while the screen is off. It owns nothing but the start and the stop: the
 * feed, the engine and the speakers all live in the service locator.
 */
class MarketWatchService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + AppDispatchers.default)
    private val sessionTracker = WatchSessionTracker(SystemAppClock)
    private val deadManSwitch = DeadManSwitch(SystemAppClock)

    private var started = false
    private var notificationJob: Job? = null
    private var watchdogJob: Job? = null
    private var restoredOnce = false

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.notificationPermission.canPost()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            NotifyActions.ACTION_STOP_WATCH, WatchActions.ACTION_STOP -> {
                stopWatch()
                return START_NOT_STICKY
            }

            else -> startWatch()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopWatchInternal()
        scope.cancel()
        super.onDestroy()
    }

    private fun startWatch() {
        if (started) return
        started = true

        WatchRuntime.markStarting()
        ServiceLocator.notificationChannels.ensure()
        sessionTracker.begin()

        val notification = ServiceLocator.ongoingNotifier.build(null, FeedHealth.UNKNOWN)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }

        ServiceCompat.startForeground(this, AppConfig.WATCH_NOTIFICATION_ID, notification, type)

        ServiceLocator.marketFeed.start()
        ServiceLocator.pipeline.start()
        ServiceLocator.watchRestorePolicy.markWanted(true)

        WatchRuntime.markRunning()

        notificationJob?.cancel()
        notificationJob = scope.launch {
            while (isActive) {
                val snapshot = ServiceLocator.marketFeed.snapshot.value
                ServiceLocator.ongoingNotifier.show(snapshot.lastPrice, snapshot.health)
                WatchRuntime.noteNotification(SystemAppClock.nowMillis())
                delay(NOTIFICATION_REFRESH_MILLIS)
            }
        }

        watchdogJob?.cancel()
        watchdogJob = scope.launch {
            while (isActive) {
                delay(WATCHDOG_INTERVAL_MILLIS)
                checkHealth()
            }
        }

        Logx.d(TAG, "watch started")
    }

    private suspend fun checkHealth() {
        val snapshot = ServiceLocator.marketFeed.snapshot.value
        val deadManEnabled = runCatching {
            ServiceLocator.settingsRepository.current().deadManSwitchEnabled
        }.getOrDefault(false)

        if (!deadManEnabled) return
        if (!deadManSwitch.isSilent(snapshot.atMillis)) return
        if (restoredOnce) return

        restoredOnce = true
        Logx.w(TAG, "price feed went silent; restarting it once")

        runCatching {
            ServiceLocator.marketFeed.stop()
            ServiceLocator.marketFeed.start()
        }

        ServiceLocator.ongoingNotifier.show(snapshot.lastPrice, FeedHealth.STALE)
    }

    private fun stopWatch() {
        WatchRuntime.markStopping()
        stopWatchInternal()
        stopSelf()
    }

    private fun stopWatchInternal() {
        if (!started) {
            WatchRuntime.markStopped()
            return
        }

        started = false
        notificationJob?.cancel()
        watchdogJob?.cancel()
        notificationJob = null
        watchdogJob = null

        runCatching { ServiceLocator.pipeline.stop() }
        runCatching { ServiceLocator.marketFeed.stop() }
        runCatching { ServiceLocator.phoneVoice.stop() }
        ServiceLocator.watchRestorePolicy.markWanted(false)
        sessionTracker.end()

        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        ServiceLocator.ongoingNotifier.hide()

        WatchRuntime.markStopped()
    }

    private companion object {
        const val TAG = "MarketWatchService"
        const val NOTIFICATION_REFRESH_MILLIS = 10_000L
        const val WATCHDOG_INTERVAL_MILLIS = 30_000L
    }
}
