package com.trendanalyzer.one.voice

import com.trendanalyzer.one.engine.AlertEvent
import com.trendanalyzer.one.util.PriceFormat

/**
 * Wording only. The builder never sees a rhythm length or a method name, so the secrecy rule is
 * enforced by what it is given rather than by what it remembers to hide.
 */
object AnnouncementTextBuilder {

    fun title(events: List<AlertEvent>): String {
        if (events.isEmpty()) return "Zone alert"
        if (events.size == 1) return GradeNames.zoneName(events.first().grade, events.first().side)
        return "${events.size} lines in reach"
    }

    fun phoneSpeech(events: List<AlertEvent>, kind: AlertKind): String {
        if (events.isEmpty()) return ""

        val sorted = events.sortedByDescending { it.grade }
        val price = PriceFormat.money(sorted.first().price)

        return when (kind) {
            AlertKind.FIRST -> {
                if (sorted.size == 1) {
                    val event = sorted.first()
                    "Gold is near the ${GradeNames.zoneName(event.grade, event.side)} line. " +
                        "Price $price. Watch your plan."
                } else {
                    val names = joinNames(sorted)
                    "Gold is near $names. Price $price. Watch your plan."
                }
            }

            AlertKind.FOLLOW_UP_FIRST -> {
                val event = sorted.first()
                "Still near the ${GradeNames.zoneName(event.grade, event.side)} line. Price $price."
            }

            AlertKind.FOLLOW_UP_SECOND -> {
                val event = sorted.first()
                "Gold is still near the ${GradeNames.zoneName(event.grade, event.side)} line. " +
                    "Price $price. Same plan."
            }
        }
    }

    fun alexaSpeech(events: List<AlertEvent>, kind: AlertKind): String {
        if (events.isEmpty()) return ""

        val sorted = events.sortedByDescending { it.grade }

        return when (kind) {
            AlertKind.FIRST -> {
                if (sorted.size == 1) {
                    val event = sorted.first()
                    "Gold near ${GradeNames.alexaName(event.grade, event.side)} line."
                } else {
                    val names = sorted.joinToString(" and ") { event ->
                        "${GradeNames.alexaName(event.grade, event.side)} line"
                    }
                    "Gold near $names."
                }
            }

            AlertKind.FOLLOW_UP_FIRST -> {
                val event = sorted.first()
                "Still near ${GradeNames.alexaName(event.grade, event.side)} line."
            }

            AlertKind.FOLLOW_UP_SECOND -> {
                val event = sorted.first()
                "Gold still near ${GradeNames.alexaName(event.grade, event.side)} line."
            }
        }
    }

    fun body(events: List<AlertEvent>): String {
        if (events.isEmpty()) return ""

        val sorted = events.sortedByDescending { it.grade }
        val price = PriceFormat.money(sorted.first().price)

        val names = if (sorted.size == 1) {
            GradeNames.zoneName(sorted.first().grade, sorted.first().side)
        } else {
            joinNames(sorted)
        }

        return "Gold is near $names at $price."
    }

    private fun joinNames(events: List<AlertEvent>): String {
        val names = events.map { GradeNames.zoneName(it.grade, it.side) }
        return when (names.size) {
            1 -> names.first()
            2 -> "${names[0]} and ${names[1]}"
            else -> names.dropLast(1).joinToString(", ") + " and " + names.last()
        }
    }
}
