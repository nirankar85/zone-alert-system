package com.trendanalyzer.one.voice

import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.time.SystemAppClock
import java.util.Calendar

/**
 * The single door to both speakers. Quiet hours are checked here, so no caller can forget them.
 */
class VoiceGateway(
    private val phone: PhoneVoice,
    private val alexa: AlexaAnnouncer,
    private val settings: SettingsRepository,
    private val clock: AppClock = SystemAppClock
) {

    suspend fun announce(phoneText: String, alexaText: String): AnnouncementOutcome {
        val current = settings.current()
        val quiet = current.isQuietAtMinute(localMinuteOfDay())

        if (quiet) {
            return AnnouncementOutcome(phoneSpoken = false, alexaStatus = "quiet hours", quiet = true)
        }

        val spoken = phone.speak(phoneText)
        val alexaResult = alexa.announce(alexaText)

        return AnnouncementOutcome(
            phoneSpoken = spoken,
            alexaStatus = alexaResult.name,
            quiet = false
        )
    }

    fun localMinuteOfDay(): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = clock.nowMillis()
        return calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
    }
}
