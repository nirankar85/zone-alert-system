package com.trendanalyzer.one.notify

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.trendanalyzer.one.MainActivity
import com.trendanalyzer.one.R
import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.service.MarketWatchService
import com.trendanalyzer.one.util.PriceFormat

class OngoingNotifier(
    private val context: Context,
    private val permission: NotificationPermission
) {

    fun build(price: Double?, health: FeedHealth): Notification {
        NotificationChannels.ensure(context)

        val content = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stop = PendingIntent.getService(
            context,
            1,
            Intent(context, MarketWatchService::class.java).setAction(NotifyActions.ACTION_STOP_WATCH),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val priceLine = if (price != null && price > 0.0) "Gold ${PriceFormat.money(price)}" else "Waiting for price"
        val healthLine = when (health) {
            FeedHealth.LIVE -> "watching"
            FeedHealth.STALE -> "price delayed"
            FeedHealth.DOWN -> "price unavailable"
            FeedHealth.UNKNOWN -> "starting"
        }

        return NotificationCompat.Builder(context, AppConfig.WATCH_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle("$priceLine · $healthLine")
            .setContentText("Seven grades are being watched. Alerts speak when a line is in reach.")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(content)
            .addAction(0, "Stop", stop)
            .build()
    }

    fun show(price: Double?, health: FeedHealth) {
        if (!permission.canPost()) return
        runCatching {
            NotificationManagerCompat.from(context)
                .notify(AppConfig.WATCH_NOTIFICATION_ID, build(price, health))
        }
    }

    fun hide() {
        runCatching { NotificationManagerCompat.from(context).cancel(AppConfig.WATCH_NOTIFICATION_ID) }
    }
}
