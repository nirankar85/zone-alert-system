package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.market.Candle
import kotlin.math.max
import kotlin.math.min

/**
 * The carried band. Each candle computes two candidate bands, then keeps the previous band when
 * price has not broken it, which is what makes the line hold its place and then jump when a close
 * crosses the opposite band. Direction flips only on a close, never on a wick.
 */
object LineEngine {

    fun compute(
        candles: List<Candle>,
        period: Int,
        multiplier: Double,
        smoothing: AtrSmoothing
    ): List<LinePoint> {
        if (candles.size < 2) return emptyList()

        val atr = Atr.series(candles, period, smoothing)
        val upper = DoubleArray(candles.size)
        val lower = DoubleArray(candles.size)
        val sides = arrayOfNulls<LineSide>(candles.size)
        val flips = BooleanArray(candles.size)

        var lastIndex = -1

        for (index in candles.indices) {
            val average = atr[index]
            if (average <= 0.0) continue

            val candle = candles[index]
            val midpoint = (candle.high + candle.low) / 2.0

            var upperBand = midpoint + multiplier * average
            var lowerBand = midpoint - multiplier * average

            if (lastIndex < 0) {
                upper[index] = upperBand
                lower[index] = lowerBand
                sides[index] = if (candle.close >= midpoint) LineSide.BUYER else LineSide.SELLER
                lastIndex = index
                continue
            }

            val previousUpper = upper[lastIndex]
            val previousLower = lower[lastIndex]
            val previousSide = sides[lastIndex] ?: LineSide.BUYER
            val previousClose = candles[lastIndex].close

            if (previousClose > previousUpper) upperBand = max(upperBand, previousUpper)
            if (previousClose < previousLower) lowerBand = min(lowerBand, previousLower)

            val side = when {
                candle.close > previousUpper -> LineSide.BUYER
                candle.close < previousLower -> LineSide.SELLER
                else -> previousSide
            }

            upper[index] = upperBand
            lower[index] = lowerBand
            sides[index] = side
            flips[index] = side != previousSide
            lastIndex = index
        }

        val points = ArrayList<LinePoint>(candles.size)

        for (index in candles.indices) {
            val side = sides[index] ?: continue
            val line = if (side == LineSide.BUYER) lower[index] else upper[index]
            if (!line.isFinite() || line <= 0.0) continue

            points.add(
                LinePoint(
                    openTimeMillis = candles[index].openTimeMillis,
                    line = line,
                    side = side,
                    flipped = flips[index],
                    close = candles[index].close
                )
            )
        }

        return points
    }

    fun latest(
        candles: List<Candle>,
        period: Int,
        multiplier: Double,
        smoothing: AtrSmoothing
    ): LinePoint? = compute(candles, period, multiplier, smoothing).lastOrNull()
}
