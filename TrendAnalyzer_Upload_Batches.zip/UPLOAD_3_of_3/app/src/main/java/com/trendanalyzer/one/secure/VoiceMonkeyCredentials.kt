package com.trendanalyzer.one.secure

/** What the owner pastes once. Never logged, never shown again, never sent anywhere but the service. */
data class VoiceMonkeyCredentials(
    val token: String,
    val device: String
) {
    fun isComplete(): Boolean = token.isNotBlank() && device.isNotBlank()
}
