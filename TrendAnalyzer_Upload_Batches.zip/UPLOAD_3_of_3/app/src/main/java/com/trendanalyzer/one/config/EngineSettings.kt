package com.trendanalyzer.one.config

enum class AtrSmoothing { SMA, RMA }

enum class CandleSource { CLOSE, HL2 }

/**
 * The owner's tuning. Every field has a default that is usable without any setup.
 *
 * E-01: smoothing defaults to a simple average. TradingView's built-in indicator smooths with
 * RMA, so the owner may need to switch it before the lines agree bar for bar.
 */
data class EngineSettings(
    val alertDistancePoints: Double = 5.0,
    val rearmDistancePoints: Double = 10.0,
    val cooldownSeconds: Int = 60,
    val minGrade: Int = 4,
    val followUpsEnabled: Boolean = true,
    val followUpFirstSeconds: Int = 180,
    val followUpSecondSeconds: Int = 1800,
    val quietHoursEnabled: Boolean = true,
    val quietHoursStartMinute: Int = 22 * 60,
    val quietHoursEndMinute: Int = 7 * 60,
    val alexaEnabled: Boolean = false,
    val tickerFallbackEnabled: Boolean = true,
    val deadManSwitchEnabled: Boolean = false,
    val chartTimeframe: String = "5m",
    val atrSmoothing: AtrSmoothing = AtrSmoothing.SMA,
    val candleSource: CandleSource = CandleSource.CLOSE,
    val disabledZoneIds: Set<String> = emptySet()
) {

    fun isZoneEnabled(zoneId: String): Boolean = zoneId !in disabledZoneIds

    /** True when the local minute-of-day falls inside the quiet window, including a window that crosses midnight. */
    fun isQuietAtMinute(minuteOfDay: Int): Boolean {
        if (!quietHoursEnabled) return false
        if (quietHoursStartMinute == quietHoursEndMinute) return false

        return if (quietHoursStartMinute < quietHoursEndMinute) {
            minuteOfDay >= quietHoursStartMinute && minuteOfDay < quietHoursEndMinute
        } else {
            minuteOfDay >= quietHoursStartMinute || minuteOfDay < quietHoursEndMinute
        }
    }

    fun sanitized(): EngineSettings = copy(
        alertDistancePoints = alertDistancePoints.coerceIn(0.1, 1_000.0),
        rearmDistancePoints = rearmDistancePoints.coerceIn(0.1, 1_000.0),
        cooldownSeconds = cooldownSeconds.coerceIn(10, 3_600),
        minGrade = minGrade.coerceIn(1, 7),
        followUpFirstSeconds = followUpFirstSeconds.coerceIn(30, 7_200),
        followUpSecondSeconds = followUpSecondSeconds.coerceIn(30, 7_200),
        quietHoursStartMinute = quietHoursStartMinute.coerceIn(0, 1_439),
        quietHoursEndMinute = quietHoursEndMinute.coerceIn(0, 1_439),
        chartTimeframe = if (ChartTimeframes.isVisible(chartTimeframe)) chartTimeframe else "5m",
        disabledZoneIds = disabledZoneIds.filter { it.matches(Regex("Z[1-7]")) }.toSet()
    )
}
