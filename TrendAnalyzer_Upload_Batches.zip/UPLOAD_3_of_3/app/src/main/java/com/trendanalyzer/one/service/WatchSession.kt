package com.trendanalyzer.one.service

import com.trendanalyzer.one.time.AppClock

data class WatchSession(
    val startedAtMillis: Long
)

class WatchSessionTracker(private val clock: AppClock) {

    private var session: WatchSession? = null

    fun begin(): WatchSession {
        val started = WatchSession(clock.nowMillis())
        session = started
        return started
    }

    fun end(): WatchSession? {
        val finished = session
        session = null
        return finished
    }

    fun current(): WatchSession? = session

    fun isActive(): Boolean = session != null
}
