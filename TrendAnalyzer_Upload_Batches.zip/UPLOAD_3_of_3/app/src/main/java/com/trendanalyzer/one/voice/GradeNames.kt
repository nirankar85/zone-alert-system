package com.trendanalyzer.one.voice

import com.trendanalyzer.one.engine.LineSide

/**
 * The only names a client ever hears or reads for a watched rhythm. No rhythm length, no setting,
 * no method name: just the grade and who is expected there.
 */
object GradeNames {

    fun zoneName(grade: Int, side: LineSide): String {
        val who = if (side == LineSide.BUYER) "Institutional Buyer" else "Institutional Seller"
        return "${ordinal(grade)} Grade $who"
    }

    fun shortName(grade: Int, side: LineSide): String {
        val who = if (side == LineSide.BUYER) "buyer" else "seller"
        return "${ordinal(grade).lowercase()} grade institutional $who"
    }

    fun ordinal(grade: Int): String = when (grade.coerceIn(1, 7)) {
        1 -> "1st"
        2 -> "2nd"
        3 -> "3rd"
        4 -> "4th"
        5 -> "5th"
        6 -> "6th"
        else -> "7th"
    }

    fun alexaName(grade: Int, side: LineSide): String {
        val who = if (side == LineSide.BUYER) "institutional buyer" else "institutional seller"
        return "${ordinal(grade).lowercase()} grade $who"
    }
}
