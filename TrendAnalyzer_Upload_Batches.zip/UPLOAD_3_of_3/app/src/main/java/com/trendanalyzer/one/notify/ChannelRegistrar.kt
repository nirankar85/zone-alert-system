package com.trendanalyzer.one.notify

import android.content.Context

/** Small wrapper so callers do not need to carry a context just to create channels. */
class ChannelRegistrar(private val context: Context) {
    fun ensure() = NotificationChannels.ensure(context)
}
