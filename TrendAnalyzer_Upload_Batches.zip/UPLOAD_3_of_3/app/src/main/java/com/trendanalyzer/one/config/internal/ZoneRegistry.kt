package com.trendanalyzer.one.config.internal

import com.trendanalyzer.one.config.CandleSource

internal object ZoneRegistry {

    val all: List<ZoneSpec> = listOf(
        ZoneSpec("Z7", 7, "1d", 10, 1.0, CandleSource.CLOSE, bucketed = false),
        ZoneSpec("Z6", 6, "4h", 10, 3.0, CandleSource.CLOSE, bucketed = false),
        ZoneSpec("Z5", 5, "2h", 10, 3.0, CandleSource.CLOSE, bucketed = false),
        ZoneSpec("Z4", 4, "1h", 10, 3.0, CandleSource.CLOSE, bucketed = false),
        ZoneSpec("Z3", 3, "45m", 10, 3.0, CandleSource.CLOSE, bucketed = true),
        ZoneSpec("Z2", 2, "30m", 10, 3.0, CandleSource.CLOSE, bucketed = false),
        ZoneSpec("Z1", 1, "15m", 10, 3.0, CandleSource.CLOSE, bucketed = false)
    )

    fun byId(zoneId: String): ZoneSpec? = all.firstOrNull { it.id == zoneId }
}
