package com.trendanalyzer.one.engine

import com.trendanalyzer.one.market.Candle

enum class LineSide { BUYER, SELLER }

enum class AlertPhase { ARMED, COOLDOWN }

/** One drawn line, on one candle. */
data class LinePoint(
    val openTimeMillis: Long,
    val line: Double,
    val side: LineSide,
    val flipped: Boolean,
    val close: Double
)

/** The newest line for a watched rhythm. */
data class ZoneReading(
    val zoneId: String,
    val grade: Int,
    val side: LineSide,
    val line: Double,
    val close: Double,
    val atr: Double,
    val atMillis: Long
) {
    fun isValid(): Boolean = line.isFinite() && line > 0.0 && close.isFinite() && close > 0.0
}

/** Something worth saying, before the speaker decides how to say it. */
data class AlertEvent(
    val zoneId: String,
    val grade: Int,
    val side: LineSide,
    val lineValue: Double,
    val price: Double,
    val atMillis: Long,
    val distance: Double
)

data class AlertDecision(
    val state: ZoneRuntimeState,
    val event: AlertEvent?
)

/** A candle that has not closed yet. */
fun Candle.isForming(nowMillis: Long, durationMillis: Long): Boolean =
    nowMillis < openTimeMillis + durationMillis
