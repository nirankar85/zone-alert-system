package com.trendanalyzer.one.engine

/**
 * Several rhythms can reach price in the same breath. A short window folds them into one
 * announcement instead of five, which is the difference between a useful alert and noise.
 */
class AlertGrouper(private val windowMillis: Long = 3_000L) {

    private val pending = mutableListOf<AlertEvent>()
    private var openedAtMillis = 0L

    @Synchronized
    fun add(event: AlertEvent, nowMillis: Long): Boolean {
        if (pending.isEmpty()) openedAtMillis = nowMillis
        pending.add(event)
        return pending.size == 1
    }

    @Synchronized
    fun readyToFlush(nowMillis: Long): Boolean {
        if (pending.isEmpty()) return false
        return nowMillis - openedAtMillis >= windowMillis
    }

    @Synchronized
    fun flush(): List<AlertEvent> {
        val flushed = pending.toList()
        pending.clear()
        openedAtMillis = 0L
        return flushed
    }

    @Synchronized
    fun isEmpty(): Boolean = pending.isEmpty()

    @Synchronized
    fun size(): Int = pending.size
}
