package com.trendanalyzer.one.secure

/** Stores the two strings the owner gets from the announcing service. */
class VoiceMonkeyCredentialRepository(private val store: SecretStore) {

    suspend fun save(credentials: VoiceMonkeyCredentials) {
        if (!credentials.isComplete()) return
        store.put(KEY_TOKEN, credentials.token.trim())
        store.put(KEY_DEVICE, credentials.device.trim())
    }

    suspend fun load(): VoiceMonkeyCredentials? {
        val token = store.get(KEY_TOKEN)?.trim().orEmpty()
        val device = store.get(KEY_DEVICE)?.trim().orEmpty()
        val credentials = VoiceMonkeyCredentials(token, device)
        return credentials.takeIf { it.isComplete() }
    }

    suspend fun clear() {
        store.remove(KEY_TOKEN)
        store.remove(KEY_DEVICE)
    }

    suspend fun isConfigured(): Boolean = load() != null

    private companion object {
        const val KEY_TOKEN = "voicemonkey_token"
        const val KEY_DEVICE = "voicemonkey_device"
    }
}
