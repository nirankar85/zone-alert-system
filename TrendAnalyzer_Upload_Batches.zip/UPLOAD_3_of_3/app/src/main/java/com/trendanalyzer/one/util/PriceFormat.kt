package com.trendanalyzer.one.util

import java.util.Locale

object PriceFormat {

    fun money(value: Double): String = String.format(Locale.US, "%,.2f", value)

    fun points(value: Double): String = String.format(Locale.US, "%.2f", value)

    fun signedPoints(value: Double): String {
        val formatted = String.format(Locale.US, "%.2f", kotlin.math.abs(value))
        return if (value < 0) "-$formatted" else "+$formatted"
    }

    fun clockTime(millis: Long): String = String.format(Locale.US, "%02d:%02d", (millis / 60000) % 1440 / 60, (millis / 60000) % 60)
}
