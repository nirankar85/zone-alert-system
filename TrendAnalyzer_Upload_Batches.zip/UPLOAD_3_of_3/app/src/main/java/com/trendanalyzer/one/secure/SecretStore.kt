package com.trendanalyzer.one.secure

/** The only way this app stores a secret: encrypted, backed by the device keystore. */
interface SecretStore {
    fun put(key: String, value: String)
    fun get(key: String): String?
    fun remove(key: String)
    fun has(key: String): Boolean
}
