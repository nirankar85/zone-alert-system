package com.trendanalyzer.one.engine

import com.trendanalyzer.one.data.db.dao.ZoneStateDao
import com.trendanalyzer.one.time.AppClock

/** Where the engine's memory of each rhythm lives. */
interface AlertStateStore {
    suspend fun loadAll(): Map<String, ZoneRuntimeState>
    suspend fun load(zoneId: String): ZoneRuntimeState
    suspend fun save(state: ZoneRuntimeState)
}

class RoomAlertStateStore(
    private val dao: ZoneStateDao,
    private val clock: AppClock
) : AlertStateStore {

    override suspend fun loadAll(): Map<String, ZoneRuntimeState> =
        runCatching { dao.all() }.getOrDefault(emptyList())
            .associate { entity -> entity.zoneId to ZoneRuntimeState.fromEntity(entity) }

    override suspend fun load(zoneId: String): ZoneRuntimeState {
        val entity = runCatching { dao.get(zoneId) }.getOrNull()
        return entity?.let { ZoneRuntimeState.fromEntity(it) } ?: ZoneRuntimeState.initial(zoneId)
    }

    override suspend fun save(state: ZoneRuntimeState) {
        runCatching { dao.upsert(state.toEntity(clock.nowMillis())) }
    }
}
