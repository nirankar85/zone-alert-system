package com.trendanalyzer.one.config.internal

import com.trendanalyzer.one.config.CandleSource

/**
 * One watched rhythm. Package-internal and deliberately absent from every keep rule: a release
 * build renames these fields and inlines the constants.
 */
internal data class ZoneSpec(
    val id: String,
    val grade: Int,
    val timeframe: String,
    val atrPeriod: Int,
    val multiplier: Double,
    val source: CandleSource,
    val bucketed: Boolean
)
