package com.trendanalyzer.one.notify

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.trendanalyzer.one.MainActivity
import com.trendanalyzer.one.R
import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.log.Logx

class AlertNotifier(
    private val context: Context,
    private val permission: NotificationPermission
) {

    fun post(title: String, body: String, fullScreen: Boolean): Boolean {
        if (!permission.canPost()) return false
        if (title.isBlank() && body.isBlank()) return false

        return runCatching {
            NotificationChannels.ensure(context)

            val contentIntent = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, AppConfig.ALERT_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_alert)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(contentIntent)
                .setOnlyAlertOnce(false)

            if (fullScreen) {
                builder.setFullScreenIntent(contentIntent, true)
            }

            NotificationManagerCompat.from(context)
                .notify(ALERT_NOTIFICATION_ID, builder.build())

            true
        }.getOrElse { error ->
            Logx.w(TAG, "alert notification failed: ${error::class.java.simpleName}")
            false
        }
    }

    fun cancel() {
        runCatching { NotificationManagerCompat.from(context).cancel(ALERT_NOTIFICATION_ID) }
    }

    private companion object {
        const val TAG = "AlertNotifier"
        const val ALERT_NOTIFICATION_ID = 1002
    }
}
