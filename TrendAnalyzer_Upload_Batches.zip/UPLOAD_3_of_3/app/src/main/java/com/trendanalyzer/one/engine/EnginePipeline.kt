package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.config.internal.ZoneRegistry
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.market.MarketFeed
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.util.DispatchersProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * The loop that watches every enabled rhythm. It asks for candles, keeps the newest line, lets the
 * alert engine decide, and hands anything worth saying to the dispatcher. A rhythm that fails is
 * skipped for that turn; one bad line never stops the watch.
 */
class EnginePipeline(
    private val feed: MarketFeed,
    private val settings: SettingsRepository,
    private val zoneEngine: ZoneEngine,
    private val alertEngine: AlertEngine,
    private val stateStore: AlertStateStore,
    private val dispatcher: AlertDispatcher,
    private val clock: AppClock,
    private val dispatchers: DispatchersProvider,
    private val allowedGrades: suspend () -> Set<Int>? = { null }
) {

    private val scope = CoroutineScope(SupervisorJob() + dispatchers.default)
    private val zoneReadings = ConcurrentHashMap<String, ZoneReading>()
    private val states = ConcurrentHashMap<String, ZoneRuntimeState>()

    private val _zones = MutableStateFlow<List<ZoneReading>>(emptyList())
    val zones: StateFlow<List<ZoneReading>> = _zones.asStateFlow()

    private var job: Job? = null

    fun start() {
        if (job != null) return
        job = scope.launch {
            while (scope.isActive) {
                runCatching { evaluateOnce() }
                    .onFailure { Logx.w(TAG, "engine turn failed: ${it::class.java.simpleName}") }
                delay(LOOP_INTERVAL_MILLIS)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        dispatcher.cancelPending()
    }

    fun reading(zoneId: String): ZoneReading? = zoneReadings[zoneId]

    fun price(): Double? = feed.snapshot.value.lastPrice

    suspend fun evaluateOnce() {
        val current = settings.current()
        val price = feed.snapshot.value.lastPrice ?: return
        if (price <= 0.0) return

        val now = clock.nowMillis()
        val readings = ArrayList<ZoneReading>(ZoneRegistry.all.size)

        // Fail closed: if the account cannot be read, this phone speaks nothing rather than
        // leaking a grade above the client's plan.
        val visible = runCatching { allowedGrades() }.getOrDefault(emptySet())

        for (spec in ZoneRegistry.all) {
            if (visible != null && spec.grade !in visible) continue
            if (!current.isZoneEnabled(spec.id)) continue

            val candles = runCatching { feed.candles(spec.timeframe, CANDLE_LIMIT) }
                .getOrElse { error ->
                    Logx.w(TAG, "no candles for ${spec.id}: ${error::class.java.simpleName}")
                    emptyList()
                }

            if (candles.size < spec.atrPeriod + 2) continue

            val reading = runCatching { zoneEngine.evaluate(spec, candles, current.atrSmoothing) }
                .getOrNull() ?: continue

            zoneReadings[spec.id] = reading
            readings.add(reading)

            val state = states[spec.id]
                ?: runCatching { stateStore.load(spec.id) }
                    .getOrElse { ZoneRuntimeState.initial(spec.id) }

            val decision = alertEngine.decide(reading, price, current, state)
            states[spec.id] = decision.state

            if (decision.state != state) {
                runCatching { stateStore.save(decision.state) }
            }

            decision.event?.let { event -> dispatcher.submit(event) }
        }

        _zones.value = readings.sortedByDescending { it.grade }

        if (readings.isEmpty() && now > 0L) {
            Logx.d(TAG, "no usable lines yet; the watch is still warming up")
        }
    }

    private companion object {
        const val TAG = "EnginePipeline"
        const val LOOP_INTERVAL_MILLIS = 3_000L
        const val CANDLE_LIMIT = 300
    }
}
