package com.trendanalyzer.one.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class WatchStatus { STOPPED, STARTING, RUNNING, STOPPING }

object WatchActions {
    const val ACTION_START = "com.trendanalyzer.one.action.START_WATCH"
    const val ACTION_STOP = "com.trendanalyzer.one.action.STOP_WATCH"
}

/**
 * Process-wide watch state. Screens read it; the service is the only writer. It is explicitly not
 * the source of truth after a restart — the restore policy decides that from what it saved.
 */
object WatchRuntime {

    private val _status = MutableStateFlow(WatchStatus.STOPPED)
    val status: StateFlow<WatchStatus> = _status.asStateFlow()

    private val _lastNotificationAtMillis = MutableStateFlow(0L)
    val lastNotificationAtMillis: StateFlow<Long> = _lastNotificationAtMillis.asStateFlow()

    fun markStarting() {
        _status.value = WatchStatus.STARTING
    }

    fun markRunning() {
        _status.value = WatchStatus.RUNNING
    }

    fun markStopping() {
        _status.value = WatchStatus.STOPPING
    }

    fun markStopped() {
        _status.value = WatchStatus.STOPPED
    }

    fun noteNotification(atMillis: Long) {
        _lastNotificationAtMillis.value = atMillis
    }
}
