package com.trendanalyzer.one.config

import com.trendanalyzer.one.data.db.dao.SettingsDao
import com.trendanalyzer.one.data.db.entity.SettingsEntity
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.time.SystemAppClock
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first

/**
 * Owner settings live in one key/value table and are applied over the compiled defaults, so
 * adding a setting never changes the database version. Every setter clamps its input: a screen
 * cannot store a value the engine would choke on.
 */
class SettingsRepository(
    private val dao: SettingsDao,
    private val clock: AppClock = SystemAppClock
) {

    private val overrides = MutableStateFlow<Map<String, String>>(emptyMap())
    private val loaded = MutableStateFlow(false)

    val engineSettings: Flow<EngineSettings> =
        combine(overrides, loaded) { values, isLoaded ->
            if (!isLoaded) EngineSettings() else build(values)
        }.distinctUntilChanged()

    suspend fun current(): EngineSettings = engineSettings.first()

    suspend fun load() {
        val rows = runCatching { dao.all() }.getOrDefault(emptyList())
        overrides.value = rows.associate { it.settingKey to it.settingValue }
        loaded.value = true
    }

    suspend fun setAlertDistance(value: Double) =
        put(KEY_ALERT_DISTANCE, clamp(value, MIN_DISTANCE, MAX_DISTANCE).toString())

    suspend fun setRearmDistance(value: Double) =
        put(KEY_REARM_DISTANCE, clamp(value, MIN_DISTANCE, MAX_DISTANCE).toString())

    suspend fun setCooldownSeconds(value: Int) =
        put(KEY_COOLDOWN, value.coerceIn(MIN_COOLDOWN, MAX_COOLDOWN).toString())

    suspend fun setMinGrade(value: Int) = put(KEY_MIN_GRADE, value.coerceIn(1, 7).toString())

    suspend fun setFollowUpsEnabled(enabled: Boolean) = put(KEY_FOLLOW_UPS, enabled.toString())

    suspend fun setFollowUpFirstSeconds(value: Int) =
        put(KEY_FOLLOW_FIRST, value.coerceIn(MIN_FOLLOW_UP, MAX_FOLLOW_UP).toString())

    suspend fun setFollowUpSecondSeconds(value: Int) =
        put(KEY_FOLLOW_SECOND, value.coerceIn(MIN_FOLLOW_UP, MAX_FOLLOW_UP).toString())

    suspend fun setZoneEnabled(zoneId: String, enabled: Boolean) =
        put(zoneKey(zoneId), enabled.toString())

    suspend fun setAlexaEnabled(enabled: Boolean) = put(KEY_ALEXA, enabled.toString())

    suspend fun setTickerFallbackEnabled(enabled: Boolean) = put(KEY_TICKER_FALLBACK, enabled.toString())

    suspend fun setDeadManSwitchEnabled(enabled: Boolean) = put(KEY_DEAD_MAN, enabled.toString())

    suspend fun setQuietHoursEnabled(enabled: Boolean) = put(KEY_QUIET_ENABLED, enabled.toString())

    suspend fun setQuietHours(startMinute: Int, endMinute: Int) {
        put(KEY_QUIET_START, startMinute.coerceIn(0, MINUTES_PER_DAY - 1).toString())
        put(KEY_QUIET_END, endMinute.coerceIn(0, MINUTES_PER_DAY - 1).toString())
    }

    suspend fun setChartTimeframe(timeframe: String) = put(KEY_CHART_TIMEFRAME, timeframe)

    suspend fun setAtrSmoothing(smoothing: AtrSmoothing) = put(KEY_SMOOTHING, smoothing.name)

    private suspend fun put(key: String, value: String) {
        overrides.value = overrides.value + (key to value)
        runCatching {
            dao.upsert(
                SettingsEntity(
                    settingKey = key,
                    settingValue = value,
                    updatedAtMillis = clock.nowMillis()
                )
            )
        }.onFailure { Logx.w(TAG, "setting write failed: ${it::class.java.simpleName}") }
    }

    private fun build(values: Map<String, String>): EngineSettings {
        val defaults = EngineSettings()

        return defaults.copy(
            alertDistancePoints = values[KEY_ALERT_DISTANCE]?.toDoubleOrNull()
                ?.let { clamp(it, MIN_DISTANCE, MAX_DISTANCE) } ?: defaults.alertDistancePoints,
            rearmDistancePoints = values[KEY_REARM_DISTANCE]?.toDoubleOrNull()
                ?.let { clamp(it, MIN_DISTANCE, MAX_DISTANCE) } ?: defaults.rearmDistancePoints,
            cooldownSeconds = values[KEY_COOLDOWN]?.toIntOrNull()
                ?.coerceIn(MIN_COOLDOWN, MAX_COOLDOWN) ?: defaults.cooldownSeconds,
            minGrade = values[KEY_MIN_GRADE]?.toIntOrNull()?.coerceIn(1, 7) ?: defaults.minGrade,
            followUpsEnabled = values[KEY_FOLLOW_UPS]?.toBooleanStrictOrNull()
                ?: defaults.followUpsEnabled,
            followUpFirstSeconds = values[KEY_FOLLOW_FIRST]?.toIntOrNull()
                ?.coerceIn(MIN_FOLLOW_UP, MAX_FOLLOW_UP) ?: defaults.followUpFirstSeconds,
            followUpSecondSeconds = values[KEY_FOLLOW_SECOND]?.toIntOrNull()
                ?.coerceIn(MIN_FOLLOW_UP, MAX_FOLLOW_UP) ?: defaults.followUpSecondSeconds,
            alexaEnabled = values[KEY_ALEXA]?.toBooleanStrictOrNull() ?: defaults.alexaEnabled,
            quietHoursEnabled = values[KEY_QUIET_ENABLED]?.toBooleanStrictOrNull()
                ?: defaults.quietHoursEnabled,
            quietHoursStartMinute = values[KEY_QUIET_START]?.toIntOrNull()
                ?.coerceIn(0, MINUTES_PER_DAY - 1) ?: defaults.quietHoursStartMinute,
            quietHoursEndMinute = values[KEY_QUIET_END]?.toIntOrNull()
                ?.coerceIn(0, MINUTES_PER_DAY - 1) ?: defaults.quietHoursEndMinute,
            tickerFallbackEnabled = values[KEY_TICKER_FALLBACK]?.toBooleanStrictOrNull()
                ?: defaults.tickerFallbackEnabled,
            deadManSwitchEnabled = values[KEY_DEAD_MAN]?.toBooleanStrictOrNull()
                ?: defaults.deadManSwitchEnabled,
            chartTimeframe = values[KEY_CHART_TIMEFRAME]?.takeIf { ChartTimeframes.isVisible(it) }
                ?: defaults.chartTimeframe,
            atrSmoothing = values[KEY_SMOOTHING]
                ?.let { runCatching { AtrSmoothing.valueOf(it) }.getOrNull() }
                ?: defaults.atrSmoothing,
            disabledZoneIds = values
                .filterKeys { it.startsWith(ZONE_PREFIX) }
                .filterValues { it.toBooleanStrictOrNull() == false }
                .keys
                .mapNotNull { it.removePrefix(ZONE_PREFIX).takeIf { id -> id.matches(Regex("Z[1-7]")) } }
                .toSet()
        )
    }

    private fun clamp(value: Double, min: Double, max: Double): Double = value.coerceIn(min, max)

    private fun zoneKey(zoneId: String): String = ZONE_PREFIX + zoneId

    private companion object {
        const val TAG = "SettingsRepository"

        const val KEY_ALERT_DISTANCE = "alert_distance"
        const val KEY_REARM_DISTANCE = "rearm_distance"
        const val KEY_COOLDOWN = "cooldown_seconds"
        const val KEY_MIN_GRADE = "min_grade"
        const val KEY_FOLLOW_UPS = "follow_ups"
        const val KEY_FOLLOW_FIRST = "follow_first"
        const val KEY_FOLLOW_SECOND = "follow_second"
        const val KEY_ALEXA = "alexa_enabled"
        const val KEY_QUIET_ENABLED = "quiet_enabled"
        const val KEY_QUIET_START = "quiet_start"
        const val KEY_QUIET_END = "quiet_end"
        const val KEY_TICKER_FALLBACK = "ticker_fallback"
        const val KEY_DEAD_MAN = "dead_man"
        const val KEY_CHART_TIMEFRAME = "chart_timeframe"
        const val KEY_SMOOTHING = "atr_smoothing"
        const val ZONE_PREFIX = "zone_disabled_"

        const val MIN_DISTANCE = 0.1
        const val MAX_DISTANCE = 1_000.0
        const val MIN_COOLDOWN = 10
        const val MAX_COOLDOWN = 3_600
        const val MIN_FOLLOW_UP = 30
        const val MAX_FOLLOW_UP = 7_200
        const val MINUTES_PER_DAY = 1_440
    }
}
