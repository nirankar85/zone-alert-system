package com.trendanalyzer.one.service

import android.content.Context

/**
 * Whether the watch should come back by itself. Only a watch the owner started is restored; an
 * install never starts speaking on its own.
 */
class WatchRestorePolicy(context: Context) {

    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun markWanted(wanted: Boolean) {
        preferences.edit().putBoolean(KEY_WANTED, wanted).commit()
    }

    fun wasRunning(): Boolean = preferences.getBoolean(KEY_WANTED, false)

    private companion object {
        const val PREFERENCES_NAME = "trend_analyzer_watch"
        const val KEY_WANTED = "watch_wanted"
    }
}
