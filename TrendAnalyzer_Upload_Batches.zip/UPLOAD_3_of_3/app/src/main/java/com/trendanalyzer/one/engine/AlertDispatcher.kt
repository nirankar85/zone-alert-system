package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.notify.AlertHistoryRecorder
import com.trendanalyzer.one.notify.AlertNotifier
import com.trendanalyzer.one.notify.FullScreenIntentPolicy
import com.trendanalyzer.one.notify.NotificationPermission
import com.trendanalyzer.one.notify.NotificationTexts
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.util.DispatchersProvider
import com.trendanalyzer.one.voice.AlertKind
import com.trendanalyzer.one.voice.AnnouncementTextBuilder
import com.trendanalyzer.one.voice.VoiceGateway
import com.trendanalyzer.one.voice.VoiceHealth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.abs

/**
 * Turns a burst of line events into one announcement, a notification, a voice message and a
 * history row. Follow-ups are scheduled here because they depend on what happens next, not on
 * what happened at the moment of the alert.
 */
class AlertDispatcher(
    private val grouper: AlertGrouper,
    private val voice: VoiceGateway,
    private val notifier: AlertNotifier,
    private val permission: NotificationPermission,
    private val history: AlertHistoryRecorder,
    private val settings: SettingsRepository,
    private val clock: AppClock,
    private val dispatchers: DispatchersProvider,
    private val voiceHealth: VoiceHealth,
    private val latestReading: (String) -> ZoneReading?,
    private val latestPrice: () -> Double?
) {

    private val scope = CoroutineScope(SupervisorJob() + dispatchers.default)
    private var flushJob: Job? = null
    private var followUpJob: Job? = null

    fun submit(event: AlertEvent) {
        val opened = grouper.add(event, clock.nowMillis())
        if (!opened) return

        flushJob?.cancel()
        flushJob = scope.launch {
            delay(GROUPING_WINDOW_MILLIS)
            flushNow()
        }
    }

    suspend fun flushNow() {
        if (grouper.isEmpty()) return
        val events = grouper.flush()
        if (events.isEmpty()) return

        speak(events, AlertKind.FIRST)
        scheduleFollowUps(events.first())
    }

    /** Silences anything already queued when the watch stops. */
    fun cancelPending() {
        flushJob?.cancel()
        flushJob = null
        followUpJob?.cancel()
        followUpJob = null
        grouper.flush()
    }

    fun shutdown() {
        cancelPending()
        scope.cancel()
    }

    private fun scheduleFollowUps(leader: AlertEvent) {
        followUpJob?.cancel()
        followUpJob = scope.launch {
            val current = settings.current()
            if (!current.followUpsEnabled) return@launch

            delay(current.followUpFirstSeconds.toLong() * 1_000L)

            val first = stillNear(leader, current.alertDistancePoints, current.alexaEnabled)
            if (first != null) speak(listOf(first), AlertKind.FOLLOW_UP_FIRST)

            val secondDelay = (current.followUpSecondSeconds - current.followUpFirstSeconds)
                .coerceAtLeast(0).toLong() * 1_000L
            delay(secondDelay)

            val second = stillNear(leader, current.alertDistancePoints, current.alexaEnabled)
            if (second != null) speak(listOf(second), AlertKind.FOLLOW_UP_SECOND)
        }
    }

    private fun stillNear(leader: AlertEvent, distancePoints: Double, alexaEnabled: Boolean): AlertEvent? {
        val reading = latestReading(leader.zoneId) ?: return null
        val price = latestPrice() ?: return null

        if (reading.side != leader.side) return null
        val distance = abs(price - reading.line)
        if (distance > distancePoints) return null

        return AlertEvent(
            zoneId = reading.zoneId,
            grade = reading.grade,
            side = reading.side,
            lineValue = reading.line,
            price = price,
            atMillis = clock.nowMillis(),
            distance = distance
        )
    }

    private suspend fun speak(events: List<AlertEvent>, kind: AlertKind) {
        val current = settings.current()
        val quiet = current.isQuietAtMinute(localMinuteOfDay())

        val title = NotificationTexts.title(events)
        val body = NotificationTexts.body(events)
        val phoneText = AnnouncementTextBuilder.phoneSpeech(events, kind)
        val alexaText = AnnouncementTextBuilder.alexaSpeech(events, kind)

        val fullScreen = FullScreenIntentPolicy.allows(permission.canUseFullScreen(), quiet)
        val notified = notifier.post(title, body, fullScreen)

        val outcome = voice.announce(phoneText, alexaText)
        voiceHealth.recordPhone(ready = true, spoken = outcome.phoneSpoken)
        voiceHealth.recordAlexa(outcome.alexaStatus)

        history.record(
            events = events,
            kind = kind,
            title = title,
            body = body,
            speech = phoneText,
            notified = notified,
            spoken = outcome.phoneSpoken,
            alexaStatus = outcome.alexaStatus
        )
    }

    private fun localMinuteOfDay(): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = clock.nowMillis()
        return calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
    }

    private companion object {
        const val GROUPING_WINDOW_MILLIS = 3_000L
    }
}
