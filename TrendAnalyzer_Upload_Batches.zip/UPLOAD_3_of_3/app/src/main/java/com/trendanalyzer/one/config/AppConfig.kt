package com.trendanalyzer.one.config

object AppConfig {

    const val SYMBOL = "XAUTUSD"

    const val REST_BASE_URL = "https://api.india.delta.exchange"
    const val WS_URL = "wss://socket.india.delta.exchange"

    const val SUPPORT_WHATSAPP_E164 = "+919434387482"

    const val CLIENT_EMAIL_DOMAIN = "clients.trendanalyzer1pct.app"

    const val MAX_CANDLES_PER_REQUEST = 2000
    const val CANDLE_STORE_LIMIT = 3000

    const val RATE_LIMIT_FALLBACK_SECONDS = 300L

    const val WATCH_CHANNEL_ID = "watch_running"
    const val ALERT_CHANNEL_ID = "zone_alerts"

    const val WATCH_NOTIFICATION_ID = 1001

    const val DEAD_MAN_SILENT_SECONDS = 300L
    const val FEED_STALE_SECONDS = 90L
}