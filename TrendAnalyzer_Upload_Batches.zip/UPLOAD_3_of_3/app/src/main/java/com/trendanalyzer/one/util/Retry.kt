package com.trendanalyzer.one.util

import kotlinx.coroutines.delay

/**
 * A bounded retry. Every caller gets a budget and an attempt count; nothing retries forever.
 */
suspend fun <T> retryWithBudget(
    attempts: Int,
    initialDelayMillis: Long = 500L,
    factor: Double = 2.0,
    maxDelayMillis: Long = 8_000L,
    onAttemptFailed: ((Throwable, Int) -> Unit)? = null,
    block: suspend () -> T
): T {
    require(attempts >= 1) { "attempts must be at least 1" }

    var delayMillis = initialDelayMillis
    var lastError: Throwable? = null

    repeat(attempts) { index ->
        try {
            return block()
        } catch (error: Throwable) {
            lastError = error
            onAttemptFailed?.invoke(error, index + 1)
            if (index < attempts - 1) {
                delay(delayMillis)
                delayMillis = (delayMillis * factor).toLong().coerceAtMost(maxDelayMillis)
            }
        }
    }

    throw lastError ?: IllegalStateException("retry failed without an error")
}
