package com.trendanalyzer.one.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.StateFlow

/** What the screens call. It never touches the engine directly, only the service. */
class WatchController(private val context: Context) {

    val status: StateFlow<WatchStatus> = WatchRuntime.status

    fun start() {
        val intent = Intent(context, MarketWatchService::class.java)
            .setAction(WatchActions.ACTION_START)
        ContextCompat.startForegroundService(context, intent)
    }

    fun stop() {
        val intent = Intent(context, MarketWatchService::class.java)
            .setAction(WatchActions.ACTION_STOP)
        runCatching { context.startService(intent) }
    }
}
