package com.trendanalyzer.one.notify

import com.trendanalyzer.one.engine.AlertEvent
import com.trendanalyzer.one.voice.AnnouncementTextBuilder

/** The same wording as the speaker, so the phone and the notification never disagree. */
object NotificationTexts {

    fun title(events: List<AlertEvent>): String = AnnouncementTextBuilder.title(events)

    fun body(events: List<AlertEvent>): String = AnnouncementTextBuilder.body(events)
}
