package com.trendanalyzer.one.notify

import com.trendanalyzer.one.engine.AlertEvent
import com.trendanalyzer.one.voice.AlertKind
import com.trendanalyzer.one.time.AppClock

class AlertHistoryRecorder(
    private val writer: AlertLogWriter,
    private val clock: AppClock
) {

    suspend fun record(
        events: List<AlertEvent>,
        kind: AlertKind,
        title: String,
        body: String,
        speech: String,
        notified: Boolean,
        spoken: Boolean,
        alexaStatus: String
    ) {
        if (events.isEmpty()) return

        writer.write(
            AlertLogRecord(
                createdAtMillis = clock.nowMillis(),
                speech = speech,
                title = title,
                body = body,
                zoneIds = events.map { it.zoneId },
                zoneGrades = events.associate { it.zoneId to it.grade.toDouble() },
                notified = notified,
                spoken = spoken,
                alexaStatus = alexaStatus
            )
        )

        if (kind == AlertKind.FOLLOW_UP_SECOND) return
    }
}
