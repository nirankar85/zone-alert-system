package com.trendanalyzer.one.service

import com.trendanalyzer.one.market.DeltaHttpException
import com.trendanalyzer.one.market.RateLimitedException
import java.io.IOException

/** One plain sentence for anything that can go wrong while watching, in English, no jargon. */
object ServiceErrors {

    fun messageFor(error: Throwable): String = when (error) {
        is RateLimitedException -> "The price source is asking us to wait a moment."
        is DeltaHttpException -> "The price source refused a request (${error.statusCode})."
        is IOException -> "The phone could not reach the price source."
        else -> "The watch hit a problem and is trying again."
    }
}
