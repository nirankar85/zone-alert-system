package com.trendanalyzer.one.engine

import com.trendanalyzer.one.data.db.entity.ZoneStateEntity

/** What has already been said about a rhythm, so a restart does not repeat it. */
data class ZoneRuntimeState(
    val zoneId: String,
    val side: LineSide = LineSide.BUYER,
    val phase: AlertPhase = AlertPhase.ARMED,
    val lineValue: Double = 0.0,
    val lastPrice: Double = 0.0,
    val phaseSinceMillis: Long = 0L,
    val lastAlertAtMillis: Long = 0L,
    val lastAlertLineValue: Double = 0.0
) {

    fun toEntity(updatedAtMillis: Long): ZoneStateEntity = ZoneStateEntity(
        zoneId = zoneId,
        side = side.name,
        phase = phase.name,
        lineValue = lineValue,
        lastPrice = lastPrice,
        phaseSinceMillis = phaseSinceMillis,
        lastAlertAtMillis = lastAlertAtMillis,
        lastAlertLineValue = lastAlertLineValue,
        updatedAtMillis = updatedAtMillis
    )

    companion object {

        fun fromEntity(entity: ZoneStateEntity): ZoneRuntimeState = ZoneRuntimeState(
            zoneId = entity.zoneId,
            side = runCatching { LineSide.valueOf(entity.side) }.getOrDefault(LineSide.BUYER),
            phase = runCatching { AlertPhase.valueOf(entity.phase) }.getOrDefault(AlertPhase.ARMED),
            lineValue = entity.lineValue,
            lastPrice = entity.lastPrice,
            phaseSinceMillis = entity.phaseSinceMillis,
            lastAlertAtMillis = entity.lastAlertAtMillis,
            lastAlertLineValue = entity.lastAlertLineValue
        )

        fun initial(zoneId: String): ZoneRuntimeState = ZoneRuntimeState(zoneId = zoneId)
    }
}
