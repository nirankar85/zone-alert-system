package com.trendanalyzer.one.notify

/**
 * A bounded retry schedule for delivery that can fail for boring reasons. The plan is computed
 * rather than slept here, so a test can assert the numbers without waiting.
 */
object DeliveryRetry {

    fun delaysMillis(attempts: Int, baseMillis: Long = 1_500L, factor: Double = 2.0): List<Long> {
        if (attempts <= 0) return emptyList()

        val delays = ArrayList<Long>(attempts)
        var delay = baseMillis

        repeat(attempts) {
            delays.add(delay.coerceAtMost(MAX_DELAY_MILLIS))
            delay = (delay * factor).toLong()
        }

        return delays
    }

    fun shouldRetry(attempt: Int, maxAttempts: Int): Boolean = attempt < maxAttempts

    private const val MAX_DELAY_MILLIS = 15_000L
}
