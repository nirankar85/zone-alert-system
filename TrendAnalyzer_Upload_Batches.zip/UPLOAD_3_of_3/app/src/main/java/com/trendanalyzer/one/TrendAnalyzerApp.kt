package com.trendanalyzer.one

import android.app.Application
import com.trendanalyzer.one.di.ServiceLocator

class TrendAnalyzerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
