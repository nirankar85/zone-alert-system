package com.trendanalyzer.one.service

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.time.AppClock

/**
 * Watches the watcher. If the price feed goes quiet for longer than the owner allowed, the switch
 * says so and the service restarts the feed once, instead of sitting there looking healthy.
 */
class DeadManSwitch(
    private val clock: AppClock,
    private val silentAfterMillis: Long = AppConfig.DEAD_MAN_SILENT_SECONDS * 1_000L
) {

    fun isSilent(lastTicketMillis: Long): Boolean {
        if (lastTicketMillis <= 0L) return false
        return clock.nowMillis() - lastTicketMillis > silentAfterMillis
    }

    fun shouldRestart(lastTicketMillis: Long, alreadyRestarted: Boolean): Boolean {
        if (alreadyRestarted) return false
        return isSilent(lastTicketMillis)
    }
}
