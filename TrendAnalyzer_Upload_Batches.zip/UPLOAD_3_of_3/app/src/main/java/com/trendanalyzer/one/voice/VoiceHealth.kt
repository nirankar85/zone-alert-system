package com.trendanalyzer.one.voice

import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class VoiceHealthState(
    val phoneReady: Boolean = false,
    val lastPhoneAtMillis: Long = 0L,
    val lastAlexaStatus: String = "",
    val lastAlexaAtMillis: Long = 0L
)

/** What the owner's health screen reads. Nothing secret, nothing cached longer than the process. */
class VoiceHealth(private val clock: AppClock) {

    private val state = MutableStateFlow(VoiceHealthState())
    val health: StateFlow<VoiceHealthState> = state.asStateFlow()

    fun recordPhone(ready: Boolean, spoken: Boolean) {
        state.update { current ->
            current.copy(
                phoneReady = ready,
                lastPhoneAtMillis = if (spoken) clock.nowMillis() else current.lastPhoneAtMillis
            )
        }
    }

    fun recordAlexa(status: String) {
        state.update { current ->
            current.copy(lastAlexaStatus = status, lastAlexaAtMillis = clock.nowMillis())
        }
    }
}
