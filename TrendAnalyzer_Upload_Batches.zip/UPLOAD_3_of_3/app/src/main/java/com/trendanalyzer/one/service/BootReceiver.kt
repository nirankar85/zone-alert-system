package com.trendanalyzer.one.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.trendanalyzer.one.log.Logx

/** Brings back a watch the owner had deliberately started, and nothing else. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        val wanted = WatchRestorePolicy(context).wasRunning()
        if (!wanted) return

        runCatching {
            val service = Intent(context, MarketWatchService::class.java)
                .setAction(WatchActions.ACTION_START)
            context.startForegroundService(service)
        }.onFailure { Logx.w(TAG, "could not restore the watch: ${it::class.java.simpleName}") }
    }

    private companion object {
        const val TAG = "BootReceiver"
    }
}
