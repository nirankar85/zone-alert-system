package com.trendanalyzer.one.time

/**
 * Time is injected everywhere so tests can pin it. Nothing in this app calls System.currentTimeMillis
 * directly outside this file.
 */
interface AppClock {
    fun nowMillis(): Long
}

object SystemAppClock : AppClock {
    override fun nowMillis(): Long = System.currentTimeMillis()
}
