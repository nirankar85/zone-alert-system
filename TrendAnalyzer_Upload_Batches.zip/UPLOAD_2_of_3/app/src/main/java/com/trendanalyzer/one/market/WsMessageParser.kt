package com.trendanalyzer.one.market

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Reads a price out of whatever the socket sends. The channel identifiers on this endpoint are
 * not confirmed, so the parser looks for a price by name rather than trusting a shape: if the
 * frame carries mark_price or price, it is used. Anything else is ignored quietly.
 */
object WsMessageParser {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val priceNames = listOf("mark_price", "markPrice", "price", "close", "last_price")

    fun parsePrice(raw: String): Double? {
        val root = runCatching { json.parseToJsonElement(raw) }.getOrNull() ?: return null
        return findPrice(root, 0)
    }

    private fun findPrice(element: JsonElement, depth: Int): Double? {
        if (depth > 4) return null

        if (element is JsonObject) {
            priceNames.forEach { name ->
                val value = DeltaJson.double(element[name])
                if (value != null && value > 0.0) return value
            }

            element.values.forEach { child ->
                val nested = findPrice(child, depth + 1)
                if (nested != null) return nested
            }
        }

        return null
    }
}
