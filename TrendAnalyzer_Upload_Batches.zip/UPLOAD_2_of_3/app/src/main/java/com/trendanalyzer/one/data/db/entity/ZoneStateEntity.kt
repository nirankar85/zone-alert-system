package com.trendanalyzer.one.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "zone_state")
data class ZoneStateEntity(
    @PrimaryKey val zoneId: String,
    val side: String,
    val phase: String,
    val lineValue: Double,
    val lastPrice: Double,
    val phaseSinceMillis: Long,
    val lastAlertAtMillis: Long,
    val lastAlertLineValue: Double,
    val updatedAtMillis: Long
)
