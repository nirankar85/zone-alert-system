package com.trendanalyzer.one.ui.model

import com.trendanalyzer.one.engine.EnginePipeline
import com.trendanalyzer.one.engine.ZoneReading
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.market.MarketFeed

class EngineDashboardSource(
    private val pipeline: EnginePipeline,
    private val feed: MarketFeed
) : DashboardSource {

    override fun readings(): List<ZoneReading> = pipeline.zones.value

    override fun price(): Double? = feed.snapshot.value.lastPrice

    override fun health(): FeedHealth = feed.snapshot.value.health
}
