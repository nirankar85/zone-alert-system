package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.CandleEntity

@Dao
interface CandleDao {

    @Query("SELECT * FROM candles WHERE symbol = :symbol AND resolution = :resolution ORDER BY openTimeMillis DESC LIMIT :limit")
    suspend fun recent(symbol: String, resolution: String, limit: Int): List<CandleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rows: List<CandleEntity>)

    @Query("DELETE FROM candles WHERE symbol = :symbol AND resolution = :resolution AND openTimeMillis < :before")
    suspend fun prune(symbol: String, resolution: String, before: Long)

    @Query("DELETE FROM candles")
    suspend fun clear()
}
