package com.trendanalyzer.one.account

import android.content.Context

/**
 * Remembers only which role is signed in and which client it belongs to. It never holds a token:
 * the authentication service owns that.
 */
class SessionStore(context: Context) {

    private val preferences = context.applicationContext
        .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun save(user: AccountUser) {
        preferences.edit()
            .putString(KEY_UID, user.uid)
            .putString(KEY_ROLE, user.role.name)
            .putString(KEY_CLIENT_ID, user.clientId)
            .putString(KEY_DISPLAY_NAME, user.displayName)
            .apply()
    }

    fun read(): AccountUser? {
        val uid = preferences.getString(KEY_UID, null)?.takeIf { it.isNotBlank() } ?: return null
        val role = preferences.getString(KEY_ROLE, null)
            ?.let { runCatching { AccountRole.valueOf(it) }.getOrNull() } ?: return null
        val clientId = preferences.getString(KEY_CLIENT_ID, null)?.takeIf { it.isNotBlank() }
        val displayName = preferences.getString(KEY_DISPLAY_NAME, null).orEmpty()

        return AccountUser(uid = uid, role = role, clientId = clientId, displayName = displayName)
    }

    fun clear() {
        preferences.edit().clear().apply()
    }

    private companion object {
        const val PREFERENCES_NAME = "trend_analyzer_session"
        const val KEY_UID = "uid"
        const val KEY_ROLE = "role"
        const val KEY_CLIENT_ID = "client_id"
        const val KEY_DISPLAY_NAME = "display_name"
    }
}
