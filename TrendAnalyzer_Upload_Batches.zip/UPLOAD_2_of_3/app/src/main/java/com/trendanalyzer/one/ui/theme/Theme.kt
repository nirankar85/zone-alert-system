package com.trendanalyzer.one.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BuyerTone = Color(0xFF2FBF71)
val SellerTone = Color(0xFFE5534B)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6FD1A0),
    onPrimary = Color(0xFF04231A),
    secondary = Color(0xFF8B93A1),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE6E8EB),
    surface = Color(0xFF151922),
    onSurface = Color(0xFFE6E8EB),
    surfaceVariant = Color(0xFF1D222C),
    onSurfaceVariant = Color(0xFF9AA3B2),
    error = Color(0xFFE5534B)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF137A52),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF5C6472),
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF14171C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14171C),
    surfaceVariant = Color(0xFFEEF1F5),
    onSurfaceVariant = Color(0xFF5C6472),
    error = Color(0xFFCF3D36)
)

@Composable
fun TrendAnalyzerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = MaterialTheme.shapes,
        content = content
    )
}
