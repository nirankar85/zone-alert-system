package com.trendanalyzer.one.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alert_log")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAtMillis: Long,
    val speech: String,
    val title: String,
    val body: String,
    val zoneIds: List<String>,
    val zoneGrades: Map<String, Double>,
    val notified: Boolean,
    val spoken: Boolean,
    val alexaStatus: String
)
