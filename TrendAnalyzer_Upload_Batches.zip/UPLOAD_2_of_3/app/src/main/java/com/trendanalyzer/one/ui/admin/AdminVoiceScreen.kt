package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.components.SectionCard
import kotlinx.coroutines.launch

@Composable
fun AdminVoiceScreen(
    controller: AdminController,
    settingsRepository: SettingsRepository,
    onOpenSecurity: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val settings by settingsRepository.engineSettings.collectAsState(initial = com.trendanalyzer.one.config.EngineSettings())
    val scope = rememberCoroutineScope()

    var configured by remember { mutableStateOf<Boolean?>(null) }
    var used by remember { mutableStateOf(0) }
    var limit by remember { mutableStateOf(200) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        configured = controller.alexaConfigured()
        val status = controller.alexaStatus()
        used = status.announcements
        limit = status.limit
    }

    ScreenScaffold(title = "Voice", subtitle = "Phone and Alexa", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Speaking") {
                AdminSwitchRow(
                    label = "Alexa announcements",
                    description = "Also speak on the owner's Alexa device.",
                    checked = settings.alexaEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { settingsRepository.setAlexaEnabled(enabled) }
                    }
                )
                KeyValueRow(
                    label = "Announcing account",
                    value = when (configured) {
                        true -> "Set up"
                        false -> "Not set up"
                        null -> "Checking"
                    }
                )
                KeyValueRow(
                    label = "This month",
                    value = "$used of $limit"
                )
                AdminNote(
                    "The free announcing plan allows $limit messages a month. When it runs out the phone still speaks."
                )
                Spacer(modifier = Modifier.height(8.dp))
                SecondaryButton(text = "Announcing credentials", onClick = onOpenSecurity)
                Spacer(modifier = Modifier.height(10.dp))
                SecondaryButton(
                    text = if (testing) "Sending…" else "Send a test to Alexa",
                    onClick = {
                        scope.launch {
                            testing = true
                            testResult = controller.testAlexa()
                            testing = false
                            val status = controller.alexaStatus()
                            used = status.announcements
                            limit = status.limit
                        }
                    }
                )
                if (testResult != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        testResult!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Quiet hours") {
                AdminNote(
                    "During quiet hours the phone stays silent and Alexa is skipped. Alerts still appear on screen."
                )
                KeyValueRow(
                    label = "Quiet hours",
                    value = if (settings.quietHoursEnabled) "On" else "Off"
                )
                SecondaryButton(
                    text = if (settings.quietHoursEnabled) "Turn quiet hours off" else "Turn quiet hours on",
                    onClick = {
                        scope.launch {
                            settingsRepository.setQuietHoursEnabled(!settings.quietHoursEnabled)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
