package com.trendanalyzer.one.data.db

import androidx.room.TypeConverter

class Converters {

    @TypeConverter
    fun fromStringList(value: List<String>): String = value.joinToString("\u001F")

    @TypeConverter
    fun toStringList(value: String): List<String> {
        if (value.isEmpty()) return emptyList()
        return value.split("\u001F")
    }

    @TypeConverter
    fun fromGradeMap(value: Map<String, Double>): String =
        value.entries.joinToString("\u001F") { "${it.key}=${it.value}" }

    @TypeConverter
    fun toGradeMap(value: String): Map<String, Double> {
        if (value.isEmpty()) return emptyMap()
        return value.split("\u001F").mapNotNull { entry ->
            val index = entry.indexOf('=')
            if (index <= 0) return@mapNotNull null
            val key = entry.substring(0, index)
            val number = entry.substring(index + 1).toDoubleOrNull() ?: return@mapNotNull null
            key to number
        }.toMap()
    }
}
