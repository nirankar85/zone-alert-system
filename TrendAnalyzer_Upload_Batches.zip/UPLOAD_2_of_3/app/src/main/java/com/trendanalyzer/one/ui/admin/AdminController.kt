package com.trendanalyzer.one.ui.admin

import com.trendanalyzer.one.account.AccountRepository
import com.trendanalyzer.one.account.ClientProfile
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.data.db.dao.AlertLogDao
import com.trendanalyzer.one.data.db.entity.AlertLogEntity
import com.trendanalyzer.one.market.MarketFeed
import com.trendanalyzer.one.secure.VoiceMonkeyCredentialRepository
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.voice.AlexaCounter
import com.trendanalyzer.one.voice.VoiceMonkeyClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Everything the owner tools need, kept away from the client screens. */
class AdminController(
    val account: AccountRepository,
    val settings: SettingsRepository,
    val feed: MarketFeed,
    val credentials: VoiceMonkeyCredentialRepository,
    val counter: AlexaCounter,
    val alertLogDao: AlertLogDao,
    val clock: AppClock,
    private val scope: CoroutineScope
) {

    private val _clients = MutableStateFlow<List<ClientProfile>>(emptyList())
    val clients: StateFlow<List<ClientProfile>> = _clients.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    fun loadClients() {
        scope.launch {
            _busy.value = true
            _clients.value = runCatching { account.adminListClients() }.getOrDefault(emptyList())
            _busy.value = false
        }
    }

    fun createClient(
        clientId: String,
        displayName: String,
        visibleGrades: Int,
        days: Int,
        password: String,
        onDone: (Boolean) -> Unit
) {
        scope.launch {
            _busy.value = true
            val result = account.adminCreateClient(clientId, displayName, visibleGrades, days, password)
            _busy.value = false

            result.onSuccess { created ->
                _clients.value = (_clients.value + created).distinctBy { it.clientId }
                    .sortedBy { it.displayName.lowercase() }
                _message.value = "Client added."
                onDone(true)
            }.onFailure {
                _message.value = "Client could not be added. Check the ID and try again."
                onDone(false)
            }
        }
    }

    fun updateClient(
        clientId: String,
        visibleGrades: Int,
        days: Int,
        enabled: Boolean,
        onDone: (Boolean) -> Unit
) {
        scope.launch {
            _busy.value = true
            val result = account.adminUpdateClient(clientId, visibleGrades, days, enabled)
            _busy.value = false

            result.onSuccess {
                _message.value = "Client updated."
                loadClients()
                onDone(true)
            }.onFailure {
                _message.value = "Client could not be updated."
                onDone(false)
            }
        }
    }

    fun deleteClient(clientId: String, onDone: (Boolean) -> Unit) {
        scope.launch {
            _busy.value = true
            val result = account.adminDeleteClient(clientId)
            _busy.value = false

            result.onSuccess {
                _clients.value = _clients.value.filterNot { it.clientId == clientId }
                _message.value = "Client removed."
                onDone(true)
            }.onFailure {
                _message.value = "Client could not be removed."
                onDone(false)
            }
        }
    }

    suspend fun loadClient(clientId: String): ClientProfile? =
        runCatching { account.adminRefreshClient(clientId) }.getOrNull()

    suspend fun loadAlerts(limit: Int): List<AlertLogEntity> =
        runCatching { alertLogDao.recent(limit) }.getOrDefault(emptyList())

    fun clearAlerts(onDone: () -> Unit) {
        scope.launch {
            runCatching { alertLogDao.clear() }
            onDone()
        }
    }

    suspend fun alexaConfigured(): Boolean =
        runCatching { credentials.isConfigured() }.getOrDefault(false)

    suspend fun alexaStatus(): AlexaCounter.Status = counter.status()

    suspend fun testAlexa(): String {
        val saved = runCatching { credentials.load() }.getOrNull()
            ?: return "Not set up yet."

        val response = VoiceMonkeyClient().announce(
            token = saved.token,
            device = saved.device,
            speech = "Test announcement from Trend Analyzer. Your Alexa announcements are working."
        )

        return if (response.success) "Test sent." else "Test refused (${response.statusCode})."
    }
}
