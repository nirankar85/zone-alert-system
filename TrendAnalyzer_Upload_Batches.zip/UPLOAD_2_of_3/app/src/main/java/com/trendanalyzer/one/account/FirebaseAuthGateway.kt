package com.trendanalyzer.one.account

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.trendanalyzer.one.log.Logx

/**
 * Sign-in only. A client account is created on a second, temporary connection so the owner stays
 * signed in on the main one.
 */
class FirebaseAuthGateway(private val context: Context) {

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance()

    fun isSignedIn(): Boolean = auth.currentUser != null

    fun currentUid(): String? = auth.currentUser?.uid

    fun currentEmail(): String? = auth.currentUser?.email

    suspend fun signIn(email: String, password: String): String {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).awaitResult()
            result.user?.uid ?: throw AccountException.InvalidCredentials()
        } catch (error: FirebaseAuthInvalidCredentialsException) {
            throw AccountException.InvalidCredentials()
        } catch (error: FirebaseAuthInvalidUserException) {
            throw AccountException.InvalidCredentials()
        } catch (error: AccountException) {
            throw error
        } catch (error: Exception) {
            Logx.w(TAG, "sign in failed: ${error::class.java.simpleName}")
            throw AccountException.Network()
        }
    }

    suspend fun createClientAccount(email: String, password: String): String {
        return try {
            val primary = FirebaseApp.getInstance()
            val secondary = FirebaseApp.getApps(context).firstOrNull { it.name == SECONDARY_NAME }
                ?: FirebaseApp.initializeApp(context, primary.options, SECONDARY_NAME)
                ?: throw AccountException.Unknown(null)

            val secondaryAuth = FirebaseAuth.getInstance(secondary)
            val result = secondaryAuth.createUserWithEmailAndPassword(email, password).awaitResult()
            val uid = result.user?.uid ?: throw AccountException.Unknown(null)

            runCatching { secondaryAuth.signOut() }
            uid
        } catch (error: FirebaseAuthUserCollisionException) {
            throw AccountException.Unknown(error)
        } catch (error: AccountException) {
            throw error
        } catch (error: Exception) {
            Logx.w(TAG, "client account creation failed: ${error::class.java.simpleName}")
            throw AccountException.Network()
        }
    }

    suspend fun signOut() {
        runCatching { auth.signOut() }
    }

    private companion object {
        const val TAG = "FirebaseAuthGateway"
        const val SECONDARY_NAME = "trend-analyzer-client-creator"
    }
}
