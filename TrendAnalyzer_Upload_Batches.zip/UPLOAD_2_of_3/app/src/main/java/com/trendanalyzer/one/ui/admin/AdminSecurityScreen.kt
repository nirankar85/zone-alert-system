package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.secure.VoiceMonkeyCredentials
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.components.SectionCard
import kotlinx.coroutines.launch

@Composable
fun AdminSecurityScreen(
    controller: AdminController,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val scope = rememberCoroutineScope()

    var configured by remember { mutableStateOf<Boolean?>(null) }
    var token by remember { mutableStateOf("") }
    var device by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        configured = controller.alexaConfigured()
    }

    ScreenScaffold(title = "Security", subtitle = "Announcing credentials", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Account") {
                KeyValueRow(
                    label = "Announcing account",
                    value = when (configured) {
                        true -> "Set up"
                        false -> "Not set up"
                        null -> "Checking"
                    }
                )
                AdminNote(
                    "These two strings come from the announcing service. They are kept in the phone's protected storage and are never written to a log or a screen after saving."
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Replace") {
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it; message = null },
                    label = { Text("Token") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = device,
                    onValueChange = { device = it; message = null },
                    label = { Text("Device") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                SecondaryButton(
                    text = "Save",
                    onClick = {
                        scope.launch {
                            val credentials = VoiceMonkeyCredentials(token, device)
                            if (!credentials.isComplete()) {
                                message = "Both fields are needed."
                                return@launch
                            }
                            runCatching { controller.credentials.save(credentials) }
                                .onSuccess {
                                    configured = true
                                    token = ""
                                    device = ""
                                    message = "Saved."
                                }
                                .onFailure { message = "Could not save on this phone." }
                        }
                    }
                )
                Spacer(modifier = Modifier.height(10.dp))
                SecondaryButton(
                    text = "Remove saved account",
                    onClick = {
                        scope.launch {
                            runCatching { controller.credentials.clear() }
                            configured = false
                            message = "Removed."
                        }
                    }
                )
                if (message != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        message!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "What is protected") {
                AdminNote(
                    "The announcing account, the owner sign-in and the client list. The app is read only and never stores a trading credential because it never asks for one."
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
