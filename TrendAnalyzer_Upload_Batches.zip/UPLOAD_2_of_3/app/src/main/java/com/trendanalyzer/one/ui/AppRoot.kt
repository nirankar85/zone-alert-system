package com.trendanalyzer.one.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.trendanalyzer.one.account.AccountRole
import com.trendanalyzer.one.di.ServiceLocator
import com.trendanalyzer.one.ui.admin.AdminAlertsScreen
import com.trendanalyzer.one.ui.admin.AdminClientDetailScreen
import com.trendanalyzer.one.ui.admin.AdminClientsScreen
import com.trendanalyzer.one.ui.admin.AdminController
import com.trendanalyzer.one.ui.admin.AdminHealthScreen
import com.trendanalyzer.one.ui.admin.AdminHistoryScreen
import com.trendanalyzer.one.ui.admin.AdminHomeScreen
import com.trendanalyzer.one.ui.admin.AdminSecurityScreen
import com.trendanalyzer.one.ui.admin.AdminSystemScreen
import com.trendanalyzer.one.ui.admin.AdminVoiceScreen
import com.trendanalyzer.one.ui.chart.ChartScreen
import com.trendanalyzer.one.ui.chart.ChartViewModel
import com.trendanalyzer.one.ui.chart.EngineChartSource
import com.trendanalyzer.one.ui.model.DashboardViewModel
import com.trendanalyzer.one.ui.model.EngineDashboardSource
import com.trendanalyzer.one.ui.model.SessionController
import com.trendanalyzer.one.ui.navigation.AppScreen
import com.trendanalyzer.one.ui.navigation.Navigator
import com.trendanalyzer.one.ui.screens.DashboardScreen
import com.trendanalyzer.one.ui.screens.LoginScreen
import com.trendanalyzer.one.ui.screens.OpeningScreen
import com.trendanalyzer.one.ui.screens.SettingsScreen

/**
 * The only place that knows which screen is on top. A signed-out phone can never reach a screen
 * that assumes a user, because that branch is chosen here, not inside a screen.
 */
@Composable
fun AppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val navigator = remember { Navigator(AppScreen.Opening) }
    val session = remember { SessionController(ServiceLocator.accountRepository, scope) }
    val user by session.user.collectAsState()

    val dashboardViewModel = remember {
        DashboardViewModel(
            account = ServiceLocator.accountRepository,
            source = EngineDashboardSource(ServiceLocator.pipeline, ServiceLocator.marketFeed),
            clock = ServiceLocator.clock,
            scope = scope
        )
    }

    val chartViewModel = remember {
        // The chart must never draw a grade the signed-in client cannot see. The owner has no
        // filter; a client gets the exact range the account page and dashboard already apply.
        val allowedGrades: suspend () -> Set<Int>? = {
            val current = session.user.value
            when {
                current == null -> emptySet()
                current.role == AccountRole.OWNER -> null
                else -> {
                    val entitlements = ServiceLocator.accountRepository.currentClient()?.entitlements()
                    val now = ServiceLocator.clock.nowMillis()
                    if (entitlements?.isActive(now) == true) {
                        entitlements.visibleRange.toSet()
                    } else {
                        emptySet()
                    }
                }
            }
        }

        ChartViewModel(
            source = EngineChartSource(
                feed = ServiceLocator.marketFeed,
                pipeline = ServiceLocator.pipeline,
                allowedGrades = allowedGrades
            ),
            settings = ServiceLocator.settingsRepository,
            clock = ServiceLocator.clock,
            scope = scope
        )
    }

    val adminController = remember {
        AdminController(
            account = ServiceLocator.accountRepository,
            settings = ServiceLocator.settingsRepository,
            feed = ServiceLocator.marketFeed,
            credentials = ServiceLocator.voiceMonkeyCredentials,
            counter = ServiceLocator.alexaCounter,
            alertLogDao = ServiceLocator.database.alertLogDao(),
            clock = ServiceLocator.clock,
            scope = scope
        )
    }

    val openSupport: () -> Unit = {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(ServiceLocator.supportWhatsAppUrl()))
            )
        }
    }

    val signOut: () -> Unit = {
        // Signing out also ends the watch: a signed-out phone must not keep speaking.
        ServiceLocator.watchController.stop()
        navigator.resetTo(AppScreen.Login)
    }

    LaunchedEffect(Unit) {
        session.restore()
    }

    LaunchedEffect(user) {
        val current = user
        if (current != null) {
            dashboardViewModel.setUser(current)
        } else {
            dashboardViewModel.setUser(null)
            dashboardViewModel.stop()
        }
    }

    LaunchedEffect(user) {
        if (user == null) {
            val screen = navigator.current()
            if (screen !is AppScreen.Opening && screen !is AppScreen.Login) {
                navigator.resetTo(AppScreen.Login)
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            val screen = navigator.current()

            // A signed-out phone never composes an owner or client screen, even for one frame.
            if (user == null && screen !is AppScreen.Opening && screen !is AppScreen.Login) {
                LoginScreen(
                    session = session,
                    onSignedIn = { navigator.resetTo(AppScreen.Dashboard) },
                    onSupport = openSupport
                )
            } else when (screen) {
                AppScreen.Opening -> OpeningScreen(
                    onStart = {
                        navigator.resetTo(if (user != null) AppScreen.Dashboard else AppScreen.Login)
                    },
                    onSupport = openSupport
                )

                AppScreen.Login -> LoginScreen(
                    session = session,
                    onSignedIn = { navigator.resetTo(AppScreen.Dashboard) },
                    onSupport = openSupport
                )

                AppScreen.Dashboard -> DashboardScreen(
                    vm = dashboardViewModel,
                    watch = ServiceLocator.watchController,
                    onOpenChart = { navigator.push(AppScreen.Chart) },
                    onOpenSettings = { navigator.push(AppScreen.Settings) },
                    onOpenAdmin = { navigator.push(AppScreen.AdminHome) }
                )

                AppScreen.Settings -> {
                    val current = user
                    if (current != null) {
                        SettingsScreen(
                            user = current,
                            session = session,
                            account = ServiceLocator.accountRepository,
                            watch = ServiceLocator.watchController,
                            onBack = { navigator.pop() },
                            onSignedOut = signOut,
                            onOpenAdmin = { navigator.push(AppScreen.AdminHome) },
                            onSupport = openSupport
                        )
                    }
                }

                AppScreen.Chart -> ChartScreen(
                    vm = chartViewModel,
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminHome -> AdminHomeScreen(
                    controller = adminController,
                    watch = ServiceLocator.watchController,
                    onOpenClients = { navigator.push(AppScreen.AdminClients) },
                    onOpenAlerts = { navigator.push(AppScreen.AdminAlerts) },
                    onOpenVoice = { navigator.push(AppScreen.AdminVoice) },
                    onOpenSystem = { navigator.push(AppScreen.AdminSystem) },
                    onOpenHealth = { navigator.push(AppScreen.AdminHealth) },
                    onOpenHistory = { navigator.push(AppScreen.AdminHistory) },
                    onOpenSecurity = { navigator.push(AppScreen.AdminSecurity) },
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminClients -> AdminClientsScreen(
                    controller = adminController,
                    onOpenClient = { navigator.push(AppScreen.AdminClientDetail(it)) },
                    onBack = { navigator.pop() }
                )

                is AppScreen.AdminClientDetail -> AdminClientDetailScreen(
                    clientId = screen.clientId,
                    controller = adminController,
                    onDeleted = {
                        navigator.pop()
                        adminController.loadClients()
                    },
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminAlerts -> AdminAlertsScreen(
                    settingsRepository = ServiceLocator.settingsRepository,
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminVoice -> AdminVoiceScreen(
                    controller = adminController,
                    settingsRepository = ServiceLocator.settingsRepository,
                    onOpenSecurity = { navigator.push(AppScreen.AdminSecurity) },
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminSystem -> AdminSystemScreen(
                    settingsRepository = ServiceLocator.settingsRepository,
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminHealth -> AdminHealthScreen(
                    feed = ServiceLocator.marketFeed,
                    pipeline = ServiceLocator.pipeline,
                    watch = ServiceLocator.watchController,
                    voiceHealth = ServiceLocator.voiceHealth,
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminHistory -> AdminHistoryScreen(
                    controller = adminController,
                    onBack = { navigator.pop() }
                )

                AppScreen.AdminSecurity -> AdminSecurityScreen(
                    controller = adminController,
                    onBack = { navigator.pop() }
                )
            }
        }
    }
}
