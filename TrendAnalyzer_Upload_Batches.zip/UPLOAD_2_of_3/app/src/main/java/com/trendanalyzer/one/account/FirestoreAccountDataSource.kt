package com.trendanalyzer.one.account

import com.google.firebase.firestore.FirebaseFirestore

/** Reads and writes the two collections the rules file names. Nothing else is reachable. */
class FirestoreAccountDataSource(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    suspend fun isOwner(uid: String): Boolean = runCatching {
        val snapshot = firestore.collection(AccountSchema.COLLECTION_ADMINS)
            .document(uid)
            .get()
            .awaitResult()
        snapshot.exists()
    }.getOrDefault(false)

    suspend fun readClient(clientId: String): ClientProfile? = runCatching {
        val snapshot = firestore.collection(AccountSchema.COLLECTION_CLIENTS)
            .document(clientId)
            .get()
            .awaitResult()

        if (!snapshot.exists()) return@runCatching null
        AccountSchema.clientFromMap(clientId, snapshot.data.orEmpty())
    }.getOrNull()

    suspend fun readPasswordHash(clientId: String): String? = runCatching {
        val snapshot = firestore.collection(AccountSchema.COLLECTION_CLIENTS)
            .document(clientId)
            .get()
            .awaitResult()

        (snapshot.data?.get(AccountSchema.FIELD_PASSWORD_HASH) as? String)?.takeIf { it.isNotBlank() }
    }.getOrNull()

    suspend fun listClients(): List<ClientProfile> = runCatching {
        val snapshot = firestore.collection(AccountSchema.COLLECTION_CLIENTS)
            .get()
            .awaitResult()

        snapshot.documents.mapNotNull { document ->
            val data = document.data ?: return@mapNotNull null
            AccountSchema.clientFromMap(document.id, data)
        }.sortedBy { it.displayName.lowercase() }
    }.getOrDefault(emptyList())

    suspend fun writeClient(
        profile: ClientProfile,
        passwordHash: String?,
        updatedAtMillis: Long
    ) {
        firestore.collection(AccountSchema.COLLECTION_CLIENTS)
            .document(profile.clientId)
            .set(AccountSchema.clientToMap(profile, passwordHash, updatedAtMillis))
            .awaitDone()
    }

    suspend fun deleteClient(clientId: String) {
        firestore.collection(AccountSchema.COLLECTION_CLIENTS)
            .document(clientId)
            .delete()
            .awaitDone()
    }
}
