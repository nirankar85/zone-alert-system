package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.config.internal.ZoneRegistry
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SectionCard
import com.trendanalyzer.one.voice.GradeNames
import kotlinx.coroutines.launch

@Composable
fun AdminAlertsScreen(
    settingsRepository: SettingsRepository,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val settings by settingsRepository.engineSettings.collectAsState(initial = com.trendanalyzer.one.config.EngineSettings())
    val scope = rememberCoroutineScope()

    ScreenScaffold(title = "Alerts", subtitle = "Distance, lines and follow-ups", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Sensitivity") {
                AdminStepperRow(
                    label = "Alert distance",
                    valueText = "${settings.alertDistancePoints.toInt()} points",
                    onMinus = {
                        scope.launch {
                            settingsRepository.setAlertDistance((settings.alertDistancePoints - 1).coerceAtLeast(1.0))
                        }
                    },
                    onPlus = {
                        scope.launch {
                            settingsRepository.setAlertDistance(settings.alertDistancePoints + 1)
                        }
                    }
                )
                AdminStepperRow(
                    label = "Re-arm distance",
                    valueText = "${settings.rearmDistancePoints.toInt()} points",
                    onMinus = {
                        scope.launch {
                            settingsRepository.setRearmDistance((settings.rearmDistancePoints - 1).coerceAtLeast(2.0))
                        }
                    },
                    onPlus = {
                        scope.launch {
                            settingsRepository.setRearmDistance(settings.rearmDistancePoints + 1)
                        }
                    }
                )
                AdminStepperRow(
                    label = "Repeat guard",
                    valueText = "${settings.cooldownSeconds / 60} min",
                    onMinus = {
                        scope.launch {
                            settingsRepository.setCooldownSeconds(settings.cooldownSeconds - 30)
                        }
                    },
                    onPlus = {
                        scope.launch {
                            settingsRepository.setCooldownSeconds(settings.cooldownSeconds + 30)
                        }
                    }
                )
                AdminStepperRow(
                    label = "Lowest grade that speaks",
                    valueText = "${settings.minGrade}",
                    onMinus = {
                        scope.launch { settingsRepository.setMinGrade(settings.minGrade - 1) }
                    },
                    onPlus = {
                        scope.launch { settingsRepository.setMinGrade(settings.minGrade + 1) }
                    }
                )
                AdminNote("Grade 1 is the fastest rhythm and the quietest sound.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Follow-ups") {
                AdminSwitchRow(
                    label = "Calm follow-ups",
                    description = "Two reminders while price stays in reach.",
                    checked = settings.followUpsEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { settingsRepository.setFollowUpsEnabled(enabled) }
                    }
                )
                AdminStepperRow(
                    label = "First follow-up",
                    valueText = "${settings.followUpFirstSeconds / 60} min",
                    onMinus = {
                        scope.launch {
                            settingsRepository.setFollowUpFirstSeconds((settings.followUpFirstSeconds - 60).coerceAtLeast(60))
                        }
                    },
                    onPlus = {
                        scope.launch {
                            settingsRepository.setFollowUpFirstSeconds(settings.followUpFirstSeconds + 60)
                        }
                    }
                )
                AdminStepperRow(
                    label = "Second follow-up",
                    valueText = "${settings.followUpSecondSeconds / 60} min",
                    onMinus = {
                        scope.launch {
                            settingsRepository.setFollowUpSecondSeconds((settings.followUpSecondSeconds - 300).coerceAtLeast(300))
                        }
                    },
                    onPlus = {
                        scope.launch {
                            settingsRepository.setFollowUpSecondSeconds(settings.followUpSecondSeconds + 300)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Lines") {
                ZoneRegistry.all.sortedByDescending { it.grade }.forEach { zone ->
                    AdminSwitchRow(
                        label = "${GradeNames.ordinal(zone.grade)} Grade",
                        description = if (settings.isZoneEnabled(zone.id)) {
                            "Watched."
                        } else {
                            "Paused."
                        },
                        checked = settings.isZoneEnabled(zone.id),
                        onCheckedChange = { enabled ->
                            scope.launch { settingsRepository.setZoneEnabled(zone.id, enabled) }
                        }
                    )
                }
                AdminNote("A paused grade stays in the ladder but never speaks.")
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "Changes apply to the next engine turn.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
