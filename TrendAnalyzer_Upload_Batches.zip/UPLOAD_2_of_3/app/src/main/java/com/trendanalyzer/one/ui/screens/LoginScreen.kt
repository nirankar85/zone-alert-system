package com.trendanalyzer.one.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import com.trendanalyzer.one.ui.components.PrimaryButton
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.model.SessionController
import com.trendanalyzer.one.ui.theme.BuyerTone

@Composable
fun LoginScreen(
    session: SessionController,
    onSignedIn: () -> Unit,
    onSupport: () -> Unit
) {
    var ownerMode by remember { mutableStateOf(false) }
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val busy by session.busy.collectAsState()

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 40.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                if (ownerMode) "Owner sign in" else "Client sign in",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                if (ownerMode) {
                    "Use the owner email and password. Owner tools open after this."
                } else {
                    "Use the client ID and password the owner gave you."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it; error = null },
                label = { Text(if (ownerMode) "Email" else "Client ID") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (ownerMode) KeyboardType.Email else KeyboardType.Ascii
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it; error = null },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )

            if (error != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    error!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (busy) {
                CircularProgressIndicator(modifier = Modifier.padding(8.dp))
                Spacer(modifier = Modifier.height(12.dp))
            }

            PrimaryButton(
                text = if (ownerMode) "Sign in as owner" else "Sign in",
                enabled = !busy && identifier.isNotBlank() && password.isNotEmpty(),
                onClick = {
                    error = null
                    if (ownerMode) {
                        session.loginOwner(identifier, password) { resultError ->
                            if (resultError == null) onSignedIn() else error = resultError
                        }
                    } else {
                        session.loginClient(identifier, password) { resultError ->
                            if (resultError == null) onSignedIn() else error = resultError
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            TextButton(
                onClick = {
                    ownerMode = !ownerMode
                    identifier = ""
                    password = ""
                    error = null
                },
                enabled = !busy
            ) {
                Text(if (ownerMode) "I am a client" else "I am the owner")
            }

            Spacer(modifier = Modifier.height(24.dp))
            SecondaryButton(text = "Contact support", onClick = onSupport)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Your password is never stored on this phone.",
                style = MaterialTheme.typography.labelSmall,
                color = BuyerTone
            )
        }
    }
}
