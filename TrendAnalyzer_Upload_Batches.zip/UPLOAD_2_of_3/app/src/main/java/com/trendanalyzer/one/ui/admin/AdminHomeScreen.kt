package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.service.WatchController
import com.trendanalyzer.one.service.WatchStatus
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.MenuRow
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SectionCard
import com.trendanalyzer.one.util.PriceFormat

@Composable
fun AdminHomeScreen(
    controller: AdminController,
    watch: WatchController,
    onOpenClients: () -> Unit,
    onOpenAlerts: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenSystem: () -> Unit,
    onOpenHealth: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSecurity: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val snapshot by controller.feed.snapshot.collectAsState()
    val watchStatus by watch.status.collectAsState()
    val clients by controller.clients.collectAsState()

    ScreenScaffold(title = "Owner tools", subtitle = "Private", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Now") {
                KeyValueRow(
                    label = "Gold",
                    value = snapshot.lastPrice?.takeIf { it > 0.0 }?.let { PriceFormat.money(it) } ?: "—"
                )
                KeyValueRow(
                    label = "Price feed",
                    value = when (snapshot.health) {
                        FeedHealth.LIVE -> "Live"
                        FeedHealth.STALE -> "Delayed"
                        FeedHealth.DOWN -> "Down"
                        FeedHealth.UNKNOWN -> "Starting"
                    }
                )
                KeyValueRow(
                    label = "Watch",
                    value = when (watchStatus) {
                        WatchStatus.RUNNING -> "On"
                        WatchStatus.STARTING -> "Starting"
                        WatchStatus.STOPPING -> "Stopping"
                        WatchStatus.STOPPED -> "Off"
                    }
                )
                KeyValueRow(label = "Clients known", value = clients.size.toString())
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Manage") {
                MenuRow("Clients", "Access, grades and expiry", onOpenClients)
                MenuRow("Alerts", "Lines, distance and follow-ups", onOpenAlerts)
                MenuRow("Voice", "Alexa and phone speaking", onOpenVoice)
                MenuRow("System", "Feed and quiet hours", onOpenSystem)
                MenuRow("Health", "What the engine sees now", onOpenHealth)
                MenuRow("History", "What was said and when", onOpenHistory)
                MenuRow("Security", "Announcing credentials", onOpenSecurity)
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Owner tools are not visible to clients.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
