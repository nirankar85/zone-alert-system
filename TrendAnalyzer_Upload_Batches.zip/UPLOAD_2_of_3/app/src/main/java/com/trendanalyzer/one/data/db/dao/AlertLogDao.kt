package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.AlertLogEntity

@Dao
interface AlertLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(row: AlertLogEntity): Long

    @Query("SELECT * FROM alert_log ORDER BY createdAtMillis DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<AlertLogEntity>

    @Query("SELECT COUNT(*) FROM alert_log WHERE createdAtMillis >= :sinceMillis")
    suspend fun countSince(sinceMillis: Long): Int

    @Query("DELETE FROM alert_log")
    suspend fun clear()
}
