package com.trendanalyzer.one.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.account.AccountRepository
import com.trendanalyzer.one.account.AccountRole
import com.trendanalyzer.one.account.AccountUser
import com.trendanalyzer.one.account.Entitlements
import com.trendanalyzer.one.service.WatchController
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SectionCard
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.model.SessionController
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    user: AccountUser,
    session: SessionController,
    account: AccountRepository,
    watch: WatchController,
    onBack: () -> Unit,
    onSignedOut: () -> Unit,
    onOpenAdmin: () -> Unit,
    onSupport: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val watching by watch.status.collectAsState()

    ScreenScaffold(title = "Settings", subtitle = user.displayName, onBack = onBack) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Account") {
                KeyValueRow(
                    label = "Signed in as",
                    value = if (user.role == AccountRole.OWNER) "Owner" else "Client"
                )
                if (user.clientId != null) {
                    KeyValueRow(label = "Client ID", value = user.clientId)
                }
                KeyValueRow(
                    label = "Watch",
                    value = if (watching == com.trendanalyzer.one.service.WatchStatus.RUNNING) "On" else "Off"
                )

                Spacer(modifier = Modifier.height(8.dp))

                SecondaryButton(
                    text = if (watching == com.trendanalyzer.one.service.WatchStatus.RUNNING) "Stop watch" else "Start watch",
                    onClick = {
                        if (watching == com.trendanalyzer.one.service.WatchStatus.RUNNING) {
                            watch.stop()
                        } else {
                            watch.start()
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            SectionCard(title = "Notifications") {
                Text(
                    "Alerts need notification permission. If no alert has ever appeared, open the phone's notification settings for this app and allow them.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                SecondaryButton(
                    text = "Open notification settings",
                    onClick = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        runCatching { context.startActivity(intent) }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            SectionCard(title = "Support") {
                Text(
                    "For access changes, billing or a problem with alerts, message the owner on WhatsApp.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                SecondaryButton(text = "Message support", onClick = onSupport)
            }

            if (user.role == AccountRole.OWNER) {
                Spacer(modifier = Modifier.height(10.dp))
                SectionCard(title = "Owner") {
                    SecondaryButton(text = "Owner tools", onClick = onOpenAdmin)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SecondaryButton(
                text = "Sign out",
                onClick = {
                    scope.launch {
                        session.logout { onSignedOut() }
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Read only. Nothing in this app touches a trading account.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
