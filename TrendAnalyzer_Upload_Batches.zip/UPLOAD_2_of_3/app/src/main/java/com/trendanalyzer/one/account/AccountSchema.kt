package com.trendanalyzer.one.account

/**
 * Field names shared by the rules file, the console instructions and this code. One spelling per
 * field, in one place.
 */
object AccountSchema {

    const val COLLECTION_CLIENTS = "clients"
    const val COLLECTION_ADMINS = "admins"

    const val FIELD_DISPLAY_NAME = "displayName"
    const val FIELD_VISIBLE_GRADES = "visibleGrades"
    const val FIELD_EXPIRES_AT = "expiresAtMillis"
    const val FIELD_ENABLED = "enabled"
    const val FIELD_PLAN = "plan"
    const val FIELD_UID = "uid"
    const val FIELD_PASSWORD_HASH = "passwordHash"
    const val FIELD_UPDATED_AT = "updatedAtMillis"
    const val FIELD_CLIENT_ID = "clientId"

    fun clientToMap(profile: ClientProfile, passwordHash: String?, updatedAtMillis: Long): Map<String, Any?> =
        mapOf(
            FIELD_CLIENT_ID to profile.clientId,
            FIELD_DISPLAY_NAME to profile.displayName,
            FIELD_VISIBLE_GRADES to profile.visibleGrades.coerceIn(0, 7),
            FIELD_EXPIRES_AT to profile.expiresAtMillis,
            FIELD_ENABLED to profile.enabled,
            FIELD_PLAN to profile.plan,
            FIELD_UID to profile.uid,
            FIELD_PASSWORD_HASH to passwordHash,
            FIELD_UPDATED_AT to updatedAtMillis
        )

    fun clientFromMap(clientId: String, data: Map<String, Any?>): ClientProfile = ClientProfile(
        clientId = (data[FIELD_CLIENT_ID] as? String)?.takeIf { it.isNotBlank() } ?: clientId,
        displayName = (data[FIELD_DISPLAY_NAME] as? String)?.takeIf { it.isNotBlank() } ?: clientId,
        visibleGrades = (data[FIELD_VISIBLE_GRADES] as? Number)?.toInt() ?: 0,
        expiresAtMillis = (data[FIELD_EXPIRES_AT] as? Number)?.toLong() ?: 0L,
        enabled = data[FIELD_ENABLED] as? Boolean ?: false,
        plan = (data[FIELD_PLAN] as? String) ?: "standard",
        uid = (data[FIELD_UID] as? String).orEmpty(),
        hasPasswordRecord = (data[FIELD_PASSWORD_HASH] as? String)?.isNotBlank() == true
    )
}
