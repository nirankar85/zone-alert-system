package com.trendanalyzer.one.account

import com.trendanalyzer.one.data.db.dao.ClientCacheDao
import com.trendanalyzer.one.data.db.entity.ClientCacheEntity
import com.trendanalyzer.one.time.AppClock

/** The last known entitlements, so the ladder still opens when the phone is briefly offline. */
class ClientCacheStore(
    private val dao: ClientCacheDao,
    private val clock: AppClock
) {

    suspend fun save(profile: ClientProfile) {
        runCatching { dao.upsert(profile.toEntity(clock.nowMillis())) }
    }

    suspend fun saveAll(profiles: List<ClientProfile>) {
        runCatching { dao.upsertAll(profiles.map { it.toEntity(clock.nowMillis()) }) }
    }

    suspend fun get(clientId: String): ClientProfile? =
        runCatching { dao.get(clientId) }.getOrNull()?.toProfile()

    suspend fun all(): List<ClientProfile> =
        runCatching { dao.all() }.getOrDefault(emptyList()).map { it.toProfile() }

    suspend fun remove(clientId: String) {
        runCatching { dao.delete(clientId) }
    }

    suspend fun clear() {
        runCatching { dao.clear() }
    }

    private fun ClientProfile.toEntity(now: Long): ClientCacheEntity = ClientCacheEntity(
        clientId = clientId,
        displayName = displayName,
        visibleGrades = visibleGrades,
        expiresAtMillis = expiresAtMillis,
        enabled = enabled,
        role = AccountRole.CLIENT.name,
        plan = plan,
        hasPasswordRecord = hasPasswordRecord,
        updatedAtMillis = now
    )

    private fun ClientCacheEntity.toProfile(): ClientProfile = ClientProfile(
        clientId = clientId,
        displayName = displayName,
        visibleGrades = visibleGrades,
        expiresAtMillis = expiresAtMillis,
        enabled = enabled,
        plan = plan,
        hasPasswordRecord = hasPasswordRecord
    )
}
