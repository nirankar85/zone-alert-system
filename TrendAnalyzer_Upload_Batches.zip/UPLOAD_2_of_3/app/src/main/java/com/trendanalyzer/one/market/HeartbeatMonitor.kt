package com.trendanalyzer.one.market

/** Tracks when something last proved it was alive. */
class HeartbeatMonitor(private val staleAfterMillis: Long) {

    private var lastSeenMillis: Long = 0L

    fun markSeen(atMillis: Long) {
        lastSeenMillis = atMillis
    }

    fun lastSeen(): Long = lastSeenMillis

    fun isStale(nowMillis: Long): Boolean {
        if (lastSeenMillis == 0L) return true
        return nowMillis - lastSeenMillis > staleAfterMillis
    }

    fun reset() {
        lastSeenMillis = 0L
    }
}