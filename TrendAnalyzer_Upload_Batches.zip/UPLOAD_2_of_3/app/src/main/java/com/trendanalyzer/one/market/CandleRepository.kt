package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.data.db.dao.CandleDao
import com.trendanalyzer.one.data.db.entity.CandleEntity
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max
import kotlin.math.min

/**
 * Candles for one rhythm, from the store when they are fresh enough and from the venue when they
 * are not. 45m is never requested from the venue: the venue has no such rhythm, so three 15m
 * candles are folded together on the UTC grid.
 */
class CandleRepository(
    private val rest: DeltaRestClient,
    private val dao: CandleDao,
    private val clock: AppClock
) {

    private val mutex = Mutex()
    private val lastFetchByResolution = mutableMapOf<String, Long>()
    private val memoryCache = mutableMapOf<String, List<Candle>>()

    suspend fun load(resolution: String, limit: Int, force: Boolean = false): List<Candle> {
        val sourceResolution = if (resolution == "45m") "15m" else resolution
        val wanted = if (resolution == "45m") limit * 3 else limit

        val cached = readCache(sourceResolution, wanted)

        val fresh = !force && cached.isNotEmpty() &&
            clock.nowMillis() - (lastFetchByResolution[sourceResolution] ?: 0L) < ttlMillis(sourceResolution)

        val candles = if (fresh) cached else {
            val fetched = runCatching { fetch(sourceResolution, wanted) }.getOrElse { error ->
                Logx.w(TAG, "candle fetch failed: ${error::class.java.simpleName}")
                emptyList()
            }
            if (fetched.isEmpty()) cached else fetched
        }

        val result = if (resolution == "45m") TimeframeBucketer.bucket45(candles) else candles
        return result.takeLast(limit.coerceAtLeast(1))
    }

    private suspend fun readCache(resolution: String, limit: Int): List<Candle> {
        memoryCache[resolution]?.takeIf { it.isNotEmpty() }?.let { cached ->
            return cached.takeLast(limit)
        }

        val rows = runCatching { dao.recent(AppConfig.SYMBOL, resolution, limit) }.getOrDefault(emptyList())
        val candles = rows.map { it.toCandle() }.sortedBy { it.openTimeMillis }
        if (candles.isNotEmpty()) memoryCache[resolution] = candles
        return candles
    }

    private suspend fun fetch(resolution: String, limit: Int): List<Candle> = mutex.withLock {
        val duration = Resolutions.durationMillis(resolution)
        val end = CandlePagination.endMillis(clock.nowMillis(), duration)
        val start = CandlePagination.startMillis(end, duration, limit.coerceAtMost(AppConfig.MAX_CANDLES_PER_REQUEST))

        val candles = rest.candles(resolution, AppConfig.SYMBOL, start, end)
            .filter { it.isValid() }
            .distinctBy { it.openTimeMillis }
            .sortedBy { it.openTimeMillis }

        if (candles.isEmpty()) return@withLock emptyList()

        val now = clock.nowMillis()
        val rows = candles.map { candle ->
            CandleEntity(
                symbol = AppConfig.SYMBOL,
                resolution = resolution,
                openTimeMillis = candle.openTimeMillis,
                open = candle.open,
                high = candle.high,
                low = candle.low,
                close = candle.close,
                volume = candle.volume,
                updatedAtMillis = now
            )
        }

        runCatching { dao.upsertAll(rows) }

        val merged = (readCache(resolution, AppConfig.CANDLE_STORE_LIMIT) + candles)
            .distinctBy { it.openTimeMillis }
            .sortedBy { it.openTimeMillis }
            .takeLast(AppConfig.CANDLE_STORE_LIMIT)

        memoryCache[resolution] = merged
        lastFetchByResolution[resolution] = now

        runCatching {
            val oldest = merged.firstOrNull()?.openTimeMillis ?: return@runCatching
            dao.prune(AppConfig.SYMBOL, resolution, oldest)
        }

        merged
    }

    /** A short rhythm is refreshed often; a daily rhythm is refreshed once every few minutes. */
    private fun ttlMillis(resolution: String): Long {
        val duration = Resolutions.durationMillis(resolution)
        val scaled = (duration * 0.05).toLong()
        return min(300_000L, max(5_000L, scaled))
    }

    fun invalidate(resolution: String? = null) {
        if (resolution == null) {
            memoryCache.clear()
            lastFetchByResolution.clear()
        } else {
            memoryCache.remove(resolution)
            lastFetchByResolution.remove(resolution)
        }
    }

    private fun CandleEntity.toCandle(): Candle = Candle(
        openTimeMillis = openTimeMillis,
        open = open,
        high = high,
        low = low,
        close = close,
        volume = volume
    )

    private companion object {
        const val TAG = "CandleRepository"
    }
}
