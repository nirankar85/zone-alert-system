package com.trendanalyzer.one.ui.model

import com.trendanalyzer.one.account.AccountRepository
import com.trendanalyzer.one.account.AccountRole
import com.trendanalyzer.one.account.AccountUser
import com.trendanalyzer.one.account.ClientAccessState
import com.trendanalyzer.one.engine.LineSide
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.service.WatchRuntime
import com.trendanalyzer.one.service.WatchStatus
import com.trendanalyzer.one.time.AppClock
import com.trendanalyzer.one.util.PriceFormat
import com.trendanalyzer.one.voice.GradeNames
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * The screen's only source of truth. It applies the client's visible grades here, once, so no
 * screen can accidentally show a grade the account did not pay for.
 */
class DashboardViewModel(
    private val account: AccountRepository,
    private val source: DashboardSource,
    private val clock: AppClock,
    private val scope: CoroutineScope
) {

    private val _state = MutableStateFlow(DashboardState())
    val state: StateFlow<DashboardState> = _state.asStateFlow()

    private var user: AccountUser? = null
    private var job: Job? = null

    fun setUser(value: AccountUser?) {
        user = value
        refresh()
    }

    fun start() {
        if (job != null) return
        job = scope.launch {
            while (isActive) {
                tick()
                delay(REFRESH_INTERVAL_MILLIS)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    fun refresh() {
        scope.launch { tick() }
    }

    private suspend fun tick() {
        val current = user

        if (current == null) {
            _state.update { it.copy(loading = false, accessMessage = "Please sign in.") }
            return
        }

        val profile = if (current.role == AccountRole.CLIENT) {
            runCatching { account.currentClient() }.getOrNull()
        } else {
            null
        }

        val now = clock.nowMillis()
        val entitlements = profile?.entitlements()

        var accessMessage: String? = null
        var accessHint = ""

        if (current.role == AccountRole.CLIENT) {
            when (entitlements?.state(now)) {
                null -> {
                    accessMessage = "Your view is not ready yet."
                    accessHint = "Please contact the owner."
                }

                ClientAccessState.ACTIVE -> Unit

                ClientAccessState.EXPIRED -> {
                    accessMessage = "Your view has ended."
                    accessHint = "Please contact the owner."
                }

                ClientAccessState.DISABLED -> {
                    accessMessage = "Your view is paused."
                    accessHint = "Please contact the owner."
                }

                ClientAccessState.NO_GRADES -> {
                    accessMessage = "No grades are open on this account."
                    accessHint = "Please contact the owner."
                }
            }
        }

        val zones = runCatching {
            source.readings()
                .filter { reading ->
                    if (current.role == AccountRole.CLIENT) {
                        entitlements?.canSee(reading.grade, now) == true
                    } else {
                        true
                    }
                }
                .sortedByDescending { it.grade }
                .map { reading ->
                    DashboardZone(
                        zoneId = reading.zoneId,
                        name = GradeNames.zoneName(reading.grade, reading.side),
                        grade = reading.grade,
                        price = reading.line,
                        isBuyer = reading.side == LineSide.BUYER
                    )
                }
        }.getOrElse { error ->
            Logx.w(TAG, "dashboard read failed: ${error::class.java.simpleName}")
            emptyList()
        }

        val price = runCatching { source.price() }.getOrNull()
        val health = runCatching { source.health() }.getOrDefault(FeedHealth.UNKNOWN)

        _state.update { previous ->
            previous.copy(
                loading = false,
                userName = current.displayName,
                role = current.role,
                zones = zones,
                lastPrice = price,
                lastPriceText = if (price != null && price > 0.0) PriceFormat.money(price) else "—",
                feedLabel = FeedLabels.from(health),
                watching = WatchRuntime.status.value == WatchStatus.RUNNING,
                accessMessage = accessMessage,
                accessHint = accessHint,
                error = null,
                isOwner = current.role == AccountRole.OWNER,
                clientId = current.clientId,
                updatedAtMillis = now
            )
        }
    }

    private companion object {
        const val TAG = "DashboardViewModel"
        const val REFRESH_INTERVAL_MILLIS = 1_500L
    }
}
