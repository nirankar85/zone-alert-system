package com.trendanalyzer.one.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.service.WatchController
import com.trendanalyzer.one.ui.components.EmptyNote
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.SectionCard
import com.trendanalyzer.one.ui.components.StatusPill
import com.trendanalyzer.one.ui.model.DashboardViewModel
import com.trendanalyzer.one.ui.model.DashboardZone
import com.trendanalyzer.one.ui.model.FeedLabel
import com.trendanalyzer.one.ui.model.FeedLabels
import com.trendanalyzer.one.ui.theme.BuyerTone
import com.trendanalyzer.one.ui.theme.PriceLargeStyle
import com.trendanalyzer.one.ui.theme.SellerTone
import com.trendanalyzer.one.util.PriceFormat

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    watch: WatchController,
    onOpenChart: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAdmin: () -> Unit
) {
    val state by vm.state.collectAsState()

    DisposableEffect(Unit) {
        vm.start()
        onDispose { vm.stop() }
    }

    BackHandler(enabled = false) { }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 12.dp, top = 18.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "TREND ANALYZER 1%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        if (state.isOwner) "Owner" else state.userName.ifBlank { "Client" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                StatusPill(
                    text = FeedLabels.text(state.feedLabel),
                    tone = feedTone(state.feedLabel)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 6.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Gold",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        state.lastPriceText,
                        style = PriceLargeStyle,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                TextButton(onClick = onOpenChart) { Text("Chart") }
                TextButton(onClick = onOpenSettings) { Text("Settings") }
            }

            if (state.accessMessage != null) {
                SectionCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                    Text(
                        state.accessMessage!!,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        state.accessHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionCard(modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (state.watching) "Watch is on" else "Watch is off",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            if (state.watching) {
                                "Alerts speak when price reaches a line."
                            } else {
                                "Turn the watch on to hear alerts."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = {
                            if (state.watching) watch.stop() else watch.start()
                        }
                    ) {
                        Text(if (state.watching) "Stop" else "Start")
                    }
                }
            }

            if (state.loading) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp))
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 18.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                items(items = state.zones, key = { it.zoneId }) { zone ->
                    ZoneRow(zone)
                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (!state.loading && state.zones.isEmpty()) {
                    item {
                        EmptyNote(
                            if (state.accessMessage != null) {
                                "No levels are open on this account."
                            } else {
                                "Waiting for the first reading."
                            }
                        )
                    }
                }

                if (state.isOwner) {
                    item {
                        TextButton(onClick = onOpenAdmin, modifier = Modifier.fillMaxWidth()) {
                            Text("Owner tools")
                        }
                    }
                }

                item {
                    Text(
                        "Alerts are information, not advice.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoneRow(zone: DashboardZone) {
    val tone = if (zone.isBuyer) BuyerTone else SellerTone

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 4.dp, height = 34.dp)
                .background(tone, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                zone.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                if (zone.isBuyer) "Expected support" else "Expected resistance",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            PriceFormat.money(zone.price),
            style = MaterialTheme.typography.titleMedium,
            color = tone,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun feedTone(label: FeedLabel): Color = when (label) {
    FeedLabel.LIVE -> BuyerTone
    FeedLabel.DELAYED -> Color(0xFFE0A800)
    FeedLabel.OFFLINE -> SellerTone
    FeedLabel.CONNECTING -> Color(0xFF8B93A1)
}
