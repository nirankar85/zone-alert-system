package com.trendanalyzer.one.ui.navigation

import androidx.compose.runtime.mutableStateListOf

/** A back stack small enough to read. No library, no saved state surprises. */
class Navigator(initial: AppScreen) {

    private val stack = mutableStateListOf<AppScreen>(initial)

    fun current(): AppScreen = stack.last()

    fun canGoBack(): Boolean = stack.size > 1

    fun push(screen: AppScreen) {
        if (stack.last() == screen) return
        stack.add(screen)
    }

    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.lastIndex)
        return true
    }

    fun resetTo(screen: AppScreen) {
        stack.clear()
        stack.add(screen)
    }

    fun depth(): Int = stack.size
}
