package com.trendanalyzer.one.ui.model

import com.trendanalyzer.one.account.AccountRepository
import com.trendanalyzer.one.account.AccountUser
import com.trendanalyzer.one.log.Logx
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Owns "who is signed in" for the screens, and nothing else. */
class SessionController(
    private val account: AccountRepository,
    private val scope: CoroutineScope
) {

    private val _user = MutableStateFlow<AccountUser?>(null)
    val user: StateFlow<AccountUser?> = _user.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun restore() {
        scope.launch {
            _busy.value = true
            _user.value = runCatching { account.restoreSession() }
                .onFailure { Logx.w(TAG, "session restore failed") }
                .getOrNull()
            _busy.value = false
        }
    }

    fun loginOwner(email: String, password: String, onResult: (String?) -> Unit) {
        scope.launch {
            _busy.value = true
            val result = account.loginOwner(email, password)
            if (result.user != null) _user.value = result.user
            _busy.value = false
            onResult(result.error)
        }
    }

    fun loginClient(clientId: String, password: String, onResult: (String?) -> Unit) {
        scope.launch {
            _busy.value = true
            val result = account.loginClient(clientId, password)
            if (result.user != null) _user.value = result.user
            _busy.value = false
            onResult(result.error)
        }
    }

    fun logout(onDone: () -> Unit) {
        scope.launch {
            runCatching { account.logout() }
            _user.value = null
            onDone()
        }
    }

    private companion object {
        const val TAG = "SessionController"
    }
}
