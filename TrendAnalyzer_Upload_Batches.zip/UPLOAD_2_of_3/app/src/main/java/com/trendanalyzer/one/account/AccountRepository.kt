package com.trendanalyzer.one.account

import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock

/**
 * The whole account story in one place: who is signed in, what a client may see, and what the owner
 * may change. Entitlements always fail closed.
 */
class AccountRepository(
    private val auth: FirebaseAuthGateway,
    private val firestore: FirestoreAccountDataSource,
    private val cache: ClientCacheStore,
    private val session: SessionStore,
    private val clock: AppClock
) {

    suspend fun restoreSession(): AccountUser? {
        val stored = session.read() ?: return null
        if (!auth.isSignedIn() || auth.currentUid() != stored.uid) {
            session.clear()
            return null
        }

        return stored
    }

    suspend fun loginOwner(email: String, password: String): LoginResult {
        val trimmed = email.trim()
        if (trimmed.isBlank() || password.isEmpty()) {
            return LoginResult(null, AccountException.InvalidCredentials().message)
        }

        return try {
            val uid = auth.signIn(trimmed, password)

            if (!firestore.isOwner(uid)) {
                auth.signOut()
                return LoginResult(null, AccountException.NotAnOwner().message)
            }

            val user = AccountUser(uid, AccountRole.OWNER, null, "Owner")
            session.save(user)
            LoginResult(user, null)
        } catch (error: Throwable) {
            LoginResult(null, AccountException.messageFor(error))
        }
    }

    suspend fun loginClient(clientIdInput: String, password: String): LoginResult {
        val clientId = ClientIdentity.normalize(clientIdInput)

        if (!ClientIdentity.isValid(clientId)) {
            return LoginResult(null, "That client ID does not look right.")
        }
        if (password.isEmpty()) {
            return LoginResult(null, "Please enter the password.")
        }

        return try {
            val uid = auth.signIn(ClientIdentity.emailFor(clientId), password)
            val profile = firestore.readClient(clientId)

            if (profile == null) {
                auth.signOut()
                return LoginResult(null, "This client is not set up yet.")
            }

            when (profile.entitlements().state(clock.nowMillis())) {
                ClientAccessState.ACTIVE -> Unit
                ClientAccessState.DISABLED -> {
                    auth.signOut()
                    return LoginResult(null, AccountException.DisabledAccount().message)
                }
                ClientAccessState.EXPIRED -> {
                    auth.signOut()
                    return LoginResult(null, AccountException.ExpiredAccount().message)
                }
                ClientAccessState.NO_GRADES -> {
                    auth.signOut()
                    return LoginResult(null, AccountException.NoGrades().message)
                }
            }

            val storedHash = firestore.readPasswordHash(clientId)
            if (storedHash != null && !PasswordHasher.verify(password, storedHash)) {
                auth.signOut()
                return LoginResult(null, AccountException.InvalidCredentials().message)
            }

            cache.save(profile)

            val user = AccountUser(uid, AccountRole.CLIENT, clientId, profile.displayName)
            session.save(user)
            LoginResult(user, null)
        } catch (error: Throwable) {
            LoginResult(null, AccountException.messageFor(error))
        }
    }

    @Volatile
    private var lastRemoteRefreshAtMillis = 0L

    suspend fun logout() {
        runCatching { auth.signOut() }
        session.clear()
    }

    suspend fun currentClient(): ClientProfile? {
        val user = session.read() ?: return null
        val clientId = user.clientId ?: return null

        val cached = cache.get(clientId)
        val now = clock.nowMillis()
        if (cached != null && now - lastRemoteRefreshAtMillis < REMOTE_REFRESH_MILLIS) {
            return cached
        }

        // At most one cloud read a minute: the owner's disable or a new expiry reaches the phone
        // quickly without turning a 1.5 second dashboard tick into a network loop.
        lastRemoteRefreshAtMillis = now
        val remote = firestore.readClient(clientId)
        if (remote != null) cache.save(remote)
        return remote ?: cached
    }

    suspend fun refreshClient(): ClientProfile? {
        val user = session.read() ?: return null
        val clientId = user.clientId ?: return null

        val remote = firestore.readClient(clientId)
        if (remote != null) cache.save(remote)
        return remote ?: cache.get(clientId)
    }

    suspend fun adminListClients(): List<ClientProfile> {
        val remote = firestore.listClients()
        if (remote.isNotEmpty()) cache.saveAll(remote)

        val cached = cache.all()
        val merged = (remote + cached).distinctBy { it.clientId }
        return merged.sortedBy { it.displayName.lowercase() }
    }

    suspend fun adminCreateClient(
        clientIdInput: String,
        displayName: String,
        visibleGrades: Int,
        days: Int,
        password: String
    ): Result<ClientProfile> {
        val clientId = ClientIdentity.normalize(clientIdInput)

        if (!ClientIdentity.isValid(clientId)) return Result.failure(AccountException.Unknown(null))
        if (password.length < MIN_PASSWORD_LENGTH) return Result.failure(AccountException.Unknown(null))

        return runCatching {
            val uid = auth.createClientAccount(ClientIdentity.emailFor(clientId), password)
            val now = clock.nowMillis()

            val profile = ClientProfile(
                clientId = clientId,
                displayName = displayName.trim().ifBlank { clientId },
                visibleGrades = Entitlements.clampVisibleGrades(visibleGrades),
                expiresAtMillis = Entitlements.expiryFromDays(days, now),
                enabled = true,
                plan = "standard",
                uid = uid,
                hasPasswordRecord = true
            )

            val hash = PasswordHasher.hash(password)
            firestore.writeClient(profile, hash, now)
            cache.save(profile)
            profile
        }.onFailure { error ->
            Logx.w(TAG, "client creation failed: ${error::class.java.simpleName}")
        }
    }

    suspend fun adminUpdateClient(
        clientId: String,
        visibleGrades: Int,
        days: Int,
        enabled: Boolean
    ): Result<Unit> = runCatching {
        // Prefer the remote record: it carries the client's auth uid, and the local cache does not.
        // Writing a cached profile back would blank that uid and break the client's own read rule.
        val current = firestore.readClient(clientId) ?: cache.get(clientId)
            ?: throw AccountException.Unknown(null)

        val updated = current.copy(
            visibleGrades = Entitlements.clampVisibleGrades(visibleGrades),
            expiresAtMillis = Entitlements.expiryFromDays(days, clock.nowMillis()),
            enabled = enabled
        )

        val existingHash = firestore.readPasswordHash(clientId)
        firestore.writeClient(updated, existingHash, clock.nowMillis())
        cache.save(updated)
    }

    suspend fun adminDeleteClient(clientId: String): Result<Unit> = runCatching {
        firestore.deleteClient(clientId)
        cache.remove(clientId)
    }

    suspend fun adminRefreshClient(clientId: String): ClientProfile? {
        val remote = firestore.readClient(clientId) ?: return null
        cache.save(remote)
        return remote
    }

    suspend fun isOwnerSignedIn(): Boolean = session.read()?.role == AccountRole.OWNER

    /**
     * Which grades may produce speech on this phone. Null means the owner and the whole ladder;
     * a set means a client, and an empty set means no speech at all. Used by the engine itself so
     * a hidden grade never reaches the alert path, not merely the screen.
     */
    suspend fun visibleGradesForAlerts(nowMillis: Long): Set<Int>? {
        val user = session.read() ?: return emptySet()
        if (user.role == AccountRole.OWNER) return null

        val profile = currentClient() ?: return emptySet()
        val entitlements = profile.entitlements()
        return if (entitlements.isActive(nowMillis)) entitlements.visibleRange.toSet() else emptySet()
    }

    companion object {
        const val MIN_PASSWORD_LENGTH = 8
        private const val REMOTE_REFRESH_MILLIS = 60_000L
        private const val TAG = "AccountRepository"
    }
}
