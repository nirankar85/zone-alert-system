package com.trendanalyzer.one.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trendanalyzer.one.ui.components.PrimaryButton
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.theme.BuyerTone

@Composable
fun OpeningScreen(
    onStart: () -> Unit,
    onSupport: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                "TREND ANALYZER 1%",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "Seven gold levels. One calm voice when price is in reach.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                "Read only. This app never places, changes or closes a trade.",
                style = MaterialTheme.typography.bodyMedium,
                color = BuyerTone
            )
            Spacer(modifier = Modifier.height(36.dp))
            PrimaryButton(text = "Continue", onClick = onStart)
            Spacer(modifier = Modifier.height(10.dp))
            SecondaryButton(text = "Contact support", onClick = onSupport)
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                "Access is given by the owner.",
                style = MaterialTheme.typography.labelSmall
                    .copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
