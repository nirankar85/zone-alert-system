package com.trendanalyzer.one.account

enum class AccountRole { OWNER, CLIENT }

/** What the app knows about one client, whether it came from the cloud or from the local cache. */
data class ClientProfile(
    val clientId: String,
    val displayName: String,
    val visibleGrades: Int,
    val expiresAtMillis: Long,
    val enabled: Boolean,
    val plan: String,
    val uid: String = "",
    val hasPasswordRecord: Boolean = false
) {
    fun entitlements(): Entitlements = Entitlements(
        visibleGrades = visibleGrades,
        expiresAtMillis = expiresAtMillis,
        enabled = enabled
    )
}

data class AccountUser(
    val uid: String,
    val role: AccountRole,
    val clientId: String?,
    val displayName: String
)

data class LoginResult(
    val user: AccountUser?,
    val error: String?
) {
    fun isSuccess(): Boolean = user != null
}
