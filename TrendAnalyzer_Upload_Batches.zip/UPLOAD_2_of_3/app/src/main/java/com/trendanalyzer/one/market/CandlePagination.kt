package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig

/** Page arithmetic for the history endpoint, kept separate so it can be tested on its own. */
object CandlePagination {

    fun pageSize(): Int = AppConfig.MAX_CANDLES_PER_REQUEST

    fun pagesNeeded(requested: Int, pageSize: Int = pageSize()): Int {
        if (requested <= 0) return 0
        return (requested + pageSize - 1) / pageSize
    }

    fun endMillis(nowMillis: Long, durationMillis: Long): Long {
        val boundary = durationMillis.coerceAtLeast(1L)
        val next = ((nowMillis / boundary) + 1L) * boundary
        return next
    }

    fun startMillis(endMillis: Long, durationMillis: Long, count: Int): Long {
        return endMillis - durationMillis.coerceAtLeast(1L) * count.coerceAtLeast(1)
    }
}
