package com.trendanalyzer.one.data

import com.trendanalyzer.one.data.db.dao.AlertLogDao
import com.trendanalyzer.one.data.db.entity.AlertLogEntity
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.notify.AlertLogRecord
import com.trendanalyzer.one.notify.AlertLogWriter

class AlertLogRoomWriter(private val dao: AlertLogDao) : AlertLogWriter {

    override suspend fun write(record: AlertLogRecord): Long =
        runCatching {
            dao.insert(
                AlertLogEntity(
                    createdAtMillis = record.createdAtMillis,
                    speech = record.speech,
                    title = record.title,
                    body = record.body,
                    zoneIds = record.zoneIds,
                    zoneGrades = record.zoneGrades,
                    notified = record.notified,
                    spoken = record.spoken,
                    alexaStatus = record.alexaStatus
                )
            )
        }.getOrElse { error ->
            Logx.w(TAG, "alert history write failed: ${error::class.java.simpleName}")
            0L
        }

    private companion object {
        const val TAG = "AlertLogRoomWriter"
    }
}
