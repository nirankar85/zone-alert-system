package com.trendanalyzer.one.market

import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock

/**
 * The venue's mark price by request, for the minutes when the socket is silent. It is a fallback,
 * not a second source of truth: it is only asked while the stream is not live.
 */
class TickerFallbackPoller(
    private val rest: DeltaRestClient,
    private val clock: AppClock
) {

    suspend fun pollOnce(): PriceTick? {
        return runCatching { rest.markPrice() }
            .onFailure { Logx.w(TAG, "ticker fallback failed: ${it::class.java.simpleName}") }
            .getOrNull()
            ?.takeIf { it > 0.0 }
            ?.let { PriceTick(it, clock.nowMillis(), PriceSource.TICKER) }
    }

    private companion object {
        const val TAG = "TickerFallbackPoller"
    }
}
