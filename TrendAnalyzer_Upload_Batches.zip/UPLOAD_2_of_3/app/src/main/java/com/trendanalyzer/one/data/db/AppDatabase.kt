package com.trendanalyzer.one.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.trendanalyzer.one.data.db.dao.AlexaCounterDao
import com.trendanalyzer.one.data.db.dao.AlertLogDao
import com.trendanalyzer.one.data.db.dao.CandleDao
import com.trendanalyzer.one.data.db.dao.ClientCacheDao
import com.trendanalyzer.one.data.db.dao.SettingsDao
import com.trendanalyzer.one.data.db.dao.ZoneStateDao
import com.trendanalyzer.one.data.db.entity.AlexaCounterEntity
import com.trendanalyzer.one.data.db.entity.AlertLogEntity
import com.trendanalyzer.one.data.db.entity.CandleEntity
import com.trendanalyzer.one.data.db.entity.ClientCacheEntity
import com.trendanalyzer.one.data.db.entity.SettingsEntity
import com.trendanalyzer.one.data.db.entity.ZoneStateEntity

@Database(
    entities = [
        CandleEntity::class,
        ZoneStateEntity::class,
        AlertLogEntity::class,
        AlexaCounterEntity::class,
        SettingsEntity::class,
        ClientCacheEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun candleDao(): CandleDao
    abstract fun zoneStateDao(): ZoneStateDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun alexaCounterDao(): AlexaCounterDao
    abstract fun settingsDao(): SettingsDao
    abstract fun clientCacheDao(): ClientCacheDao

    companion object {

        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "trend_analyzer.db"
                ).build().also { instance = it }
            }
    }
}
