package com.trendanalyzer.one.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alexa_counter")
data class AlexaCounterEntity(
    @PrimaryKey val monthKey: String,
    val announcements: Int,
    val monthlyLimit: Int,
    val lastAnnouncementAtMillis: Long,
    val updatedAtMillis: Long
)
