package com.trendanalyzer.one.account

import com.google.android.gms.tasks.Task
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Bridges a Google task to a coroutine without pulling in another dependency. */
internal suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        if (task.isSuccessful) {
            @Suppress("UNCHECKED_CAST")
            val value = task.result as T
            continuation.resume(value)
        } else {
            continuation.resumeWithException(task.exception ?: IllegalStateException("task failed"))
        }
    }
}

internal suspend fun Task<Void>.awaitDone(): Unit = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        if (task.isSuccessful) continuation.resume(Unit)
        else continuation.resumeWithException(task.exception ?: IllegalStateException("task failed"))
    }
}
