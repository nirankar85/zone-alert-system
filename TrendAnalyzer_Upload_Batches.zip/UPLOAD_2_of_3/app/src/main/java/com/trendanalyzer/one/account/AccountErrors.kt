package com.trendanalyzer.one.account

/** Messages a client may read. They say what happened and never why in technical terms. */
sealed class AccountException(message: String) : Exception(message) {

    class InvalidCredentials : AccountException("That ID or password is not correct.")

    class DisabledAccount : AccountException("This account is switched off. Please contact the owner.")

    class ExpiredAccount : AccountException("This account has ended. Please contact the owner.")

    class NoGrades : AccountException("No grades are open on this account. Please contact the owner.")

    class NotAnOwner : AccountException("This account is not the owner account.")

    class Network : AccountException("No connection. Please try again when the phone is online.")

    class Unknown(cause: Throwable?) : AccountException("Something went wrong. Please try again.")

    companion object {
        fun messageFor(error: Throwable): String = when (error) {
            is AccountException -> error.message ?: "Something went wrong. Please try again."
            else -> "Something went wrong. Please try again."
        }
    }
}
