package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.ZoneStateEntity

@Dao
interface ZoneStateDao {

    @Query("SELECT * FROM zone_state")
    suspend fun all(): List<ZoneStateEntity>

    @Query("SELECT * FROM zone_state WHERE zoneId = :zoneId LIMIT 1")
    suspend fun get(zoneId: String): ZoneStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: ZoneStateEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rows: List<ZoneStateEntity>)

    @Query("DELETE FROM zone_state")
    suspend fun clear()
}
