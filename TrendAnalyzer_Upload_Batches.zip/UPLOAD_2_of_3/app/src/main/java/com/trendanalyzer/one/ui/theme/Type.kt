package com.trendanalyzer.one.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AppTypography = Typography()

val PriceSmallStyle = TextStyle(
    fontWeight = FontWeight.SemiBold,
    fontSize = 15.sp,
    letterSpacing = 0.sp
)

val PriceLargeStyle = TextStyle(
    fontWeight = FontWeight.SemiBold,
    fontSize = 34.sp,
    letterSpacing = (-0.5).sp
)
