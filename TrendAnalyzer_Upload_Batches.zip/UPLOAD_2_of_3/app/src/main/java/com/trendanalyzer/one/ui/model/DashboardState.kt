package com.trendanalyzer.one.ui.model

import com.trendanalyzer.one.account.AccountRole
import com.trendanalyzer.one.market.FeedHealth

enum class FeedLabel { CONNECTING, LIVE, DELAYED, OFFLINE }

object FeedLabels {

    fun from(health: FeedHealth): FeedLabel = when (health) {
        FeedHealth.LIVE -> FeedLabel.LIVE
        FeedHealth.STALE -> FeedLabel.DELAYED
        FeedHealth.DOWN -> FeedLabel.OFFLINE
        FeedHealth.UNKNOWN -> FeedLabel.CONNECTING
    }

    fun text(value: FeedLabel): String = when (value) {
        FeedLabel.CONNECTING -> "Connecting"
        FeedLabel.LIVE -> "Live"
        FeedLabel.DELAYED -> "Price delayed"
        FeedLabel.OFFLINE -> "Offline"
    }
}

data class DashboardZone(
    val zoneId: String,
    val name: String,
    val grade: Int,
    val price: Double,
    val isBuyer: Boolean
)

data class DashboardState(
    val loading: Boolean = true,
    val userName: String = "",
    val role: AccountRole? = null,
    val zones: List<DashboardZone> = emptyList(),
    val lastPrice: Double? = null,
    val lastPriceText: String = "—",
    val feedLabel: FeedLabel = FeedLabel.CONNECTING,
    val watching: Boolean = false,
    val accessMessage: String? = null,
    val accessHint: String = "",
    val error: String? = null,
    val isOwner: Boolean = false,
    val clientId: String? = null,
    val updatedAtMillis: Long = 0L
)
