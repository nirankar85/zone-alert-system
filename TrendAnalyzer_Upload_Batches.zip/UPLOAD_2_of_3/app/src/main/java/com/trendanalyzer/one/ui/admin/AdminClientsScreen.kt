package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.account.ClientProfile
import com.trendanalyzer.one.account.Entitlements
import com.trendanalyzer.one.ui.components.EmptyNote
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.PrimaryButton
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.components.SectionCard

@Composable
fun AdminClientsScreen(
    controller: AdminController,
    onOpenClient: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val clients by controller.clients.collectAsState()
    val busy by controller.busy.collectAsState()
    val message by controller.message.collectAsState()

    var showCreate by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { controller.loadClients() }

    ScreenScaffold(title = "Clients", subtitle = "${clients.size} known", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            if (message != null) {
                Text(
                    message!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            SectionCard(title = "Add a client") {
                SecondaryButton(
                    text = if (showCreate) "Close form" else "New client",
                    onClick = {
                        showCreate = !showCreate
                        controller.clearMessage()
                    }
                )
                if (showCreate) {
                    Spacer(modifier = Modifier.height(10.dp))
                    CreateClientForm(busy = busy) { id, name, grades, days, password ->
                        controller.createClient(id, name, grades, days, password) { _ -> }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (clients.isEmpty()) {
                EmptyNote("No clients yet. Add the first one above.")
            }

            clients.forEach { client ->
                SectionCard(modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(
                        client.displayName,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        "ID ${client.clientId}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyValueRow(
                        label = "Visible grades",
                        value = client.entitlements().visibleRange.let { range ->
                            if (range.isEmpty()) "None" else "${range.first} to ${range.last}"
                        }
                    )
                    KeyValueRow(
                        label = "Expiry",
                        value = if (client.expiresAtMillis <= 0L) "No end" else "Set"
                    )
                    TextButton(
                        onClick = { onOpenClient(client.clientId) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Open") }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CreateClientForm(
    busy: Boolean,
    onCreate: (String, String, Int, Int, String) -> Unit
) {
    var clientId by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var grades by remember { mutableStateOf("4") }
    var days by remember { mutableStateOf("30") }
    var password by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = clientId,
            onValueChange = { clientId = it },
            label = { Text("Client ID (lowercase letters, digits, - or _)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = grades,
            onValueChange = { grades = it },
            label = { Text("Visible grades (1 to 7, highest first)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = days,
            onValueChange = { days = it },
            label = { Text("Days (0 means no end)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (at least 8 characters)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(10.dp))
        PrimaryButton(
            text = "Add client",
            enabled = !busy && clientId.isNotBlank() && password.length >= 8,
            onClick = {
                onCreate(
                    clientId,
                    displayName,
                    grades.toIntOrNull() ?: 4,
                    days.toIntOrNull() ?: 30,
                    password
                )
            }
        )
    }
}

@Composable
fun AdminClientDetailScreen(
    clientId: String,
    controller: AdminController,
    onDeleted: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var profile by remember { mutableStateOf<ClientProfile?>(null) }
    var grades by remember { mutableStateOf("4") }
    var days by remember { mutableStateOf("30") }
    var enabled by remember { mutableStateOf(true) }
    var showDelete by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    val busy by controller.busy.collectAsState()
    val message by controller.message.collectAsState()

    LaunchedEffect(clientId) {
        val loadedProfile = controller.loadClient(clientId)
        profile = loadedProfile
        if (loadedProfile != null) {
            grades = loadedProfile.entitlements().effectiveGrades.toString()
            days = if (loadedProfile.expiresAtMillis <= 0L) {
                "0"
            } else {
                loadedProfile.entitlements().daysRemaining(controller.clock.nowMillis()).toString()
            }
            enabled = loadedProfile.enabled
        }
        loaded = true
    }

    ScreenScaffold(title = profile?.displayName ?: clientId, subtitle = "ID $clientId", onBack = onBack) {
        if (!loaded) {
            Text("Loading…", style = MaterialTheme.typography.bodySmall)
            return@ScreenScaffold
        }

        if (profile == null) {
            EmptyNote("This client could not be read. Check the connection and try again.")
            return@ScreenScaffold
        }

        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            if (message != null) {
                Text(message!!, style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(8.dp))
            }

            SectionCard(title = "Access") {
                OutlinedTextField(
                    value = grades,
                    onValueChange = { grades = it },
                    label = { Text("Visible grades (0 to 7)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = days,
                    onValueChange = { days = it },
                    label = { Text("Days from today (0 means no end)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                AdminSwitchRow(
                    label = "Account enabled",
                    description = "Off blocks sign in even before expiry.",
                    checked = enabled,
                    onCheckedChange = { enabled = it }
                )
                Spacer(modifier = Modifier.height(6.dp))
                AdminNote(
                    "Visible grades works from the top down. Four grades shows the 4th to the 7th."
                )
                Spacer(modifier = Modifier.height(8.dp))
                PrimaryButton(
                    text = "Save changes",
                    enabled = !busy,
                    onClick = {
                        controller.updateClient(
                            clientId = clientId,
                            visibleGrades = grades.toIntOrNull() ?: 0,
                            days = days.toIntOrNull() ?: 0,
                            enabled = enabled
                        ) { }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Remove") {
                AdminNote(
                    "Removing a client deletes the record here and in the cloud. The sign-in on that phone stops working."
                )
                SecondaryButton(text = "Remove client", onClick = { showDelete = true })
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Remove this client?") },
            text = { Text("This cannot be undone from the app.") },
            confirmButton = {
                TextButton(onClick = {
                    showDelete = false
                    controller.deleteClient(clientId) { success -> if (success) onDeleted() }
                }) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) { Text("Cancel") }
            }
        )
    }
}
