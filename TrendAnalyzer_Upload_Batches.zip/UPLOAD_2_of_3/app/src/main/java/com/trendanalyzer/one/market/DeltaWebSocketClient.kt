package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

/**
 * A price stream that reconnects by being collected again. Nothing here decides when to stop;
 * the owner does, through the service.
 */
class DeltaWebSocketClient(
    private val http: OkHttpClient = defaultClient(),
    private val clock: AppClock,
    private val url: String = AppConfig.WS_URL
) {

    fun prices(symbol: String = AppConfig.SYMBOL): Flow<PriceTick> = callbackFlow {
        val request = Request.Builder().url(url).build()

        val listener = object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                val payload = """{"type":"subscribe","payload":{"channels":[{"name":"v2/ticker","symbols":["$symbol"]}]}}"""
                webSocket.send(payload)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val price = WsMessageParser.parsePrice(text) ?: return
                if (price <= 0.0) return
                runCatching { trySend(PriceTick(price, clock.nowMillis(), PriceSource.STREAM)) }
            }

            override fun onFailure(webSocket: WebSocket, error: Throwable, response: Response?) {
                Logx.w(TAG, "socket failed: ${error::class.java.simpleName}")
                runCatching { close(error) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runCatching { close() }
            }
        }

        val socket = http.newWebSocket(request, listener)

        awaitClose {
            runCatching { socket.close(1000, "client closed") }
        }
    }

    companion object {
        private const val TAG = "DeltaWebSocketClient"

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
