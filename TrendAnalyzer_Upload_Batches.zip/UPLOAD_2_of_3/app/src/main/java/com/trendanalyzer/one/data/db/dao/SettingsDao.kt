package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.SettingsEntity

@Dao
interface SettingsDao {

    @Query("SELECT * FROM settings")
    suspend fun all(): List<SettingsEntity>

    @Query("SELECT settingValue FROM settings WHERE settingKey = :key LIMIT 1")
    suspend fun value(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SettingsEntity)

    @Query("DELETE FROM settings WHERE settingKey = :key")
    suspend fun delete(key: String)

    @Query("DELETE FROM settings")
    suspend fun clear()
}
