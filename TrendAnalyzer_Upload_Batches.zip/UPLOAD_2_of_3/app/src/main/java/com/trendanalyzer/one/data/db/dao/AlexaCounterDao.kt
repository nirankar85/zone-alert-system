package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.AlexaCounterEntity

@Dao
interface AlexaCounterDao {

    @Query("SELECT * FROM alexa_counter WHERE monthKey = :monthKey LIMIT 1")
    suspend fun get(monthKey: String): AlexaCounterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: AlexaCounterEntity)

    @Query("DELETE FROM alexa_counter")
    suspend fun clear()
}
