package com.trendanalyzer.one.ui.model

import com.trendanalyzer.one.engine.ZoneReading
import com.trendanalyzer.one.market.FeedHealth

/** What a dashboard needs from the engine, with nothing else attached. */
interface DashboardSource {
    fun readings(): List<ZoneReading>
    fun price(): Double?
    fun health(): FeedHealth
}
