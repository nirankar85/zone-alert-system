package com.trendanalyzer.one.ui.chart

import com.trendanalyzer.one.config.ChartTimeframes
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChartViewModel(
    private val source: ChartDataSource,
    private val settings: SettingsRepository,
    private val clock: AppClock,
    private val scope: CoroutineScope
) {

    data class State(
        val loading: Boolean = true,
        val payload: String? = null,
        val error: String? = null,
        val timeframe: String = "5m",
        val visibleTimeframes: List<String> = ChartTimeframes.visibleToClients
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            try {
                val preferred = runCatching { settings.current().chartTimeframe }
                    .getOrDefault(ChartTimeframes.visibleToClients.first())
                load(if (ChartTimeframes.isVisible(preferred)) preferred else ChartTimeframes.visibleToClients.first())
            } finally {
                job = null
            }
        }
    }

    fun refresh() {
        scope.launch { load(_state.value.timeframe) }
    }

    fun selectTimeframe(timeframe: String) {
        if (!ChartTimeframes.isVisible(timeframe)) return
        scope.launch {
            runCatching { settings.setChartTimeframe(timeframe) }
            load(timeframe)
        }
    }

    private suspend fun load(timeframe: String) {
        _state.update { it.copy(loading = true, error = null, timeframe = timeframe) }

        runCatching {
            val candles = source.candles(timeframe, CANDLE_LIMIT)
            val levels = source.levels()

            if (candles.isEmpty()) {
                throw IllegalStateException("no candles")
            }

            ChartJson.payload("Gold", timeframe, candles, levels)
        }.onSuccess { payload ->
            _state.update { it.copy(loading = false, payload = payload, error = null) }
        }.onFailure { error ->
            Logx.w(TAG, "chart load failed: ${error::class.java.simpleName}")
            _state.update {
                it.copy(
                    loading = false,
                    error = if (it.payload == null) "Chart data is not ready." else null
                )
            }
        }
    }

    private companion object {
        const val TAG = "ChartViewModel"
        const val CANDLE_LIMIT = 400
    }
}
