package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class RateLimitedException(val retryAfterMillis: Long) : Exception("rate limited")

/**
 * One gate for the whole process. When the venue answers 429 the gate holds every caller until
 * the reset moment, which is usually a duration in seconds but is tolerated as an epoch too.
 */
class RateLimitGate(private val clock: AppClock) {

    private val mutex = Mutex()
    private var pausedUntilMillis: Long = 0L

    suspend fun awaitTurn() {
        while (true) {
            val waitMillis = mutex.withLock { pausedUntilMillis - clock.nowMillis() }
            if (waitMillis <= 0L) return
            delay(waitMillis.coerceAtMost(MAX_WAIT_MILLIS))
        }
    }

    suspend fun noteRateLimit(resetHeader: String?) {
        val parsed = parseResetMillis(resetHeader)
        mutex.withLock {
            pausedUntilMillis = maxOf(pausedUntilMillis, parsed)
        }
    }

    fun parseResetMillis(header: String?): Long {
        val now = clock.nowMillis()
        val value = header?.trim()?.toDoubleOrNull() ?: return now + DEFAULT_PAUSE_MILLIS

        val until = if (value > 100_000_000.0) {
            value.toLong()
        } else {
            now + (value * 1_000.0).toLong()
        }

        return until.coerceIn(now, now + MAX_PAUSE_MILLIS)
    }

    private companion object {
        const val MAX_PAUSE_MILLIS = AppConfig.RATE_LIMIT_FALLBACK_SECONDS * 1_000L
        const val DEFAULT_PAUSE_MILLIS = 30_000L
        const val MAX_WAIT_MILLIS = 5_000L
    }
}
