package com.trendanalyzer.one.ui.navigation

sealed interface AppScreen {
    data object Opening : AppScreen
    data object Login : AppScreen
    data object Dashboard : AppScreen
    data object Settings : AppScreen
    data object Chart : AppScreen

    data object AdminHome : AppScreen
    data object AdminClients : AppScreen
    data class AdminClientDetail(val clientId: String) : AppScreen
    data object AdminAlerts : AppScreen
    data object AdminVoice : AppScreen
    data object AdminSystem : AppScreen
    data object AdminHealth : AppScreen
    data object AdminHistory : AppScreen
    data object AdminSecurity : AppScreen
}
