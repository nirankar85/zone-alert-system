package com.trendanalyzer.one.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "client_cache")
data class ClientCacheEntity(
    @PrimaryKey val clientId: String,
    val displayName: String,
    val visibleGrades: Int,
    val expiresAtMillis: Long,
    val enabled: Boolean,
    val role: String,
    val plan: String,
    val hasPasswordRecord: Boolean,
    val updatedAtMillis: Long
)
