package com.trendanalyzer.one.market

/**
 * Turns silence into a state the screens can show. Nothing is inferred from a closed socket that
 * a user could not see: a feed that stops talking becomes Stale, then Down.
 */
class FeedHealthMonitor(
    private val staleAfterMillis: Long,
    private val downAfterMillis: Long
) {

    fun evaluate(lastMessageAtMillis: Long, nowMillis: Long): FeedHealth {
        if (lastMessageAtMillis <= 0L) return FeedHealth.UNKNOWN

        val age = nowMillis - lastMessageAtMillis
        return when {
            age <= staleAfterMillis -> FeedHealth.LIVE
            age <= downAfterMillis -> FeedHealth.STALE
            else -> FeedHealth.DOWN
        }
    }
}