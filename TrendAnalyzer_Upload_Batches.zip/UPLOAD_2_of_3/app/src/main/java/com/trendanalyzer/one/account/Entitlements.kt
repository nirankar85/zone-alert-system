package com.trendanalyzer.one.account

enum class ClientAccessState { ACTIVE, EXPIRED, DISABLED, NO_GRADES }

/**
 * How much of the ladder a client may see. Seven visible grades means the whole ladder; four means
 * only the top four. A missing or nonsensical number shows nothing, which is the safe direction.
 */
data class Entitlements(
    val visibleGrades: Int,
    val expiresAtMillis: Long,
    val enabled: Boolean = true
) {

    val effectiveGrades: Int
        get() = visibleGrades.coerceIn(0, 7)

    val visibleRange: IntRange
        get() = if (effectiveGrades <= 0) IntRange.EMPTY else (8 - effectiveGrades)..7

    fun state(nowMillis: Long): ClientAccessState {
        if (!enabled) return ClientAccessState.DISABLED
        if (effectiveGrades <= 0) return ClientAccessState.NO_GRADES
        if (expiresAtMillis > 0L && expiresAtMillis <= nowMillis) return ClientAccessState.EXPIRED
        return ClientAccessState.ACTIVE
    }

    fun isActive(nowMillis: Long): Boolean = state(nowMillis) == ClientAccessState.ACTIVE

    fun canSee(grade: Int, nowMillis: Long): Boolean {
        if (!isActive(nowMillis)) return false
        return grade in visibleRange
    }

    fun daysRemaining(nowMillis: Long): Long {
        if (expiresAtMillis <= 0L) return Long.MAX_VALUE
        val remaining = expiresAtMillis - nowMillis
        if (remaining <= 0L) return 0L
        return remaining / DAY_MILLIS
    }

    companion object {
        const val DAY_MILLIS = 86_400_000L

        fun clampVisibleGrades(value: Int): Int = value.coerceIn(0, 7)

        fun expiryFromDays(days: Int, nowMillis: Long): Long {
            if (days <= 0) return 0L
            return nowMillis + days.toLong() * DAY_MILLIS
        }
    }
}
