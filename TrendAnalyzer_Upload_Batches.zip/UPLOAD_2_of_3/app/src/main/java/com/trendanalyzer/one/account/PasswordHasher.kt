package com.trendanalyzer.one.account

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * A salted, slow hash kept as a second opinion beside the authentication service. It is never the
 * only lock, and it is never reversible.
 */
object PasswordHasher {

    const val DEFAULT_ITERATIONS = 120_000
    private const val KEY_BITS = 256
    private const val SALT_BYTES = 16
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val PREFIX = "pbkdf2_sha256"

    fun randomSalt(): ByteArray {
        val salt = ByteArray(SALT_BYTES)
        SecureRandom().nextBytes(salt)
        return salt
    }

    fun hash(password: String, iterations: Int = DEFAULT_ITERATIONS, salt: ByteArray = randomSalt()): String {
        require(password.isNotEmpty()) { "password must not be empty" }
        require(iterations >= 10_000) { "iterations too low" }

        val derived = derive(password, salt, iterations)
        val encoder = Base64.getEncoder().withoutPadding()

        return listOf(
            PREFIX,
            iterations.toString(),
            encoder.encodeToString(salt),
            encoder.encodeToString(derived)
        ).joinToString("$")
    }

    fun verify(password: String, encoded: String): Boolean {
        if (password.isEmpty()) return false

        val parts = encoded.split('$')
        if (parts.size != 4 || parts[0] != PREFIX) return false

        val iterations = parts[1].toIntOrNull() ?: return false
        if (iterations < 10_000) return false

        return runCatching {
            val decoder = Base64.getDecoder()
            val salt = decoder.decode(parts[2])
            val expected = decoder.decode(parts[3])
            val derived = derive(password, salt, iterations)
            MessageDigest.isEqual(expected, derived)
        }.getOrDefault(false)
    }

    private fun derive(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, KEY_BITS)
        return SecretKeyFactory.getInstance(ALGORITHM).generateSecret(spec).encoded
    }
}
