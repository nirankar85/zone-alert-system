package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * The one place that owns the price. It collects the stream, falls back to the ticker when the
 * stream is quiet, and keeps a state that says honestly how fresh the price is.
 */
class MarketFeed(
    private val rest: DeltaRestClient,
    private val repository: CandleRepository,
    private val settings: SettingsRepository,
    private val clock: AppClock,
    private val socket: DeltaWebSocketClient,
    private val dispatchers: com.trendanalyzer.one.util.DispatchersProvider
) {

    private val scope = CoroutineScope(SupervisorJob() + dispatchers.io)
    private val jobs = mutableListOf<Job>()

    private val _snapshot = MutableStateFlow(MarketSnapshot())
    val snapshot: StateFlow<MarketSnapshot> = _snapshot.asStateFlow()

    private val healthMonitor = FeedHealthMonitor(
        staleAfterMillis = AppConfig.FEED_STALE_SECONDS * 1_000L,
        downAfterMillis = AppConfig.DEAD_MAN_SILENT_SECONDS * 1_000L
    )

    private val poller = TickerFallbackPoller(rest, clock)

    fun start() {
        if (jobs.isNotEmpty()) return

        jobs += scope.launch { streamLoop() }
        jobs += scope.launch { fallbackLoop() }
        jobs += scope.launch { healthLoop() }
    }

    fun stop() {
        jobs.forEach { it.cancel() }
        jobs.clear()
        _snapshot.value = MarketSnapshot(lastPrice = _snapshot.value.lastPrice, health = FeedHealth.DOWN)
    }

    fun isRunning(): Boolean = jobs.isNotEmpty()

    suspend fun candles(resolution: String, limit: Int, force: Boolean = false): List<Candle> =
        repository.load(resolution, limit, force)

    private suspend fun streamLoop() {
        while (scope.isActive) {
            runCatching {
                socket.prices(AppConfig.SYMBOL).collect { tick ->
                    publish(tick)
                }
            }
            if (!scope.isActive) break
            delay(RECONNECT_DELAY_MILLIS)
        }
    }

    private suspend fun fallbackLoop() {
        while (scope.isActive) {
            delay(FALLBACK_INTERVAL_MILLIS)

            val current = _snapshot.value
            val enabled = runCatching { settings.current().tickerFallbackEnabled }.getOrDefault(true)
            val quiet = current.health != FeedHealth.LIVE

            if (enabled && quiet) {
                poller.pollOnce()?.let { tick -> publish(tick) }
            }
        }
    }

    private suspend fun healthLoop() {
        while (scope.isActive) {
            val now = clock.nowMillis()
            val current = _snapshot.value
            val health = healthMonitor.evaluate(current.atMillis, now)

            if (health != current.health) {
                _snapshot.update { it.copy(health = health) }
            }

            delay(HEALTH_INTERVAL_MILLIS)
        }
    }

    private fun publish(tick: PriceTick) {
        _snapshot.update {
            it.copy(
                lastPrice = tick.price,
                health = FeedHealth.LIVE,
                atMillis = tick.atMillis,
                source = tick.source
            )
        }
    }

    private companion object {
        const val RECONNECT_DELAY_MILLIS = 5_000L
        const val FALLBACK_INTERVAL_MILLIS = 10_000L
        const val HEALTH_INTERVAL_MILLIS = 2_000L
    }
}
