package com.trendanalyzer.one.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.config.ChartTimeframes
import com.trendanalyzer.one.config.SettingsRepository
import com.trendanalyzer.one.data.db.entity.AlertLogEntity
import com.trendanalyzer.one.engine.EnginePipeline
import com.trendanalyzer.one.market.FeedHealth
import com.trendanalyzer.one.market.MarketFeed
import com.trendanalyzer.one.service.WatchController
import com.trendanalyzer.one.service.WatchStatus
import com.trendanalyzer.one.ui.components.EmptyNote
import com.trendanalyzer.one.ui.components.KeyValueRow
import com.trendanalyzer.one.ui.components.ScreenScaffold
import com.trendanalyzer.one.ui.components.SecondaryButton
import com.trendanalyzer.one.ui.components.SectionCard
import com.trendanalyzer.one.ui.theme.BuyerTone
import com.trendanalyzer.one.util.PriceFormat
import com.trendanalyzer.one.voice.VoiceHealth
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
fun AdminSystemScreen(
    settingsRepository: SettingsRepository,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val settings by settingsRepository.engineSettings.collectAsState(initial = com.trendanalyzer.one.config.EngineSettings())
    val scope = rememberCoroutineScope()

    var quietStart by remember { mutableStateOf("") }
    var quietEnd by remember { mutableStateOf("") }

    LaunchedEffect(settings.quietHoursStartMinute, settings.quietHoursEndMinute) {
        quietStart = minutesToText(settings.quietHoursStartMinute)
        quietEnd = minutesToText(settings.quietHoursEndMinute)
    }

    ScreenScaffold(title = "System", subtitle = "Feed, hours and chart", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Price feed") {
                AdminSwitchRow(
                    label = "Fallback price",
                    description = "Use the last traded price when the stream is quiet.",
                    checked = settings.tickerFallbackEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { settingsRepository.setTickerFallbackEnabled(enabled) }
                    }
                )
                AdminSwitchRow(
                    label = "Restart watch if silent",
                    description = "Brings the watch back after a long silence.",
                    checked = settings.deadManSwitchEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { settingsRepository.setDeadManSwitchEnabled(enabled) }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Quiet hours") {
                AdminSwitchRow(
                    label = "Quiet hours",
                    description = "Silence speech in this window.",
                    checked = settings.quietHoursEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { settingsRepository.setQuietHoursEnabled(enabled) }
                    }
                )
                OutlinedTextField(
                    value = quietStart,
                    onValueChange = { quietStart = it },
                    label = { Text("Start (HH:MM)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = quietEnd,
                    onValueChange = { quietEnd = it },
                    label = { Text("End (HH:MM)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                SecondaryButton(
                    text = "Save quiet hours",
                    onClick = {
                        val start = textToMinutes(quietStart)
                        val end = textToMinutes(quietEnd)
                        if (start != null && end != null) {
                            scope.launch { settingsRepository.setQuietHours(start, end) }
                        }
                    }
                )
                AdminNote("Times use the phone's own clock.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Chart") {
                AdminNote("Timeframes a client may open.")
                ChartTimeframes.visibleToClients.forEach { timeframe ->
                    TextButton(
                        onClick = { scope.launch { settingsRepository.setChartTimeframe(timeframe) } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (settings.chartTimeframe == timeframe) {
                                "$timeframe  ✓"
                            } else {
                                timeframe
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Line calculation") {
                AdminNote(
                    "Smoothing used when the line is built. The chart site uses the second method; this app defaults to the first."
                )
                AtrSmoothing.entries.forEach { smoothing ->
                    TextButton(
                        onClick = { scope.launch { settingsRepository.setAtrSmoothing(smoothing) } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (settings.atrSmoothing == smoothing) {
                                "${smoothing.name}  ✓"
                            } else {
                                smoothing.name
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "Settings are stored on this phone only.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AdminHealthScreen(
    feed: MarketFeed,
    pipeline: EnginePipeline,
    watch: WatchController,
    voiceHealth: VoiceHealth,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val snapshot by feed.snapshot.collectAsState()
    val zones by pipeline.zones.collectAsState()
    val status by watch.status.collectAsState()
    val voice by voiceHealth.health.collectAsState()

    ScreenScaffold(title = "Health", subtitle = "What the engine sees", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = "Feed") {
                KeyValueRow(
                    label = "Price",
                    value = snapshot.lastPrice?.takeIf { it > 0.0 }?.let { PriceFormat.money(it) } ?: "—"
                )
                KeyValueRow(
                    label = "Health",
                    value = when (snapshot.health) {
                        FeedHealth.LIVE -> "Live"
                        FeedHealth.STALE -> "Delayed"
                        FeedHealth.DOWN -> "Down"
                        FeedHealth.UNKNOWN -> "Starting"
                    },
                    tone = if (snapshot.health == FeedHealth.LIVE) BuyerTone else null
                )
                KeyValueRow(
                    label = "Watch",
                    value = when (status) {
                        WatchStatus.RUNNING -> "Running"
                        WatchStatus.STARTING -> "Starting"
                        WatchStatus.STOPPING -> "Stopping"
                        WatchStatus.STOPPED -> "Stopped"
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Lines now") {
                if (zones.isEmpty()) {
                    EmptyNote("No readings yet. The watch may be off.")
                }
                zones.sortedByDescending { it.grade }.forEach { reading ->
                    KeyValueRow(
                        label = "${reading.grade} grade",
                        value = PriceFormat.money(reading.line)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SectionCard(title = "Voice") {
                KeyValueRow(label = "Phone ready", value = if (voice.phoneReady) "Yes" else "No")
                KeyValueRow(
                    label = "Last Alexa",
                    value = voice.lastAlexaStatus.ifBlank { "—" }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AdminHistoryScreen(
    controller: AdminController,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var rows by remember { mutableStateOf<List<AlertLogEntity>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableStateOf(0) }

    LaunchedEffect(reloadKey) {
        rows = controller.loadAlerts(HISTORY_LIMIT)
        loaded = true
    }

    ScreenScaffold(title = "History", subtitle = "${rows.size} recent alerts", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(8.dp))

            SecondaryButton(
                text = "Clear history",
                onClick = {
                    controller.clearAlerts {
                        rows = emptyList()
                        reloadKey += 1
                    }
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (loaded && rows.isEmpty()) {
                EmptyNote("Nothing has been said yet.")
            }

            rows.forEach { row ->
                SectionCard(modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(row.title, style = MaterialTheme.typography.titleSmall)
                    Text(
                        row.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyValueRow(label = "When", value = formatTime(row.createdAtMillis))
                    KeyValueRow(
                        label = "Delivered",
                        value = buildString {
                            append(if (row.notified) "screen" else "no screen")
                            append(" · ")
                            append(if (row.spoken) "phone" else "no phone")
                            if (row.alexaStatus.isNotBlank()) {
                                append(" · Alexa ")
                                append(row.alexaStatus.lowercase())
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private fun minutesToText(minutes: Int): String {
    val hour = minutes / 60
    val minute = minutes % 60
    return String.format(Locale.US, "%02d:%02d", hour, minute)
}

private fun textToMinutes(value: String): Int? {
    val parts = value.trim().split(':')
    if (parts.size != 2) return null
    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}

private fun formatTime(millis: Long): String =
    SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date(millis))

private const val HISTORY_LIMIT = 100
