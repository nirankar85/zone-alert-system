package com.trendanalyzer.one.ui.chart

import com.trendanalyzer.one.market.Candle
import com.trendanalyzer.one.market.MarketFeed
import com.trendanalyzer.one.engine.EnginePipeline

interface ChartDataSource {
    suspend fun candles(resolution: String, limit: Int): List<Candle>
    suspend fun levels(): List<ChartLevel>
}

class EngineChartSource(
    private val feed: MarketFeed,
    private val pipeline: EnginePipeline,
    private val allowedGrades: suspend () -> Set<Int>? = { null }
) : ChartDataSource {

    override suspend fun candles(resolution: String, limit: Int): List<Candle> =
        feed.candles(resolution, limit)

    override suspend fun levels(): List<ChartLevel> {
        // Null means the owner: the whole ladder. A set means a client, and only those grades
        // may ever reach the page. An empty set therefore draws no lines at all.
        val allowed = allowedGrades()
        val readings = pipeline.zones.value.filter { reading ->
            allowed == null || reading.grade in allowed
        }
        return ChartJson.levelsFrom(readings)
    }
}
