package com.trendanalyzer.one.account

import com.trendanalyzer.one.config.AppConfig

/**
 * A client signs in with a short ID, not an email. The ID is turned into a synthetic address so
 * the authentication service never holds a real inbox for a client.
 */
object ClientIdentity {

    private val pattern = Regex("^[a-z0-9][a-z0-9_-]{2,31}$")

    fun normalize(raw: String): String = raw.trim().lowercase()

    fun isValid(clientId: String): Boolean = pattern.matches(clientId)

    fun emailFor(clientId: String): String =
        "client+${normalize(clientId)}@${AppConfig.CLIENT_EMAIL_DOMAIN}"

    fun clientIdFromEmail(email: String): String? {
        val normalized = email.trim().lowercase()
        val prefix = "client+"
        val suffix = "@${AppConfig.CLIENT_EMAIL_DOMAIN}"

        if (!normalized.startsWith(prefix) || !normalized.endsWith(suffix)) return null

        val candidate = normalized.removePrefix(prefix).removeSuffix(suffix)
        return candidate.takeIf { isValid(it) }
    }

    fun suggestFromName(displayName: String): String {
        val base = displayName.trim().lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .take(24)

        return base.ifBlank { "client" }
    }
}
