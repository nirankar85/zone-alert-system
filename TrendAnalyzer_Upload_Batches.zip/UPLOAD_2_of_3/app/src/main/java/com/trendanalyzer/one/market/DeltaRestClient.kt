package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig
import com.trendanalyzer.one.log.Logx
import com.trendanalyzer.one.time.AppClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

class DeltaHttpException(val statusCode: Int) : IOException("http $statusCode")

/**
 * Public market data only. No key, no signature, no account.
 */
class DeltaRestClient(
    private val http: OkHttpClient = defaultClient(),
    private val gate: RateLimitGate,
    private val clock: AppClock,
    private val baseUrl: String = AppConfig.REST_BASE_URL
) {

    suspend fun candles(
        resolution: String,
        symbol: String = AppConfig.SYMBOL,
        startMillis: Long,
        endMillis: Long
    ): List<Candle> = withContext(Dispatchers.IO) {
        gate.awaitTurn()

        val url = "$baseUrl/v2/history/candles?resolution=$resolution&symbol=$symbol" +
            "&start=${startMillis / 1000L}&end=${endMillis / 1000L}"

        val body = get(url)
        val candles = DeltaJson.resultArray(body).mapNotNull { parseCandle(it) }
        candles.sortedBy { it.openTimeMillis }
    }

    suspend fun markPrice(symbol: String = AppConfig.SYMBOL): Double? = withContext(Dispatchers.IO) {
        gate.awaitTurn()

        val body = get("$baseUrl/v2/tickers/$symbol")
        val result = DeltaJson.resultObject(body) ?: return@withContext null

        DeltaJson.double(DeltaJson.field(result, "mark_price"))
            ?: DeltaJson.double(DeltaJson.field(result, "close"))
            ?: DeltaJson.double(DeltaJson.field(result, "spot_price"))
    }

    private suspend fun get(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .get()
            .build()

        http.newCall(request).execute().use { response ->
            if (response.code == 429) {
                val header = response.header("X-RATE-LIMIT-RESET")
                gate.noteRateLimit(header)
                throw RateLimitedException(gate.parseResetMillis(header) - clock.nowMillis())
            }

            val body = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Logx.w(TAG, "request failed status ${response.code} for ${LogxSafe.url(url)}")
                throw DeltaHttpException(response.code)
            }

            return body
        }
    }

    private fun parseCandle(element: kotlinx.serialization.json.JsonElement): Candle? {
        val time = DeltaJson.long(DeltaJson.field(element, "time")) ?: return null
        val openTime = if (time < 100_000_000_000L) time * 1_000L else time

        val candle = Candle(
            openTimeMillis = openTime,
            open = DeltaJson.double(DeltaJson.field(element, "open")) ?: return null,
            high = DeltaJson.double(DeltaJson.field(element, "high")) ?: return null,
            low = DeltaJson.double(DeltaJson.field(element, "low")) ?: return null,
            close = DeltaJson.double(DeltaJson.field(element, "close")) ?: return null,
            volume = DeltaJson.double(DeltaJson.field(element, "volume")) ?: 0.0
        )

        return candle.takeIf { it.isValid() }
    }

    private object LogxSafe {
        fun url(raw: String): String = raw.substringBefore('?')
    }

    companion object {
        private const val TAG = "DeltaRestClient"

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
