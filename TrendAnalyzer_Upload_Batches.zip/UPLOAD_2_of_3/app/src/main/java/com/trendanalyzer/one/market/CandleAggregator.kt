package com.trendanalyzer.one.market

/**
 * Folds price ticks into the candle that is still forming. Used for the chart's newest bar and for
 * any test that needs a deterministic forming candle.
 */
class CandleAggregator(private val resolutionMillis: Long) {

    private var current: Candle? = null

    fun onTick(price: Double, atMillis: Long): Candle? {
        if (!price.isFinite() || price <= 0.0) return null
        if (resolutionMillis <= 0L) return null

        val bucketStart = (atMillis / resolutionMillis) * resolutionMillis
        val existing = current

        if (existing == null || existing.openTimeMillis != bucketStart) {
            current = Candle(
                openTimeMillis = bucketStart,
                open = price,
                high = price,
                low = price,
                close = price,
                volume = 0.0
            )
            return current
        }

        val updated = existing.copy(
            high = maxOf(existing.high, price),
            low = minOf(existing.low, price),
            close = price
        )
        current = updated
        return updated
    }

    fun forming(): Candle? = current

    /** True when the tick crossed into a new candle. */
    fun isNewCandle(atMillis: Long): Boolean {
        val existing = current ?: return true
        return existing.openTimeMillis != (atMillis / resolutionMillis) * resolutionMillis
    }
}
