package com.trendanalyzer.one.ui.chart

import com.trendanalyzer.one.engine.LineSide
import com.trendanalyzer.one.market.Candle
import com.trendanalyzer.one.voice.GradeNames

data class ChartLevel(
    val name: String,
    val price: Double,
    val isBuyer: Boolean
)

/**
 * Builds the document the chart page receives. Hand written so the shape is visible and a unit
 * test can compare exact strings; no reflection and no serialization plugin.
 */
object ChartJson {

    fun payload(
        symbol: String,
        timeframe: String,
        candles: List<Candle>,
        levels: List<ChartLevel>
    ): String {
        val builder = StringBuilder(candles.size * 64 + levels.size * 64 + 128)

        builder.append("{")
        builder.append("\"symbol\":").append(quote(symbol)).append(',')
        builder.append("\"timeframe\":").append(quote(timeframe)).append(',')

        builder.append("\"candles\":[")
        candles.forEachIndexed { index, candle ->
            if (index > 0) builder.append(',')
            builder.append('{')
            builder.append("\"t\":").append(candle.openTimeMillis).append(',')
            builder.append("\"o\":").append(number(candle.open)).append(',')
            builder.append("\"h\":").append(number(candle.high)).append(',')
            builder.append("\"l\":").append(number(candle.low)).append(',')
            builder.append("\"c\":").append(number(candle.close))
            builder.append('}')
        }
        builder.append("],")

        builder.append("\"levels\":[")
        levels.forEachIndexed { index, level ->
            if (index > 0) builder.append(',')
            builder.append('{')
            builder.append("\"name\":").append(quote(level.name)).append(',')
            builder.append("\"price\":").append(number(level.price)).append(',')
            builder.append("\"buyer\":").append(if (level.isBuyer) "true" else "false")
            builder.append('}')
        }
        builder.append("]")

        builder.append('}')
        return builder.toString()
    }

    fun levelsFrom(readings: List<com.trendanalyzer.one.engine.ZoneReading>): List<ChartLevel> =
        readings
            .sortedByDescending { it.grade }
            .map { reading ->
                ChartLevel(
                    name = GradeNames.zoneName(reading.grade, reading.side),
                    price = reading.line,
                    isBuyer = reading.side == LineSide.BUYER
                )
            }

    fun quote(value: String): String {
        val builder = StringBuilder(value.length + 2)
        builder.append('"')

        value.forEach { character ->
            when (character) {
                '"' -> builder.append("\\\"")
                '\\' -> builder.append("\\\\")
                '\n' -> builder.append("\\n")
                '\r' -> builder.append("\\r")
                '\t' -> builder.append("\\t")
                else -> if (character.code < 0x20) {
                    builder.append("\\u").append(character.code.toString(16).padStart(4, '0'))
                } else {
                    builder.append(character)
                }
            }
        }

        builder.append('"')
        return builder.toString()
    }

    private fun number(value: Double): String =
        if (value.isFinite()) value.toString() else "0.0"
}
