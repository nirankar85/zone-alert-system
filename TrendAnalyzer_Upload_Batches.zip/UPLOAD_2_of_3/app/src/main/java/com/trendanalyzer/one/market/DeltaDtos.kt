package com.trendanalyzer.one.market

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Reading helpers for the venue payloads. The venue is inconsistent about numbers versus
 * strings, so every number is read through text and parsed once, here.
 */
object DeltaJson {

    fun defaultJson(): Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        explicitNulls = false
    }

    fun double(element: JsonElement?): Double? {
        val primitive = element?.let { runCatching { it.jsonPrimitive }.getOrNull() } ?: return null
        return primitive.content.toDoubleOrNull()
    }

    fun long(element: JsonElement?): Long? {
        val primitive = element?.let { runCatching { it.jsonPrimitive }.getOrNull() } ?: return null
        val text = primitive.content
        return text.toLongOrNull() ?: text.toDoubleOrNull()?.toLong()
    }

    fun string(element: JsonElement?): String? {
        val primitive = element?.let { runCatching { it.jsonPrimitive }.getOrNull() } ?: return null
        return primitive.content
    }

    fun field(element: JsonElement?, name: String): JsonElement? =
        (element as? JsonObject)?.get(name)

    fun resultArray(body: String): List<JsonElement> {
        val root = runCatching { defaultJson().parseToJsonElement(body) }.getOrNull() ?: return emptyList()
        val result = field(root, "result") ?: return emptyList()
        return runCatching { result.jsonArray.toList() }.getOrDefault(emptyList())
    }

    fun resultObject(body: String): JsonObject? {
        val root = runCatching { defaultJson().parseToJsonElement(body) }.getOrNull() ?: return null
        return runCatching { field(root, "result")?.jsonObject }.getOrNull()
    }
}
