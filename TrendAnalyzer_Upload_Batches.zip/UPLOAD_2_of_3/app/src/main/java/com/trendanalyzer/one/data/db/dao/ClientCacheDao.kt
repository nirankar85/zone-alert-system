package com.trendanalyzer.one.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.trendanalyzer.one.data.db.entity.ClientCacheEntity

@Dao
interface ClientCacheDao {

    @Query("SELECT * FROM client_cache WHERE clientId = :clientId LIMIT 1")
    suspend fun get(clientId: String): ClientCacheEntity?

    @Query("SELECT * FROM client_cache ORDER BY displayName ASC")
    suspend fun all(): List<ClientCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: ClientCacheEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rows: List<ClientCacheEntity>)

    @Query("DELETE FROM client_cache WHERE clientId = :clientId")
    suspend fun delete(clientId: String)

    @Query("DELETE FROM client_cache")
    suspend fun clear()
}
