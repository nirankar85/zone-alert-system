package com.trendanalyzer.one.ui.chart

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import com.trendanalyzer.one.ui.components.ScreenScaffold
import org.json.JSONObject

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ChartScreen(
    vm: ChartViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val state by vm.state.collectAsState()
    var pageReady by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.start() }

    ScreenScaffold(title = "Chart", subtitle = "Gold · one look, no noise", onBack = onBack) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                state.visibleTimeframes.forEach { timeframe ->
                    TextButton(
                        onClick = { vm.selectTimeframe(timeframe) },
                        enabled = !state.loading
                    ) {
                        Text(
                            if (state.timeframe == timeframe) "$timeframe ✓" else timeframe,
                            color = if (state.timeframe == timeframe) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }
            }

            if (state.error != null) {
                Text(
                    state.error!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )
            }

            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = false
                            settings.allowFileAccess = true
                            settings.allowContentAccess = false
                            settings.blockNetworkLoads = true
                            setBackgroundColor(0xFF0F1115.toInt())
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    pageReady = true
                                }
                            }
                            loadUrl("file:///android_asset/chart/index.html")
                        }
                    },
                    update = { webView ->
                        val payload = state.payload
                        if (pageReady && payload != null) {
                            webView.evaluateJavascript(
                                "window.renderChart(" + JSONObject.quote(payload) + ")",
                                null
                            )
                        }
                    }
                )

                if (state.loading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }

            Text(
                "Lines are expectations, not instructions.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
            )
        }
    }
}
