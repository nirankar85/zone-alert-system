package com.trendanalyzer.one.market

import com.trendanalyzer.one.config.AppConfig

/**
 * Builds a 45-minute candle out of three 15-minute candles. The grid is anchored to the UTC
 * epoch, so a 45-minute candle always starts at :00, :45 or :30 and never drifts.
 */
object TimeframeBucketer {

    const val BUCKET_MILLIS = 45L * 60L * 1_000L

    fun bucket45(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()

        val sorted = candles.sortedBy { it.openTimeMillis }
        val result = ArrayList<Candle>(sorted.size / 3 + 1)

        var index = 0
        while (index < sorted.size) {
            val bucketStart = (sorted[index].openTimeMillis / BUCKET_MILLIS) * BUCKET_MILLIS

            var open = sorted[index].open
            var high = sorted[index].high
            var low = sorted[index].low
            var close = sorted[index].close
            var volume = sorted[index].volume
            var count = 1

            index++
            while (index < sorted.size && (sorted[index].openTimeMillis / BUCKET_MILLIS) * BUCKET_MILLIS == bucketStart) {
                val candle = sorted[index]
                high = maxOf(high, candle.high)
                low = minOf(low, candle.low)
                close = candle.close
                volume += candle.volume
                count++
                index++
            }

            // A bucket with fewer than one source candle is still a bucket; a partial last bucket
            // is kept because the engine needs the forming candle, not only closed ones.
            result.add(
                Candle(
                    openTimeMillis = bucketStart,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume
                )
            )
        }

        return result
    }

    fun isAligned(openTimeMillis: Long): Boolean = openTimeMillis % BUCKET_MILLIS == 0L

    fun pruneToLimit(candles: List<Candle>): List<Candle> =
        candles.takeLast(AppConfig.CANDLE_STORE_LIMIT)
}
