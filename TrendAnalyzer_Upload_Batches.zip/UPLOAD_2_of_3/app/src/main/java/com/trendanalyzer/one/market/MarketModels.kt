package com.trendanalyzer.one.market

import kotlin.math.abs

data class Candle(
    val openTimeMillis: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0
) {
    fun isValid(): Boolean =
        open.isFinite() && high.isFinite() && low.isFinite() && close.isFinite() &&
            high >= low && openTimeMillis > 0L
}

enum class PriceSource { STREAM, TICKER, CANDLE }

data class PriceTick(
    val price: Double,
    val atMillis: Long,
    val source: PriceSource
)

enum class FeedHealth { UNKNOWN, LIVE, STALE, DOWN }

data class MarketSnapshot(
    val lastPrice: Double? = null,
    val health: FeedHealth = FeedHealth.UNKNOWN,
    val atMillis: Long = 0L,
    val source: PriceSource? = null
) {
    fun isUsable(): Boolean = lastPrice != null && lastPrice > 0.0
}

object Resolutions {

    private val secondsByResolution = mapOf(
        "1m" to 60L,
        "3m" to 180L,
        "5m" to 300L,
        "15m" to 900L,
        "30m" to 1_800L,
        "45m" to 2_700L,
        "1h" to 3_600L,
        "2h" to 7_200L,
        "4h" to 14_400L,
        "6h" to 21_600L,
        "1d" to 86_400L,
        "1w" to 604_800L
    )

    val nativeResolutions: Set<String> = setOf(
        "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "1d", "1w"
    )

    fun seconds(resolution: String): Long? = secondsByResolution[resolution]

    fun durationMillis(resolution: String): Long = (secondsByResolution[resolution] ?: 60L) * 1_000L

    /** True when the venue serves this rhythm directly; 45m is built locally from 15m. */
    fun isNative(resolution: String): Boolean = resolution in nativeResolutions

    fun samePrice(first: Double, second: Double, tolerance: Double = 0.01): Boolean =
        abs(first - second) <= tolerance
}
