# Unverified items

Nothing in this repository has been compiled or run. This page lists what the first build and the
first phone test must prove, in the order they will bite.

| # | Item | Why it is unverified | If it fails |
| --- | --- | --- | --- |
| U-01 | ATR smoothing | Default is a simple average; the charting site uses RMA. Both are implemented. | Compare on a known series; set `AtrSmoothing.RMA` in `EngineSettings` if the owner's reference is RMA. |
| U-02 | 45m bucket | Built locally from three 15m candles on the UTC grid; the venue has no 45m resolution. | Check bucket close against a chart; adjust `TimeframeBucketer`. |
| U-03 | WebSocket payload shape | Parser accepts the documented ticker/candle shapes but no live socket was observed. | Log one frame locally, extend `WsMessageParser`; never guess fields. |
| U-04 | Rate-limit header | `X-RATE-LIMIT-RESET` is parsed as seconds, with an epoch fallback. | Read the real 429 response and adjust `RateLimitGate`. |
| U-05 | No socket resolution probe | The app subscribes to the 1m stream and builds other rhythms from REST. | If a subscription is refused, inspect the error frame and the accepted channel names. |
| U-06 | Placeholder Firebase config | `ci/google-services.json` points to a placeholder project. | Replace it with the real file; the build fails or sign-in fails until then. |
| U-07 | Client account creation | Uses a secondary `FirebaseApp` so the owner stays signed in. | If the provider refuses, create clients in the Firebase console and set `uid` manually. |
| U-08 | Foreground service type | `specialUse` requires a Play declaration if the app is ever published. | Sideloaded builds are unaffected; for Play, fill the declaration or change the type. |
| U-09 | Full-screen intent on Android 14+ | Permission `USE_FULL_SCREEN_INTENT` is declared; the system may still refuse. | The alert still posts as a heads-up notification. Do not promise a takeover screen. |
| U-10 | OEM battery killers | Xiaomi, Oppo, Vivo, Samsung differ. The app can only ask. | Walk the client through battery settings; the ongoing notice proves the service lives. |
| U-11 | WebView local file access | `file:///android_asset` with `blockNetworkLoads = true`. | If the chart is blank, check `setAllowFileAccess` and the console log. |
| U-12 | Version matrix | AGP 8.5.2, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Compose BOM 2024.09.03, Gradle 8.9 were written from memory. | The first CI log names the exact mismatch; change only that pair. |
| U-13 | R8 keep rules | Written for serialization, Room, Firebase. | A release-only crash means a missing keep rule; debug builds are unaffected. |
| U-14 | Chart renderer | Hand-written canvas, no chart library. | Visual bugs are expected; the data contract is tested. |
| U-15 | Whole app | No compiler, no emulator, no device was used. | Treat the first green CI run as the first evidence, not this document. |

## How to report a first-build failure

1. Open the failed Actions run.
2. Copy the step name and the last 40 lines of its log.
3. Note whether it is a Gradle resolution error, a Kotlin error, or a missing Firebase file.
4. Send only that to the owner. Do not paste the whole log into chat.

## What is already tested by unit tests (once they run)

- ATR true range and both smoothings.
- Line invariants: finite, positive, buyer in a rise, seller in a fall.
- Alert engine arming, cooldown, re-arm and grade filter.
- Alert grouping and flush timing.
- 45m bucketing and UTC alignment.
- Rate-limit header parsing and cap.
- Entitlement ranges, expiry and disabled states.
- Password hash round trip and malformed records.
- Client ID rules and email round trip.
- Grade names and announcement sentences.
- Notification title and body.
- Chart JSON escaping and contract.
- Dead-man silence and one restart.
- Secrecy audit over the client surface.

**These tests have never been executed here.** CI will execute them.
