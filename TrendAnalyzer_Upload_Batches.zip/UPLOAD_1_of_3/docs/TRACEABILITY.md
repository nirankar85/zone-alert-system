# Requirement traceability

Every requirement the owner set, mapped to the file that implements it. State is always
"written" - nothing was compiled in the authoring environment.

## Functional

| ID | Requirement | Implementation | State |
| --- | --- | --- | --- |
| F-01 | Seven price zones from 15m to 1d | `config/internal/ZoneRegistry.kt`, `config/internal/ZoneSpec.kt` | written |
| F-02 | Line carried candle to candle, flip on close | `engine/LineEngine.kt` | written |
| F-03 | ATR bands with period 10, multiplier 3 | `engine/Atr.kt`, `engine/ZoneEngine.kt` | written |
| F-04 | 45m built from 15m on UTC grid | `market/TimeframeBucketer.kt` | written |
| F-05 | Alert when price comes within distance | `engine/AlertEngine.kt` | written |
| F-06 | Re-arm only after price walks away | `engine/AlertEngine.kt` | written |
| F-07 | One announcement for simultaneous zones | `engine/AlertGrouper.kt` | written |
| F-08 | Two calm follow-ups, then silence | `engine/AlertDispatcher.kt` | written |
| F-09 | Phone speech | `voice/PhoneVoice.kt`, `voice/AnnouncementTextBuilder.kt` | written |
| F-10 | Alexa speech | `voice/AlexaAnnouncer.kt`, `voice/VoiceMonkeyClient.kt` | written |
| F-11 | Monthly Alexa quota | `voice/AlexaCounter.kt` | written |
| F-12 | Quiet hours | `engine/AlertStateStore.kt`, `config/EngineSettings.kt` | written |
| F-13 | Foreground watch with ongoing notice | `service/MarketWatchService.kt`, `notify/OngoingNotifier.kt` | written |
| F-14 | Restore the watch after reboot | `service/BootReceiver.kt`, `service/WatchRestorePolicy.kt` | written |
| F-15 | Client chart, four neutral timeframes | `ui/chart/*`, `assets/chart/*`, `config/ChartTimeframes.kt` | written |
| F-16 | Alert history | `data/db/*AlertLog*`, `ui/admin/AdminHistoryScreen.kt` | written |
| F-17 | Owner settings | `config/SettingsRepository.kt`, `ui/admin/AdminSystemScreens.kt` | written |

## Accounts and access

| ID | Requirement | Implementation | State |
| --- | --- | --- | --- |
| A-01 | Owner sign-in, owner marker check | `account/AccountRepository.kt`, `FirestoreAccountDataSource.kt` | written |
| A-02 | Client sign-in by client ID | `account/ClientIdentity.kt`, `AccountRepository.kt` | written |
| A-03 | Top-down visible grades | `account/Entitlements.kt`, `ui/model/DashboardViewModel.kt` | written |
| A-04 | Expiry and disable | `account/Entitlements.kt`, `AccountErrors.kt` | written |
| A-05 | Offline client cache | `account/ClientCacheStore.kt`, `data/db/ClientCache*` | written |
| A-06 | Create, update, delete clients | `account/AccountRepository.kt`, `ui/admin/AdminClientsScreen.kt` | written |
| A-07 | Password change is not offered | documented in `docs/OWNER_GUIDE.md` | written |

## Secrecy and security

| ID | Requirement | Implementation | State |
| --- | --- | --- | --- |
| C-01 | Client sees grade names only | `voice/GradeNames.kt`, client screens | written |
| C-02 | No method words, timeframes or venue in client surface | `security/SecrecyAuditTest.kt` | written |
| C-03 | Technical settings only in internal config | `config/internal/*` | written |
| C-04 | Notifications and speech carry no method | `voice/AnnouncementTextBuilder.kt`, `notify/NotificationTexts.kt` | written |
| C-05 | Chart page is neutral and local | `assets/chart/*` | written |
| C-06 | Token in Keystore, AES-GCM | `secure/KeystoreSecretStore.kt` | written |
| C-07 | No backups | `AndroidManifest.xml`, `res/xml/data_extraction_rules.xml` | written |
| C-08 | Log redaction | `log/LogRedactor.kt` | written |
| C-09 | Firestore least privilege | `firestore.rules` | written |
| C-10 | Read-only app | no trading code anywhere | written |

## Reliability

| ID | Requirement | Implementation | State |
| --- | --- | --- | --- |
| R-01 | Respect rate limits and back off | `market/RateLimitGate.kt`, `market/CandleRepository.kt` | written |
| R-02 | Feed health and stale price | `market/FeedHealthMonitor.kt`, `market/HeartbeatMonitor.kt` | written |
| R-03 | Dead-man switch restarts once | `service/DeadManSwitch.kt`, `MarketWatchService.kt` | written |
| R-04 | Retry with backoff | `util/Retry.kt`, `notify/DeliveryRetry.kt` | written |
| R-05 | Offline cache for candles | `market/CandleRepository.kt`, `data/db/Candle*` | written |

## Operations

| ID | Requirement | Implementation | State |
| --- | --- | --- | --- |
| O-01 | One-click build in the browser | `.github/workflows/android.yml` | written |
| O-02 | No secrets in the repository | placeholder config, Keystore, docs | written |
| O-03 | Owner can run it without coding | `docs/OWNER_HANDOVER.md`, `docs/OWNER_GUIDE.md` | written |

## Verification

| Area | Test file |
| --- | --- |
| ATR | `app/src/test/java/com/trendanalyzer/one/engine/AtrTest.kt` |
| Line | `engine/LineEngineTest.kt` |
| Alerts | `engine/AlertEngineTest.kt`, `engine/AlertGrouperTest.kt` |
| Bucketing | `market/TimeframeBucketerTest.kt` |
| Rate limit | `market/RateLimitGateTest.kt` |
| Entitlements | `account/EntitlementsTest.kt` |
| Password | `account/PasswordHasherTest.kt` |
| Client ID | `account/ClientIdentityTest.kt` |
| Speech | `voice/GradeNamesTest.kt`, `voice/AnnouncementTextBuilderTest.kt` |
| Notifications | `notify/NotificationTextsTest.kt` |
| Chart contract | `ui/ChartJsonTest.kt` |
| Dead-man | `service/DeadManSwitchTest.kt` |
| Secrecy | `security/SecrecyAuditTest.kt` |

Test state: written, never executed. See `docs/UNVERIFIED.md` U-15.
