# Owner guide

How to run the app day to day, and what to tell a client.

## The promise

The app watches seven gold levels and speaks when price comes into reach. It does not predict,
does not advise, and never touches a trade. Every alert is information.

## Each morning

1. Open the app. The dashboard shows the last price and a feed label.
2. **Live** means the price is fresh. **Price delayed** means the stream is quiet and the app is
   using the last traded price. **Offline** means wait for a connection.
3. Press **Start** if the watch is off. The ongoing notice must stay in the notification shade.
4. Leave the phone charging if you can.

The watch survives a reboot only when it was on before the reboot and the phone lets the app
start in the background. Some brands block this; the ongoing notice is the proof it is running.

## What an alert sounds like

- First sound: the grade name, the price, and "Watch your plan."
- If price stays in reach: one calm follow-up, then a second, then silence.
- A line speaks once, waits for price to walk away, then re-arms.
- Several lines in reach at the same moment are spoken as one sentence, not seven.

## Quiet hours

Default 22:00 to 07:00. During quiet hours the phone does not speak and Alexa is skipped, but the
alert still appears on the screen. Change the window in **Owner tools -> System**.

## Adding and renewing a client

1. **Owner tools -> Clients -> New client**.
2. Visible grades work from the top down: 4 means grades 4 to 7; 7 means all; 0 shows nothing.
3. Days: 30 for a month, 0 for no end.
4. Send the client ID and password separately, and ask the client to save the password before
   the WhatsApp message is deleted.
5. To renew, open the client, set Days again from today, set Enabled on, save.
6. To pause immediately, set Enabled off. The next sign-in is refused; the phone already signed in
   keeps its last cached view until it refreshes.

Changing a client password is not offered from the app: the sign-in provider does not allow the
owner to set another person's password from a phone. Create a new client ID if a password is lost,
then remove the old one.

## What to tell a client (short, honest)

English:

> This app is read only. It shows the levels your access covers and speaks when gold is near one.
> It is not advice and it never places a trade. Keep notifications on and battery unrestricted,
> otherwise the alert cannot reach you.

Hinglish (owner note only, not app text):

> App sirf levels dikhata hai aur paas aane par bolta hai. Koi trade nahi karta. Notification
> allowed rakhiye aur battery unrestricted rakhiye, warna alert nahi aayega.

## Troubleshooting

| What you see | What to do |
| --- | --- |
| No sound, but the screen shows the alert | Notification permission or phone silent mode. Check **Settings -> Notifications** in the app. |
| No alert at all | Is the watch on? Is the ongoing notice present? Is the feed label Live? |
| Watch stops overnight | Phone battery setting. Set the app to Unrestricted. |
| Alexa silent, phone speaks | Voice Monkey quota, wrong device name, or Alexa announcements switched off. Use **Send a test to Alexa**. |
| Client sees fewer lines than expected | Visible grades is a top-down count. Raise it in Owner tools. |
| Client cannot sign in | Enabled off, expired, wrong ID, or wrong password. Check in this order. |
| Price looks old | Feed label says delayed. Wait; the app reconnects by itself. |

## Support messages

Reply within one working day. Ask for: phone brand, Android version, what the screen said, and a
screenshot with names covered. Never ask for a password or a token in chat.

## Weekly housekeeping

- Check **Owner tools -> Health** for feed and watch status.
- Check **Owner tools -> History** for what was actually said.
- Check the Voice Monkey usage number in **Owner tools -> Voice**.
- Remove clients whose access ended.
