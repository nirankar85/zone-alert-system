# Owner handover

This is the click-by-click path from this zip to an app on a phone. It assumes no coding.
Read the whole page once before starting. Keep the zip until the app is installed.

Total time on a good connection: about 45 to 90 minutes, most of it waiting for the first build.

---

## Part 1 - Put the files on GitHub

GitHub is free hosting for the code and the machine that builds the APK. The APK is the file you
install on the phone.

### 1.1 Create the account and repository

1. Open https://github.com and sign in (or create a free account).
2. Click the **+** at the top right, then **New repository**.
3. Repository name: `trend-analyzer-1pct`.
4. Choose **Private**. The app is read-only, but the owner tools and rules should not be public.
5. Tick **Add a README file**.
6. Click **Create repository**.

### 1.2 Unzip and upload

1. Unzip `TrendAnalyzer1Pct.zip` on the computer. You get a folder containing `app`, `ci`,
   `docs`, `gradle`, `SETUP`, `README.md`, `build.gradle.kts` and the rest.
2. Open that folder. Select **everything inside it** - not the folder itself.
3. On the repository page click **Add file -> Upload files**.
4. Drag the selection into the browser window. Wait until the list stops growing.
5. Scroll down, type `initial upload` in the message box, click **Commit changes**.

GitHub's browser upload can skip empty folders and sometimes skips `.gitignore`. If `.gitignore`
is missing afterwards, use **Add file -> Create new file**, name it `.gitignore`, and paste the
contents from the zip.

### 1.3 Add the build workflow

The workflow lives in a folder whose name starts with a dot; browser upload cannot create it.

1. In the repository click **Add file -> Create new file**.
2. In the file name box type: `.github/workflows/android.yml`
   The slashes create the folders automatically.
3. Open `SETUP/android.yml` from the zip in Notepad. Select all, copy.
4. Paste into the GitHub editor.
5. Click **Commit changes**.

### 1.4 Turn on Actions

1. Click the **Actions** tab. If GitHub asks, click **I understand my workflows, go ahead**.
2. Click **Android CI** on the left, then **Run workflow -> Run workflow**.
3. A yellow dot means running, a green tick means built, a red cross means the log needs work.
4. The first run will probably fail at the Firebase step until Part 2 is done. That is expected.

---

## Part 2 - Firebase (sign-in and client records)

Firebase gives the app sign-in and a small database for client access. The free Spark plan is
enough. No payment card is needed.

### 2.1 Create the project

1. Open https://console.firebase.google.com and sign in with the same Google account.
2. Click **Add project**. Name it `trend-analyzer-1pct`. Turn Google Analytics off if you like.
3. Wait for **Your new project is ready**, then **Continue**.

### 2.2 Register the Android app

1. On the project home, click the Android icon (**Add app**).
2. Android package name: `com.trendanalyzer.one`  (exactly this, all lowercase).
3. App nickname: `Trend Analyzer`. Skip the debug signing certificate.
4. Click **Register app**.
5. Click **Download google-services.json**.
6. In the repository open the `ci` folder, click `google-services.json`, click the pencil
   (**Edit**), select all, delete, paste the downloaded file's contents, commit.
   The file in `ci/` is a placeholder; the real one must replace it. The build copies it into the
   app automatically.

The downloaded file is a public client configuration, not a password, but keep the repository
private anyway.

### 2.3 Enable sign-in

1. Left menu: **Build -> Authentication -> Get started**.
2. **Sign-in method** tab -> **Email/Password** -> enable the first switch -> **Save**.
3. **Users** tab -> **Add user**.
4. Email: the owner's real email. Password: a long one, saved in a password manager.
5. After it appears, copy the **User UID** (a long string). You need it twice below.

This account is the owner. The app checks a marker document before it opens owner tools.

### 2.4 Create the database

1. Left menu: **Build -> Firestore Database -> Create database**.
2. Choose **Production mode** (rules are pasted next, so nobody is locked out for long).
3. Location: pick the closest to India (`asia-south1` if offered). This cannot be changed later.
4. Click **Create**.

### 2.5 Publish the rules

1. Open `firestore.rules` from the zip in Notepad.
2. Replace **both** occurrences of `__ADMIN_UID__` with the UID copied in 2.3.
3. In Firestore, open the **Rules** tab, select all, paste, click **Publish**.

### 2.6 Create the owner marker

1. In Firestore open the **Data** tab.
2. **Start collection**, collection id: `admins`.
3. Document id: paste the owner UID.
4. Add a field `role` (string) with value `owner`. Click **Save**.

Without this document the owner sign-in is refused by design.

### 2.7 Run the build again

1. **Actions -> Android CI -> Run workflow**.
2. Wait for the green tick. First run downloads Gradle and dependencies; 5 to 15 minutes is
   normal.
3. Open the finished run, scroll to **Artifacts**, download `trend-analyzer-debug-apk`.
4. Unzip it - inside is `app-debug.apk`.

If the run is red, open the failed step and read the last 40 lines. See
`docs/UNVERIFIED.md` for the known first-build risks.

---

## Part 3 - Install on the phone

1. Send `app-debug.apk` to the phone (USB, Google Drive, WhatsApp to yourself).
2. Tap the file. Android asks to allow installs from this source; allow it for the app you used
   to open the file, then tap **Install**.
3. Open **TREND ANALYZER 1%**.
4. Allow notifications when asked. Without this an alert has no screen and no sound.
5. Sign in as owner with the email and password from 2.3.
6. Open **Owner tools -> Voice**, then **Announcing credentials**, and enter the Voice Monkey
   token and device (Part 4).
7. Open **Owner tools -> Clients** and add the first client.
8. On the dashboard press **Start** so the watch runs. Android shows a quiet ongoing notice.
9. Phone settings -> Apps -> TREND ANALYZER 1% -> Battery -> **Unrestricted** (the wording differs
   by brand). This is what keeps the watch alive with the screen off.

---

## Part 4 - Alexa (Voice Monkey)

1. Open https://voicemonkey.io and create a free account.
2. In the Voice Monkey dashboard, link the Alexa skill: open the Alexa app -> Skills -> search
   **Voice Monkey** -> enable -> sign in with the same account.
3. In Voice Monkey create a **device** (sometimes called a routine/device). Give it a clear name
   such as `office echo`.
4. Copy the **API token** and the **device name**.
5. In the app: **Owner tools -> Security**, paste both, **Save**. The fields clear after saving
   and are never shown again.
6. **Owner tools -> Voice** -> **Send a test to Alexa**.
7. Turn **Alexa announcements** on. The free plan allows 200 announcements a month; the app
   counts them and the phone still speaks when the quota is used up.

Never send the token in chat, and never paste it into a public repository.

---

## Part 5 - First client, first alert, first proof

1. **Owner tools -> Clients -> New client**.
2. Client ID: lowercase letters, digits, `-` or `_`, at least 3 characters (e.g. `ravi-kumar`).
3. Visible grades: `4` means the client sees the 4th, 5th, 6th and 7th only. `7` means all.
4. Days: `30`. Use `0` for no end.
5. Password: at least 8 characters. Give it to the client on WhatsApp, then delete the message
   after they confirm they saved it.
6. On the client's phone install the same APK, sign in with the client ID and that password.
7. On the owner phone press **Start** and wait. When gold comes within the alert distance of a
   line, the phone says the grade name and the client sees the matching line only.

There is no button that forces a market alert. The Alexa test in Part 4 proves the announcing
path; the first real alert proves the engine. Be honest with the client about that.

---

## Part 6 - Updating the app later

1. Change files in the repository through the browser, or upload replacements.
2. Every commit to `main` starts a new build automatically.
3. Download the new artifact and install it over the old app. Client records and settings stay.

## If something is wrong

1. Write down the screen and the exact words.
2. Take a screenshot; cover any client name.
3. For a build failure, copy the failed step name and the last 40 log lines.
4. Message the owner on WhatsApp **+91 94343 87482**.
5. Never send passwords, the Voice Monkey token, or the full `google-services.json`.
