# Security and secrecy threat model

What the app protects, from whom, and what it does not protect. Read this before promising secrecy.

## Assets

1. **Method secrecy** - the words and numbers that describe how the seven lines are built.
2. **Price source** - the venue name and the resolution ladder.
3. **Voice Monkey token** - lets anyone who holds it speak on the owner's Alexa.
4. **Owner account** - full client administration.
5. **Client list and entitlements** - who pays, what they can see.
6. **Alert history** - what was said and when.

## Adversaries

| Adversary | Capability |
| --- | --- |
| A client with the APK | Can unzip, decompile, read strings, inspect network traffic, screenshot. |
| A curious phone user | Can open notifications, the recent-apps preview, and the chart. |
| A network observer | Sees TLS endpoints and timing, not content. |
| A stolen phone | Has the unlocked screen unless the phone is locked. |
| A lost repository | Has all source, but no secret values if the rules are followed. |

## Controls that exist

| Control | Where |
| --- | --- |
| Client-visible names are grade names only | `voice/GradeNames.kt`, all `ui/` except `ui/admin/` |
| No method vocabulary in client code or assets | `app/src/test/.../security/SecrecyAuditTest.kt` scans the surface |
| Client chart offers only four neutral timeframes | `config/ChartTimeframes.kt` |
| Chart page is local, network loads blocked | `ui/chart/ChartScreen.kt`, `assets/chart` |
| Token encrypted with Android Keystore | `secure/KeystoreSecretStore.kt`, AES-256-GCM |
| Token never rendered after save | `ui/admin/AdminSecurityScreen.kt` |
| Log redaction for tokens, emails, passwords | `log/LogRedactor.kt`, `log/Logx.kt` |
| Backups disabled | `AndroidManifest.xml` `allowBackup=false`, extraction rules |
| Firestore denies everything not listed | `firestore.rules` |
| Client may read only their own record | `firestore.rules` `clients/{id}` |
| Owner check by marker document, not by email text | `account/FirestoreAccountDataSource.kt` |
| Second-opinion password hash (PBKDF2) | `account/PasswordHasher.kt` |
| No trade endpoints, no API keys, no order code | entire tree |
| Release build shrunk and resource-shrunk | `app/build.gradle.kts`, `proguard-rules.pro` |

## Residual risks (say these out loud)

1. **A determined client can still reverse-engineer.** R8 renames code; it cannot hide the shape of
   a calculation. The engine lives in the same APK. Secrecy here is commercial, not cryptographic.
2. **The lines themselves reveal behaviour.** A client who records alerts for a month learns how
   the lines react, even without the formula.
3. **The phone is the weak point.** Screenshots, a shared screen, or a notification preview can
   show a grade and a price. The app cannot prevent a camera.
4. **Alexa speech leaves the phone.** Voice Monkey and Amazon process the sentence. Do not put a
   client's name in an announcement.
5. **A rooted phone exposes app storage.** Keystore keys generally survive, but a live process can
   be inspected.
6. **The Firebase client config is public by design.** It is not a secret; the rules are the
   boundary.
7. **Owner tools are only as safe as the owner password.** Use a long unique password and 2FA on
   the Google account that owns the Firebase project.
8. **Screenshots of owner tools can leak the client list.** Do not demo owner tools on a call.

## If the token leaks

1. In Voice Monkey, revoke the token and create a new one.
2. In the app, **Owner tools -> Security**, save the new token.
3. Check **Owner tools -> History** for announcements you did not expect.

## If a client record leaks

1. Set the client **Enabled** off, or delete the record.
2. The client's phone keeps its last cached view until it refreshes; there is no remote wipe.
3. Tell the client plainly what was exposed.

## What is deliberately absent

- No trading, no broker connection, no order placement.
- No analytics SDK, no advertising SDK, no crash reporter.
- No web view navigation, no external links inside the chart.
- No admin password reset for clients (the provider does not allow it from the app).

## Review checklist before each release

1. Does `SecrecyAuditTest` still pass in CI?
2. Did any new string mention a method, a timeframe outside the client four, or the venue?
3. Is the token still only in encrypted storage and never in logs?
4. Are the Firestore rules unchanged except for the UID placeholder?
5. Does the release build still exclude backups?
