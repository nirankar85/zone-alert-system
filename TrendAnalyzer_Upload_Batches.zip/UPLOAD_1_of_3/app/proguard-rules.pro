# Keep the generated serializers that kotlinx.serialization installs at runtime.
-keepclassmembers class ** {
    *** Companion;
}
-keepclasseswithmembers class ** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Firebase models are read reflectively.
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# The internal zone table is deliberately NOT kept: it is renamed in release builds.
