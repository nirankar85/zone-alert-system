(function (global) {
  'use strict';

  var state = null;
  var canvas = null;
  var ctx = null;

  var theme = {
    background: '#0f1115',
    grid: '#1d222c',
    text: '#9aa3b2',
    buyer: '#2fbf71',
    seller: '#e5534b',
    up: '#2fbf71',
    down: '#e5534b'
  };

  function resize() {
    if (!canvas) return;
    var ratio = global.devicePixelRatio || 1;
    var width = canvas.clientWidth || global.innerWidth;
    var height = canvas.clientHeight || global.innerHeight;
    canvas.width = Math.max(1, Math.floor(width * ratio));
    canvas.height = Math.max(1, Math.floor(height * ratio));
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    draw();
  }

  function geometryFor(width, height, candles) {
    var paddingLeft = 6;
    var paddingRight = 118;
    var paddingTop = 18;
    var paddingBottom = 26;

    var low = Infinity;
    var high = -Infinity;
    var i;

    for (i = 0; i < candles.length; i += 1) {
      if (candles[i].l < low) low = candles[i].l;
      if (candles[i].h > high) high = candles[i].h;
    }

    if (state && state.levels) {
      for (i = 0; i < state.levels.length; i += 1) {
        var levelPrice = state.levels[i].price;
        if (levelPrice < low) low = levelPrice;
        if (levelPrice > high) high = levelPrice;
      }
    }

    if (!isFinite(low) || !isFinite(high) || high <= low) {
      low = 0;
      high = 1;
    }

    var span = high - low;
    low -= span * 0.06;
    high += span * 0.06;
    span = high - low;

    var plotWidth = Math.max(1, width - paddingLeft - paddingRight);
    var plotHeight = Math.max(1, height - paddingTop - paddingBottom);
    var step = plotWidth / Math.max(1, candles.length);

    return {
      left: paddingLeft,
      right: width - paddingRight,
      top: paddingTop,
      bottom: height - paddingBottom,
      plotWidth: plotWidth,
      plotHeight: plotHeight,
      step: step,
      bodyWidth: Math.max(1, Math.min(step * 0.62, 14)),
      yFor: function (price) {
        return paddingTop + (high - price) / span * plotHeight;
      }
    };
  }

  function drawGrid(width, height, geometry) {
    ctx.save();
    ctx.strokeStyle = theme.grid;
    ctx.lineWidth = 1;
    ctx.fillStyle = theme.text;
    ctx.font = '10px -apple-system, Roboto, Arial, sans-serif';
    ctx.textBaseline = 'middle';

    var rows = 5;
    for (var i = 0; i <= rows; i += 1) {
      var y = geometry.top + (geometry.plotHeight / rows) * i;
      ctx.beginPath();
      ctx.moveTo(geometry.left, y);
      ctx.lineTo(geometry.right, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawCandles(candles, geometry) {
    ctx.save();

    for (var i = 0; i < candles.length; i += 1) {
      var candle = candles[i];
      var x = geometry.left + geometry.step * i + geometry.step / 2;
      var openY = geometry.yFor(candle.o);
      var closeY = geometry.yFor(candle.c);
      var highY = geometry.yFor(candle.h);
      var lowY = geometry.yFor(candle.l);

      var rising = candle.c >= candle.o;
      ctx.strokeStyle = rising ? theme.up : theme.down;
      ctx.fillStyle = rising ? theme.up : theme.down;
      ctx.lineWidth = 1;

      ctx.beginPath();
      ctx.moveTo(x, highY);
      ctx.lineTo(x, lowY);
      ctx.stroke();

      var top = Math.min(openY, closeY);
      var bodyHeight = Math.max(1, Math.abs(closeY - openY));
      ctx.fillRect(x - geometry.bodyWidth / 2, top, geometry.bodyWidth, bodyHeight);
    }

    ctx.restore();
  }

  function draw() {
    if (!ctx || !canvas) return;

    var width = canvas.clientWidth || global.innerWidth;
    var height = canvas.clientHeight || global.innerHeight;

    ctx.fillStyle = theme.background;
    ctx.fillRect(0, 0, width, height);

    if (!state || !state.candles || !state.candles.length) return;

    var geometry = geometryFor(width, height, state.candles);
    drawGrid(width, height, geometry);
    drawCandles(state.candles, geometry);

    if (global.drawLevels) {
      global.drawLevels(ctx, state.levels, geometry, theme);
    }

    ctx.save();
    ctx.fillStyle = theme.text;
    ctx.font = '11px -apple-system, Roboto, Arial, sans-serif';
    ctx.textBaseline = 'top';
    ctx.fillText('Gold · ' + state.timeframe, geometry.left + 2, 4);
    ctx.restore();
  }

  global.renderChart = function (payload) {
    try {
      state = typeof payload === 'string' ? JSON.parse(payload) : payload;
    } catch (error) {
      return;
    }

    var empty = document.getElementById('empty');
    if (empty) {
      empty.className = state.candles && state.candles.length ? 'hidden' : '';
    }

    draw();
  };

  function begin() {
    canvas = document.getElementById('canvas');
    if (!canvas) return;
    ctx = canvas.getContext('2d');
    global.addEventListener('resize', resize);
    resize();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', begin);
  } else {
    begin();
  }
})(window);
