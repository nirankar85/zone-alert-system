(function (global) {
  'use strict';

  function labelFor(level) {
    return level.name;
  }

  function drawLevels(ctx, levels, geometry, theme) {
    if (!levels || !levels.length) return;

    ctx.save();
    ctx.font = '11px -apple-system, Roboto, Arial, sans-serif';
    ctx.textBaseline = 'middle';

    for (var i = 0; i < levels.length; i += 1) {
      var level = levels[i];
      var y = geometry.yFor(level.price);
      if (!isFinite(y)) continue;

      var colour = level.buyer ? theme.buyer : theme.seller;

      ctx.strokeStyle = colour;
      ctx.globalAlpha = 0.55;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(geometry.left, y);
      ctx.lineTo(geometry.right, y);
      ctx.stroke();

      ctx.globalAlpha = 1;
      var text = labelFor(level) + '  ' + level.price.toFixed(2);
      var width = ctx.measureText(text).width;
      var boxY = Math.min(Math.max(y - 9, geometry.top), geometry.bottom - 18);

      ctx.fillStyle = colour;
      ctx.globalAlpha = 0.18;
      ctx.fillRect(geometry.right - width - 14, boxY, width + 10, 18);

      ctx.globalAlpha = 1;
      ctx.fillStyle = colour;
      ctx.fillText(text, geometry.right - width - 9, boxY + 9);
    }

    ctx.restore();
  }

  global.drawLevels = drawLevels;
})(window);
