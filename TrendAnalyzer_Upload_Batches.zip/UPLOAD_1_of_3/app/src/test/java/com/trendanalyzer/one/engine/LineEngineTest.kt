package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.testing.candle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LineEngineTest {

    private fun risingCandles(count: Int) = (0 until count).map { index ->
        val base = 2_000.0 + index * 2.0
        candle(
            openTimeMillis = (index + 1) * 900_000L,
            open = base,
            high = base + 3.0,
            low = base - 3.0,
            close = base + 2.0
        )
    }

    @Test
    fun tooFewCandlesGiveNoPoints() {
        assertTrue(LineEngine.compute(risingCandles(1), 10, 3.0, AtrSmoothing.SMA).isEmpty())
    }

    @Test
    fun risingSeriesStaysBuyerAndFinite() {
        val points = LineEngine.compute(risingCandles(80), 10, 3.0, AtrSmoothing.SMA)
        assertFalse(points.isEmpty())

        points.forEach { point ->
            assertTrue(point.line.isFinite())
            assertTrue(point.line > 0.0)
        }

        assertEquals(LineSide.BUYER, points.last().side)
    }

    @Test
    fun lineIsBelowCloseInARisingSeries() {
        val points = LineEngine.compute(risingCandles(80), 10, 3.0, AtrSmoothing.SMA)
        val last = points.last()
        assertTrue(last.line < last.close)
    }

    @Test
    fun fallingSeriesFlipsToSeller() {
        val candles = (0 until 80).map { index ->
            val base = 3_000.0 - index * 2.0
            candle((index + 1) * 900_000L, base, base + 3.0, base - 3.0, base - 2.0)
        }

        val points = LineEngine.compute(candles, 10, 3.0, AtrSmoothing.SMA)
        assertEquals(LineSide.SELLER, points.last().side)
        assertTrue(points.last().line > points.last().close)
    }

    @Test
    fun latestMatchesLastComputedPoint() {
        val candles = risingCandles(40)
        val points = LineEngine.compute(candles, 10, 3.0, AtrSmoothing.SMA)
        val latest = LineEngine.latest(candles, 10, 3.0, AtrSmoothing.SMA)
        assertEquals(points.last(), latest)
    }
}
