package com.trendanalyzer.one.voice

import com.trendanalyzer.one.engine.LineSide
import org.junit.Assert.assertEquals
import org.junit.Test

class GradeNamesTest {

    @Test
    fun buyerNameIsThePublicName() {
        assertEquals("4th Grade Institutional Buyer", GradeNames.zoneName(4, LineSide.BUYER))
    }

    @Test
    fun sellerNameIsThePublicName() {
        assertEquals("7th Grade Institutional Seller", GradeNames.zoneName(7, LineSide.SELLER))
    }

    @Test
    fun alexaNameIsLowerCaseForSpeech() {
        assertEquals("2nd grade institutional buyer", GradeNames.alexaName(2, LineSide.BUYER))
    }

    @Test
    fun ordinalsCoverTheLadder() {
        assertEquals("1st", GradeNames.ordinal(1))
        assertEquals("2nd", GradeNames.ordinal(2))
        assertEquals("3rd", GradeNames.ordinal(3))
        assertEquals("4th", GradeNames.ordinal(4))
        assertEquals("5th", GradeNames.ordinal(5))
        assertEquals("6th", GradeNames.ordinal(6))
        assertEquals("7th", GradeNames.ordinal(7))
    }
}
