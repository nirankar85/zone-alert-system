package com.trendanalyzer.one.account

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EntitlementsTest {

    private val now = 1_700_000_000_000L

    @Test
    fun fourVisibleGradesMeanTheTopFour() {
        val entitlements = Entitlements(visibleGrades = 4, expiresAtMillis = 0L)
        assertEquals(4..7, entitlements.visibleRange)
        assertTrue(entitlements.canSee(7, now))
        assertFalse(entitlements.canSee(3, now))
    }

    @Test
    fun sevenVisibleGradesMeanAllOfThem() {
        val entitlements = Entitlements(visibleGrades = 7, expiresAtMillis = 0L)
        assertEquals(1..7, entitlements.visibleRange)
    }

    @Test
    fun zeroVisibleGradesShowsNothing() {
        val entitlements = Entitlements(visibleGrades = 0, expiresAtMillis = 0L)
        assertEquals(ClientAccessState.NO_GRADES, entitlements.state(now))
        assertFalse(entitlements.canSee(7, now))
    }

    @Test
    fun disabledBeatsExpiry() {
        val entitlements = Entitlements(visibleGrades = 4, expiresAtMillis = now - 1L, enabled = false)
        assertEquals(ClientAccessState.DISABLED, entitlements.state(now))
    }

    @Test
    fun pastExpiryIsExpired() {
        val entitlements = Entitlements(visibleGrades = 4, expiresAtMillis = now - 1L)
        assertEquals(ClientAccessState.EXPIRED, entitlements.state(now))
    }

    @Test
    fun expiryIsInclusiveAtItsMoment() {
        val entitlements = Entitlements(visibleGrades = 4, expiresAtMillis = now)
        assertEquals(ClientAccessState.EXPIRED, entitlements.state(now))
    }

    @Test
    fun noEndMeansActiveForever() {
        val entitlements = Entitlements(visibleGrades = 4, expiresAtMillis = 0L)
        assertEquals(ClientAccessState.ACTIVE, entitlements.state(now))
        assertEquals(Long.MAX_VALUE, entitlements.daysRemaining(now))
    }

    @Test
    fun daysAreRoundedDown() {
        val entitlements = Entitlements(
            visibleGrades = 4,
            expiresAtMillis = now + Entitlements.DAY_MILLIS * 3L + 5_000L
        )
        assertEquals(3L, entitlements.daysRemaining(now))
    }

    @Test
    fun gradesAreClamped() {
        assertEquals(7, Entitlements.clampVisibleGrades(99))
        assertEquals(0, Entitlements.clampVisibleGrades(-4))
    }

    @Test
    fun expiryFromDaysUsesTheClock() {
        assertEquals(now + Entitlements.DAY_MILLIS * 10, Entitlements.expiryFromDays(10, now))
        assertEquals(0L, Entitlements.expiryFromDays(0, now))
    }
}
