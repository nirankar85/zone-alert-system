package com.trendanalyzer.one.market

import com.trendanalyzer.one.testing.candle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TimeframeBucketerTest {

    @Test
    fun threeCandlesBecomeOne() {
        val source = listOf(
            candle(0L, 100.0, 103.0, 99.0, 102.0, 1.0),
            candle(900_000L, 102.0, 105.0, 101.0, 104.0, 2.0),
            candle(1_800_000L, 104.0, 106.0, 103.0, 105.0, 3.0)
        )

        val buckets = TimeframeBucketer.bucket45(source)
        assertEquals(1, buckets.size)

        val bucket = buckets.first()
        assertEquals(0L, bucket.openTimeMillis)
        assertEquals(100.0, bucket.open, 1e-9)
        assertEquals(106.0, bucket.high, 1e-9)
        assertEquals(99.0, bucket.low, 1e-9)
        assertEquals(105.0, bucket.close, 1e-9)
        assertEquals(6.0, bucket.volume, 1e-9)
    }

    @Test
    fun fourthCandleStartsTheNextBucket() {
        val source = (0 until 4).map { index ->
            candle(index * 900_000L, 100.0, 101.0, 99.0, 100.5, 1.0)
        }

        val buckets = TimeframeBucketer.bucket45(source)
        assertEquals(2, buckets.size)
        assertEquals(2_700_000L, buckets[1].openTimeMillis)
        assertTrue(TimeframeBucketer.isAligned(buckets[1].openTimeMillis))
    }

    @Test
    fun boundaryFollowsTheUtcGrid() {
        assertTrue(TimeframeBucketer.isAligned(0L))
        assertTrue(TimeframeBucketer.isAligned(2_700_000L))
        assertTrue(!TimeframeBucketer.isAligned(2_700_001L))
    }

    @Test
    fun emptyInputStaysEmpty() {
        assertTrue(TimeframeBucketer.bucket45(emptyList()).isEmpty())
    }
}
