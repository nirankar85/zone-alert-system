package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.EngineSettings
import com.trendanalyzer.one.testing.FixedClock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AlertEngineTest {

    private val clock = FixedClock(1_000_000L)
    private val engine = AlertEngine(clock)

    private val settings = EngineSettings(
        alertDistancePoints = 5.0,
        rearmDistancePoints = 10.0,
        cooldownSeconds = 60,
        minGrade = 1
    )

    private fun reading(line: Double = 100.0, grade: Int = 4) = ZoneReading(
        zoneId = "Z4",
        grade = grade,
        side = LineSide.BUYER,
        line = line,
        close = 104.0,
        atr = 1.5,
        atMillis = clock.nowMillis()
    )

    @Test
    fun nearAnArmedLineSpeaksOnce() {
        val first = engine.decide(reading(), 104.0, settings, ZoneRuntimeState.initial("Z4"))
        assertNotNull(first.event)
        assertEquals(AlertPhase.COOLDOWN, first.state.phase)

        val second = engine.decide(reading(), 104.0, settings, first.state)
        assertNull(second.event)
    }

    @Test
    fun farPriceKeepsItQuiet() {
        val decision = engine.decide(reading(), 130.0, settings, ZoneRuntimeState.initial("Z4"))
        assertNull(decision.event)
        assertEquals(AlertPhase.ARMED, decision.state.phase)
    }

    @Test
    fun walkingAwayRearmsTheLine() {
        val first = engine.decide(reading(), 104.0, settings, ZoneRuntimeState.initial("Z4"))
        val away = engine.decide(reading(), 130.0, settings, first.state)
        assertEquals(AlertPhase.ARMED, away.state.phase)

        val again = engine.decide(reading(), 104.0, settings, away.state)
        assertNotNull(again.event)
    }

    @Test
    fun gradeBelowOwnerMinimumStaysSilent() {
        val strict = settings.copy(minGrade = 6)
        val decision = engine.decide(reading(grade = 4), 104.0, strict, ZoneRuntimeState.initial("Z4"))
        assertNull(decision.event)
    }

    @Test
    fun invalidPriceIsIgnored() {
        val decision = engine.decide(reading(), 0.0, settings, ZoneRuntimeState.initial("Z4"))
        assertNull(decision.event)
    }

    @Test
    fun sideFlipReArmsEvenInCooldown() {
        val first = engine.decide(reading(), 104.0, settings, ZoneRuntimeState.initial("Z4"))
        val flipped = reading().copy(side = LineSide.SELLER)
        val decision = engine.decide(flipped, 104.0, settings, first.state)
        assertEquals(AlertPhase.COOLDOWN, decision.state.phase)
    }
}
