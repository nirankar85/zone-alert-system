package com.trendanalyzer.one.voice

import com.trendanalyzer.one.engine.AlertEvent
import com.trendanalyzer.one.engine.LineSide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnouncementTextBuilderTest {

    private fun event(grade: Int = 4, side: LineSide = LineSide.BUYER, price: Double = 2_350.0) =
        AlertEvent(
            zoneId = "Z4",
            grade = grade,
            side = side,
            lineValue = 2_345.0,
            price = price,
            atMillis = 0L,
            distance = 5.0
        )

    @Test
    fun singleEventTitleIsTheGradeName() {
        assertEquals("4th Grade Institutional Buyer", AnnouncementTextBuilder.title(listOf(event())))
    }

    @Test
    fun severalEventsAreCounted() {
        val events = listOf(event(4), event(5, LineSide.SELLER))
        assertEquals("2 lines in reach", AnnouncementTextBuilder.title(events))
    }

    @Test
    fun phoneSpeechIsCalmAndComplete() {
        val speech = AnnouncementTextBuilder.phoneSpeech(listOf(event()), AlertKind.FIRST)
        assertTrue(speech.contains("Gold is near the 4th Grade Institutional Buyer line."))
        assertTrue(speech.contains("2,350.00"))
        assertTrue(speech.contains("Watch your plan."))
    }

    @Test
    fun followUpIsShorter() {
        val speech = AnnouncementTextBuilder.phoneSpeech(listOf(event()), AlertKind.FOLLOW_UP_FIRST)
        assertEquals("Still near the 4th Grade Institutional Buyer line. Price 2,350.00.", speech)
    }

    @Test
    fun alexaSpeechHasNoPriceNoise() {
        assertEquals(
            "Gold near 4th grade institutional buyer line.",
            AnnouncementTextBuilder.alexaSpeech(listOf(event()), AlertKind.FIRST)
        )
    }

    @Test
    fun bodyMentionsThePrice() {
        assertEquals(
            "Gold is near 4th Grade Institutional Buyer at 2,350.00.",
            AnnouncementTextBuilder.body(listOf(event()))
        )
    }

    @Test
    fun emptyInputGivesEmptySpeech() {
        assertEquals("", AnnouncementTextBuilder.phoneSpeech(emptyList(), AlertKind.FIRST))
        assertEquals("", AnnouncementTextBuilder.alexaSpeech(emptyList(), AlertKind.FIRST))
        assertEquals("", AnnouncementTextBuilder.body(emptyList()))
        assertEquals("Zone alert", AnnouncementTextBuilder.title(emptyList()))
    }
}
