package com.trendanalyzer.one.market

import com.trendanalyzer.one.testing.FixedClock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RateLimitGateTest {

    private val clock = FixedClock(1_700_000_000_000L)
    private val gate = RateLimitGate(clock)

    @Test
    fun missingHeaderGivesTheShortDefaultPause() {
        assertEquals(clock.now + 30_000L, gate.parseResetMillis(null))
    }

    @Test
    fun headerInSecondsIsAddedToNow() {
        assertEquals(clock.now + 12_000L, gate.parseResetMillis("12"))
    }

    @Test
    fun fractionalSecondsAreTolerated() {
        assertEquals(clock.now + 1_500L, gate.parseResetMillis("1.5"))
    }

    @Test
    fun garbageHeaderFallsBackToDefault() {
        assertEquals(clock.now + 30_000L, gate.parseResetMillis("soon"))
    }

    @Test
    fun pauseIsCapped() {
        val until = gate.parseResetMillis("999999")
        assertTrue(until <= clock.now + 300_000L)
    }
}
