package com.trendanalyzer.one.notify

import com.trendanalyzer.one.engine.AlertEvent
import com.trendanalyzer.one.engine.LineSide
import org.junit.Assert.assertEquals
import org.junit.Test

class NotificationTextsTest {

    private val event = AlertEvent(
        zoneId = "Z4",
        grade = 4,
        side = LineSide.BUYER,
        lineValue = 2_345.0,
        price = 2_350.0,
        atMillis = 0L,
        distance = 5.0
    )

    @Test
    fun titleIsTheGradeName() {
        assertEquals("4th Grade Institutional Buyer", NotificationTexts.title(listOf(event)))
    }

    @Test
    fun bodyMentionsTheLineAndThePrice() {
        assertEquals(
            "Gold is near 4th Grade Institutional Buyer at 2,350.00.",
            NotificationTexts.body(listOf(event))
        )
    }
}
