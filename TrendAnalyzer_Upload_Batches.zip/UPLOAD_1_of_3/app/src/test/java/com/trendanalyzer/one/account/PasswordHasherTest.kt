package com.trendanalyzer.one.account

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHasherTest {

    @Test
    fun roundTripVerifies() {
        val encoded = PasswordHasher.hash("correct horse", iterations = 10_000)
        assertTrue(PasswordHasher.verify("correct horse", encoded))
    }

    @Test
    fun wrongPasswordFails() {
        val encoded = PasswordHasher.hash("correct horse", iterations = 10_000)
        assertFalse(PasswordHasher.verify("wrong horse", encoded))
    }

    @Test
    fun twoHashesOfTheSamePasswordDiffer() {
        val first = PasswordHasher.hash("same", iterations = 10_000)
        val second = PasswordHasher.hash("same", iterations = 10_000)
        assertFalse(first == second)
    }

    @Test
    fun encodedFormatIsReadable() {
        val encoded = PasswordHasher.hash("secret", iterations = 10_000)
        assertTrue(encoded.startsWith("pbkdf2_sha256$10000$"))
        assertTrue(encoded.split('$').size == 4)
    }

    @Test
    fun malformedRecordNeverVerifies() {
        assertFalse(PasswordHasher.verify("secret", "not a hash"))
        assertFalse(PasswordHasher.verify("secret", "pbkdf2_sha256$1$abc$def"))
        assertFalse(PasswordHasher.verify("", "pbkdf2_sha256$10000$abc$def"))
    }
}
