package com.trendanalyzer.one.security

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The secrecy rule, tested as a property of the shipped client surface rather than trusted to
 * review. Anything a client can read, hear or see is scanned for words that would reveal how the
 * lines are built or where the price comes from.
 *
 * Patterns use word boundaries so UI class names such as CircularProgressIndicator and colour
 * literals such as #1d222c do not count as leaks.
 */
class SecrecyAuditTest {

    private val forbidden = listOf(
        Regex("\\bsupertrend\\b", RegexOption.IGNORE_CASE),
        Regex("\\bindicator\\b", RegexOption.IGNORE_CASE),
        Regex("\\baverage true range\\b", RegexOption.IGNORE_CASE),
        Regex("\\batr\\b", RegexOption.IGNORE_CASE),
        Regex("\\bmultiplier\\b", RegexOption.IGNORE_CASE),
        Regex("\\bxautusd\\b", RegexOption.IGNORE_CASE),
        Regex("\\bmark price\\b", RegexOption.IGNORE_CASE),
        Regex("\\bdelta exchange\\b", RegexOption.IGNORE_CASE),
        Regex("\\b15m\\b", RegexOption.IGNORE_CASE),
        Regex("\\b30m\\b", RegexOption.IGNORE_CASE),
        Regex("\\b45m\\b", RegexOption.IGNORE_CASE),
        Regex("\\b1h\\b", RegexOption.IGNORE_CASE),
        Regex("\\b2h\\b", RegexOption.IGNORE_CASE),
        Regex("\\b4h\\b", RegexOption.IGNORE_CASE),
        Regex("\\b1d\\b", RegexOption.IGNORE_CASE)
    )

    @Test
    fun clientSurfaceNamesNoMethodNoTimeframeNoVenue() {
        val roots = resolveRoots()
        assertTrue("scan roots are missing", roots.isNotEmpty())

        val violations = mutableListOf<String>()
        var scanned = 0

        roots.forEach { root ->
            root.walkTopDown()
                .filter { it.isFile }
                .filter { it.extension in scannedExtensions }
                .filterNot { it.path.replace('\\', '/').contains(adminSegment) }
                .forEach { file ->
                    scanned += 1
                    val text = runCatching { file.readText() }.getOrDefault("")

                    forbidden.forEach { pattern ->
                        if (pattern.containsMatchIn(text)) {
                            violations += "${file.path} contains ${pattern.pattern}"
                        }
                    }
                }
        }

        assertTrue("no files were scanned", scanned > 10)
        assertTrue("client surface leaks: ${violations.joinToString("; ")}", violations.isEmpty())
    }

    private fun resolveRoots(): List<File> {
        val relative = listOf(
            "java/com/trendanalyzer/one/ui",
            "java/com/trendanalyzer/one/voice",
            "java/com/trendanalyzer/one/notify",
            "assets/chart",
            "res/values"
        )

        val bases = listOf("src/main", "app/src/main")

        bases.forEach { base ->
            val files = relative.map { File(base, it) }
            if (files.all { it.exists() }) return files
        }

        return emptyList()
    }

    private companion object {
        val scannedExtensions = setOf("kt", "js", "css", "html", "xml")
        const val adminSegment = "/ui/admin/"
    }
}
