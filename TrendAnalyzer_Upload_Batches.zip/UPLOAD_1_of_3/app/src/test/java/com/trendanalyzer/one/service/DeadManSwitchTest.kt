package com.trendanalyzer.one.service

import com.trendanalyzer.one.testing.FixedClock
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeadManSwitchTest {

    private val clock = FixedClock(1_000_000L)
    private val deadMan = DeadManSwitch(clock)

    @Test
    fun recentTicketIsNotSilent() {
        assertFalse(deadMan.isSilent(clock.now - 10_000L))
    }

    @Test
    fun oldTicketIsSilent() {
        assertTrue(deadMan.isSilent(clock.now - 300_001L))
    }

    @Test
    fun zeroTicketIsNotJudged() {
        assertFalse(deadMan.isSilent(0L))
    }

    @Test
    fun restartHappensOnlyOnce() {
        val old = clock.now - 400_000L
        assertTrue(deadMan.shouldRestart(old, alreadyRestarted = false))
        assertFalse(deadMan.shouldRestart(old, alreadyRestarted = true))
    }
}
