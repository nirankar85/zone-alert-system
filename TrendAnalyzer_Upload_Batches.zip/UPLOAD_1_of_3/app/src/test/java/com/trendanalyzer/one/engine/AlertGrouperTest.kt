package com.trendanalyzer.one.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AlertGrouperTest {

    private fun event(zoneId: String) = AlertEvent(
        zoneId = zoneId,
        grade = 4,
        side = LineSide.BUYER,
        lineValue = 2_000.0,
        price = 2_002.0,
        atMillis = 0L,
        distance = 2.0
    )

    @Test
    fun firstEventOpensTheWindow() {
        val grouper = AlertGrouper(3_000L)
        assertTrue(grouper.add(event("Z1"), 1_000L))
        assertFalse(grouper.add(event("Z2"), 1_100L))
        assertEquals(2, grouper.size())
    }

    @Test
    fun windowIsNotReadyBeforeItCloses() {
        val grouper = AlertGrouper(3_000L)
        grouper.add(event("Z1"), 1_000L)
        assertFalse(grouper.readyToFlush(3_999L))
        assertTrue(grouper.readyToFlush(4_000L))
    }

    @Test
    fun flushEmptiesTheGroup() {
        val grouper = AlertGrouper(3_000L)
        grouper.add(event("Z1"), 1_000L)
        grouper.add(event("Z2"), 1_000L)
        val flushed = grouper.flush()
        assertEquals(2, flushed.size)
        assertTrue(grouper.isEmpty())
    }
}
