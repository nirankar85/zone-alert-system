package com.trendanalyzer.one.ui

import com.trendanalyzer.one.market.Candle
import com.trendanalyzer.one.ui.chart.ChartJson
import com.trendanalyzer.one.ui.chart.ChartLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChartJsonTest {

    private val candle = Candle(
        openTimeMillis = 60_000L,
        open = 2_350.5,
        high = 2_355.0,
        low = 2_348.0,
        close = 2_352.0,
        volume = 12.0
    )

    @Test
    fun payloadKeepsTheChartContract() {
        val payload = ChartJson.payload(
            symbol = "XAUUSD",
            timeframe = "5m",
            candles = listOf(candle),
            levels = listOf(ChartLevel("4th Grade Institutional Buyer", 2_345.0, true))
        )

        assertTrue(payload.startsWith("{\"symbol\":\"XAUUSD\","))
        assertTrue(payload.contains("\"timeframe\":\"5m\""))
        assertTrue(payload.contains("\"candles\":[{\"t\":60000,\"o\":2350.5,\"h\":2355.0,\"l\":2348.0,\"c\":2352.0}]"))
        assertTrue(payload.contains("\"name\":\"4th Grade Institutional Buyer\""))
        assertTrue(payload.contains("\"buyer\":true"))
    }

    @Test
    fun emptyInputsStillProduceValidEmptyArrays() {
        val payload = ChartJson.payload("XAUUSD", "1m", emptyList(), emptyList())
        assertTrue(payload.contains("\"candles\":[]"))
        assertTrue(payload.contains("\"levels\":[]"))
    }

    @Test
    fun quoteEscapesTheDangerousCharacters() {
        assertEquals("\"a\\\"b\\\\c\\n\"", ChartJson.quote("a\"b\\c\n"))
    }

    @Test
    fun controlCharactersBecomeUnicodeEscapes() {
        assertEquals("\"\\u0001\"", ChartJson.quote("\u0001"))
    }

    @Test
    fun sellerFlagIsWritten() {
        val payload = ChartJson.payload(
            "XAUUSD", "1m", listOf(candle),
            listOf(ChartLevel("7th Grade Institutional Seller", 2_400.0, false))
        )
        assertTrue(payload.contains("\"buyer\":false"))
    }
}
