package com.trendanalyzer.one.testing

import com.trendanalyzer.one.time.AppClock

class FixedClock(var now: Long) : AppClock {
    override fun nowMillis(): Long = now
}

fun candle(
    openTimeMillis: Long,
    open: Double,
    high: Double,
    low: Double,
    close: Double,
    volume: Double = 0.0
) = com.trendanalyzer.one.market.Candle(
    openTimeMillis = openTimeMillis,
    open = open,
    high = high,
    low = low,
    close = close,
    volume = volume
)
