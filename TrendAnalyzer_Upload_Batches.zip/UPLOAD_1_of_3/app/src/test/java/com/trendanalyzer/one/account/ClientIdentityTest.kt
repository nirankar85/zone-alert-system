package com.trendanalyzer.one.account

import com.trendanalyzer.one.config.AppConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ClientIdentityTest {

    @Test
    fun emailRoundTrips() {
        val email = ClientIdentity.emailFor("gold-7")
        assertTrue(email.contains(AppConfig.CLIENT_EMAIL_DOMAIN))
        assertEquals("gold-7", ClientIdentity.clientIdFromEmail(email))
    }

    @Test
    fun normalizationTrimsAndLowers() {
        assertEquals("gold-7", ClientIdentity.normalize("  GOLD-7 "))
    }

    @Test
    fun shortIdsAreRejected() {
        assertFalse(ClientIdentity.isValid("ab"))
        assertFalse(ClientIdentity.isValid("has space"))
        assertFalse(ClientIdentity.isValid("-leading"))
        assertTrue(ClientIdentity.isValid("abc"))
    }

    @Test
    fun foreignEmailIsRejected() {
        assertNull(ClientIdentity.clientIdFromEmail("person@example.com"))
        assertNull(ClientIdentity.clientIdFromEmail("client+ab@" + AppConfig.CLIENT_EMAIL_DOMAIN))
    }

    @Test
    fun suggestionKeepsItSimple() {
        assertEquals("ravi-kumar", ClientIdentity.suggestFromName("Ravi Kumar"))
        assertTrue(ClientIdentity.isValid(ClientIdentity.suggestFromName("Ravi Kumar")))
    }
}
