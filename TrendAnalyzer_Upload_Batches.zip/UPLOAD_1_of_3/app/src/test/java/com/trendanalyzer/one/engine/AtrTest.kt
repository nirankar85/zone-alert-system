package com.trendanalyzer.one.engine

import com.trendanalyzer.one.config.AtrSmoothing
import com.trendanalyzer.one.market.Candle
import com.trendanalyzer.one.testing.candle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AtrTest {

    private val candles = listOf(
        candle(60_000, 100.0, 102.0, 99.0, 101.0),
        candle(120_000, 101.0, 103.0, 100.0, 102.0),
        candle(180_000, 102.0, 104.0, 101.0, 103.0),
        candle(240_000, 103.0, 105.0, 102.0, 104.0)
    )

    @Test
    fun trueRangeOfFirstCandleIsItsSpan() {
        val ranges = Atr.trueRanges(candles)
        assertEquals(3.0, ranges[0], 1e-9)
    }

    @Test
    fun trueRangeOfSecondCandle() {
        val ranges = Atr.trueRanges(candles)
        assertEquals(3.0, ranges[1], 1e-9)
    }

    @Test
    fun seriesLeavesLeadingZeroesBeforePeriodIsFilled() {
        val series = Atr.series(candles, period = 3)
        assertEquals(0.0, series[0], 1e-9)
        assertEquals(0.0, series[1], 1e-9)
        assertTrue(series[2] > 0.0)
    }

    @Test
    fun simpleAverageOfThreeRanges() {
        val series = Atr.series(candles, period = 3, smoothing = AtrSmoothing.SMA)
        val ranges = Atr.trueRanges(candles)
        val expected = (ranges[0] + ranges[1] + ranges[2]) / 3.0
        assertEquals(expected, series[2], 1e-9)
    }

    @Test
    fun rmaSeedsOnTheSimpleAverage() {
        val series = Atr.series(candles, period = 3, smoothing = AtrSmoothing.RMA)
        val ranges = Atr.trueRanges(candles)
        val seed = (ranges[0] + ranges[1] + ranges[2]) / 3.0
        assertEquals(seed, series[2], 1e-9)
        assertEquals((seed * 2.0 + ranges[3]) / 3.0, series[3], 1e-9)
    }

    @Test
    fun tooFewCandlesReturnZeroes() {
        val series = Atr.series(candles.take(2), period = 5)
        assertEquals(2, series.size)
        assertEquals(0.0, series[0], 1e-9)
        assertEquals(0.0, series[1], 1e-9)
    }

    @Test
    fun latestReturnsZeroWhenEmpty() {
        assertEquals(0.0, Atr.latest(emptyList<Candle>()), 1e-9)
    }
}
