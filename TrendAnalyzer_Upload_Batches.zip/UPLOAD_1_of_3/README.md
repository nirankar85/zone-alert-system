# TREND ANALYZER 1%

A read-only Android app that watches seven gold levels, speaks a pullback alert on the phone and
on the owner's Alexa, then follows up calmly. It never places, changes or closes a trade.

Package: `com.trendanalyzer.one` · Android 8.0+ (API 26) · Kotlin + Jetpack Compose

## Honest status

Every source file, test and document in this repository was written and saved. **Nothing here has
been compiled or run yet.** The first GitHub Actions run is the first build. See
[`docs/UNVERIFIED.md`](docs/UNVERIFIED.md) for the exact list of things that could need a fix on
that first run. Do not promise a working APK until the green artifact exists.

## Start here (no coding)

1. Follow [`docs/OWNER_HANDOVER.md`](docs/OWNER_HANDOVER.md) step by step: GitHub upload,
   Firebase project, `google-services.json`, Firestore rules, first build, phone install.
2. Read [`docs/OWNER_GUIDE.md`](docs/OWNER_GUIDE.md) for daily use and client onboarding.
3. Read [`docs/SECURITY_THREAT_MODEL.md`](docs/SECURITY_THREAT_MODEL.md) before promising secrecy
   to anyone.

## What is in the tree

| Area | Folder |
| --- | --- |
| App shell, screens, navigation | `app/src/main/java/com/trendanalyzer/one/ui` |
| Seven-grade engine and alert state machine | `app/src/main/java/com/trendanalyzer/one/engine` |
| Price feed, candles, rate limiting | `app/src/main/java/com/trendanalyzer/one/market` |
| Phone speech and Alexa announcing | `app/src/main/java/com/trendanalyzer/one/voice` |
| Notifications and alert history | `app/src/main/java/com/trendanalyzer/one/notify` |
| Foreground watch service | `app/src/main/java/com/trendanalyzer/one/service` |
| Accounts, entitlements, Firebase | `app/src/main/java/com/trendanalyzer/one/account` |
| Protected storage | `app/src/main/java/com/trendanalyzer/one/secure` |
| Local chart page | `app/src/main/assets/chart` |
| Unit tests | `app/src/test/java/com/trendanalyzer/one` |
| Build workflow | `.github/workflows/android.yml` |
| Firestore rules | `firestore.rules` |

## Support

WhatsApp **+91 94343 87482**. Do not send passwords, tokens or the `google-services.json` file in
chat.
