# Adding the build workflow without a coding tool

GitHub's browser uploader cannot create a folder whose name starts with a dot. That is the only
reason this folder exists.

1. Open the repository on github.com.
2. Click **Add file -> Create new file**.
3. In the file name box type exactly: `.github/workflows/android.yml`
   (typing the slashes creates the folders).
4. Open `SETUP/android.yml` from this zip, copy all of it, paste it into the editor.
5. Click **Commit changes**.

`.github/workflows/android.yml` in the repository and `SETUP/android.yml` must stay identical.
